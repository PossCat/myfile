import os
import setuptools
from soterml import __version__

here = os.path.abspath(os.path.dirname(__file__))


def read_file(file_name):
    file_path = os.path.join(here, file_name)
    return open(file_path).read().strip()


setuptools.setup(
    name="ml",  # Replace with your own username
    version = __version__,
    author="Guoxin Li",
    author_email="gxli@soterone.com",
    description="ML SDK",
    long_description=read_file('README.md'),
    long_description_content_type="text/markdown",
    url="https://github.com/soterone/ML-SDK",
    packages=setuptools.find_packages(exclude=['contrib', 'docs', 'tests*', 'examples', 'run']),
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Topic :: Software Development :: Build Tools',
        "Programming Language :: Python :: 3",
    ],
    python_requires='>=3.6',
)