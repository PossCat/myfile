"""
test of util in connection
"""
import unittest
import os
import sys

from soterml.connection.utils.soterone_utils import bytes_from_file


class TestSoteroneUtils(unittest.TestCase):
    """
    test class
    """
    def test_bytes_from_file(self):
        """
        test the generator of bytes from file
        """
        filepath = './testf.txt'
        if os.path.exists(filepath):
            os.remove(filepath)
        file = open(filepath, 'w')
        try:
            file.write('23' * 512)
        except:
            print('write error!')
            file.close()
            sys.exit(-1)
        file.close()

        bytes_data = bytes_from_file(filepath, 300)
        for tmp in bytes_data:
            self.assertIsInstance(tmp, bytes)

        os.remove(filepath)
