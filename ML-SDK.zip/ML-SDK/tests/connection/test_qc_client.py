"""
test file of qc_client.py
But qc_client.py may be removed after, because it is just used in end2endtest, and it should is used
in frontend in fact.
"""

import os
import sys
import unittest
from concurrent import futures
import grpc
from soterml.connection.proto import soterone_service_pb2_grpc, soterone_service_pb2
from soterml.connection.qc_client import gen_submit_query, submit_query
from soterml.connection.utils.soterone_utils import bytes_from_file


class FakeServicer(soterone_service_pb2_grpc.SoteroneServiceServicer):
    """
    fake servicer
    """

    def SubmitQuery(self, request_iterator, context):
        """
        ss deal with the submitquey from qc
        """
        for _ in request_iterator:
            pass
        response = soterone_service_pb2.SubmitQueryResponse(uuid='test_res_uuid')
        return response


class TestQcClient(unittest.TestCase):
    """
    test class
    """

    def setUp(self):
        """
        to do before testing
        """
        self.server = grpc.server(futures.ThreadPoolExecutor(max_workers=8))
        soterone_service_pb2_grpc.add_SoteroneServiceServicer_to_server(FakeServicer(), self.server)
        self.server.add_insecure_port('[::]:9001')
        self.server.start()
        self.filepath = './test.txt'

    def test_gen_submit_query(self):
        """
        test  submit_query
        """
        if os.path.exists(self.filepath):
            os.remove(self.filepath)
        file = open(self.filepath, 'w')
        try:
            file.write('23' * 512)
        except:
            print('write error!')
            file.close()
            sys.exit(-1)
        file.close()
        bytes_data = bytes_from_file(self.filepath, 300)

        gen_res = gen_submit_query(uuid='test_uuid', qc_uuid='test_qc_uuid', content=bytes_data)
        for per_res in gen_res:
            self.assertEqual('test_uuid', per_res.query_info.uuid)
        if os.path.exists(self.filepath):
            os.remove(self.filepath)

    def test_submit_query(self):
        """
        test submit_query
        """
        if os.path.exists(self.filepath):
            os.remove(self.filepath)
        file = open(self.filepath, 'w')
        for i in range(9):
            for j in range(1024):
                try:
                    file.write('01' * 512)
                except:
                    print('write error!')
                    file.close()
                    sys.exit(-1)
        file.close()
        with grpc.insecure_channel('localhost:9001') as channel:
            res = submit_query(uuid='test_uuid', qc_uuid='test_qc_uuid',
                               content_path=self.filepath, channel=channel)
            self.assertEqual(res.uuid, 'test_res_uuid')
        if os.path.exists(self.filepath):
            os.remove(self.filepath)
