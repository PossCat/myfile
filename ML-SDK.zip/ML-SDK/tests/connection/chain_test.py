import json
import random
import threading
import time
import unittest
import logging
from binascii import unhexlify

from soterml.connection.chain import ChainEvent, NodeType, SoterOneChain
from soterml.connection.chain_connection_helpers import CHAIN_EVENT_GET_FAILED_WAIT_TIME_IN_S


class TestChain(unittest.TestCase):
    def test_simple(self):
        ctx = {}

        # implement your callback
        def call_back(chain, event):
            print("receive event: ", event)

        def psi_callback(chain, event):
            print("receive event: ", event)
            plan = event['plan'][2:]
            plan_bytes = plan.encode(encoding='utf-8')
            plan_str = unhexlify(plan_bytes)
            print("psi plan: ", eval(plan_str))

        sc = SoterOneChain('http://192.168.1.5:8545',
                           '980b26e2fa86b5a1ca0e3fd6eafcfd226fb868727522022289287ceb7f328768',
                           ctx)
        sc.subscribe(ChainEvent.LogAdded, call_back)
        # sc.subscribe(ChainEvent.DORegistered, call_back)
        sc.subscribe(ChainEvent.ServerReady, call_back)
        # sc.subscribe(ChainEvent.DOUnregistered, call_back)
        # sc.subscribe(ChainEvent.MPCRegistered, call_back)
        # sc.subscribe(ChainEvent.MPCUnregistered, call_back)
        # sc.subscribe(ChainEvent.PSIPlan, psi_callback)
        # sc.subscribe(ChainEvent.QueryDispatched, call_back)
        # sc.subscribe(ChainEvent.QueryProgressUpdated, call_back)

        time.sleep(10)


        # topics = ['0x2a105b504873e6cae2ea9e9eba00d2f1ded4557ca784f61d4729458967139860']
        # event_filter = {
        #     "address": sc.contract.contract_addr,
        #     "topics": topics,
        #     "fromBlock": hex(52093),
        #     "toBlock": hex(52093)
        # }
        # print('start get...')
        # logs = sc.contract.w3h.eth.getLogs(event_filter)
        # print('get logs:', logs)
        #

        # print('add log')
        sc.add_log("111", {"111": 222})
        # print('register do')
        # sc.register_do("122", "fa", 123)
        print('server start listening')
        sc.server_start_listening("23", NodeType.DO)
        # print('unregister do')
        # sc.unregister_do()
        # print('register mpc')
        # sc.register_mpc("23", "123", 123)
        # print('submit psi plan')
        # sc.submit_psi_plan("kkkkkkkkkkkkkkkk", {"plan": "daf"})
        # print('unregister mpc')
        # sc.unregister_mpc()
        # print('submit query')
        # sc.submit_query("94d02f15259c")
        # print('update query progress')
        # sc.update_query_progress("123", 12, 32, 10, 31)

        time.sleep(1 * 60 * 60)
        sc.shutdown(wait=True)


if __name__ == '__main__':
    unittest.main()
