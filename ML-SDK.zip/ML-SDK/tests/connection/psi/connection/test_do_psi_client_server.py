import time
from concurrent import futures
from typing import List

from soterml.connection.psi.connection.do_psi_client import DoPsiClient
from soterml.connection.psi.connection.do_psi_server import DoPsiServer
from soterml.connection.chain import SoterOneChain
import unittest
import grpc

from soterml.connection.psi.proto import psi_server_pb2_grpc


class TestDOPsiClient(unittest.TestCase):

    def setUp(self) -> None:
        self.chain = SoterOneChain('http://192.168.1.22:8645',
                                   '980b26e2fa86b5a1ca0e3fd6ea'
                                   'fcfd226fb868727522022289287ceb7f328768',
                                   {})
        self.server = grpc.server(futures.ThreadPoolExecutor(max_workers=8))
        psi_server_pb2_grpc.add_PsiServerServicer_to_server(
            DoPsiServer(['a', 'b', 'cc12'], {}, tmp_dir='./'), self.server
        )
        self.server.add_insecure_port('[::]:9001')
        self.server.start()

    def test_do_psi_client_send_receive(self):
        client = DoPsiClient(strlist=['b', 'A', 'cc12', '？？？！@！'],
                             psi_server_addr='localhost:9001',
                             tmp_dir='./')
        client.start()
        res = client.psi_procedure(
            {'Server': '192.168.0.1', 'Client': '192.168.0.1'}, self.chain
        )
        client.close()
        self.server.stop(0)
        self.assertEqual(res, ['b', 'cc12'])
