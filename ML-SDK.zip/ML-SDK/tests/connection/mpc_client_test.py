"""
Test the functionality of the MPC client using test model.
Also provides an example of how to use the MPC client.
"""
import proto.mpc_message_pb2 as mpc_message

import unittest
import mpc_client
import logging


class TestMPCClient(unittest.TestCase):
    def setUp(self):
        logging.getLogger().setLevel(logging.DEBUG)

    def test_simple_mpc_client(self):
        client = mpc_client.MPCClient("fake_address:5050", is_testing_mode=True)
        client.start()
        message1 = "Test message A for test"
        message2 = "Test message B for test"
        try:
            # Send test message twice should always get the same message since the client is in the testing mode.
            self.assertTrue(
                message1 in client.send_test_message(mpc_message.TestMessageRequest(test_message=message1))
                .test_message_response.test_message)
            self.assertTrue(
                message2 in client.send_test_message(mpc_message.TestMessageRequest(test_message=message2))
                .test_message_response.test_message)
        finally:
            client.close()


if __name__ == '__main__':
    unittest.main()
