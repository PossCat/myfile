"""
This file tests the api that includes get_query_info() and query_completed()
I create the result by mock, then judge whether they are equal
"""
import os
import shutil
import sys
from concurrent import futures
import unittest
import grpc
from soterml.connection import soterone
from soterml.connection.proto import soterone_service_pb2, soterone_service_pb2_grpc
from soterml.connection.utils.soterone_utils import bytes_from_file


class FakeServicer(soterone_service_pb2_grpc.SoteroneServiceServicer):
    """
    fake servicer
    """

    def GetQueryInfo(self, request, context):
        """
                :param request: rpc request
                :param context: context
                :return: rpc response
                """
        requestid = request.query_uuid  # test signal
        tmp = soterone_service_pb2.GetQueryInfoResponse()

        # create testing response by adding test signal
        query_info = tmp.query_info
        query_info.uuid = 'uuid ' + requestid
        query_info.content = ('content ' + requestid).encode('utf8')

        query_cluster = tmp.query_cluster
        query_cluster.query_uuid = 'query_cluster.query_uuid ' + requestid

        mpc_nodes = query_cluster.mpc_nodes.add()
        mpc_nodes.address = 'mpc_nodes.address1 ' + requestid
        mpc_nodes.port = 'mpc_nodes.port1 ' + requestid
        mpc_nodes = query_cluster.mpc_nodes.add()
        mpc_nodes.address = 'mpc_nodes.address2 ' + requestid
        mpc_nodes.port = 'mpc_nodes.port2 ' + requestid

        do_nodes = query_cluster.do_nodes.add()
        do_nodes.address = 'do_nodes.address1 ' + requestid
        do_nodes.port = 'do_nodes.port1 ' + requestid
        do_nodes = query_cluster.do_nodes.add()
        do_nodes.address = 'do_nodes.address2 ' + requestid
        do_nodes.port = 'do_nodes.port2 ' + requestid

        yield tmp

    def QueryCompleted(self, request, context):
        """
        The rpc response is None, don't ask me,not defined by me
        """
        return soterone_service_pb2.QueryCompletedResponse()

    def RegisterDO(self, request, context):
        """

        @param request:
        @param context:
        @return:
        """
        response = soterone_service_pb2.RegisterDOResponse(uuid='test_uuid')
        return response

    def GetQueryExecutionInfo(self, request, context):
        """
        test function of Server
        """
        res1 = soterone_service_pb2.GetQueryExecutionInfoResponse()
        res1.query_execution_info.result = b'abcdefg'
        res1.result_ready = True

        res2 = soterone_service_pb2.GetQueryExecutionInfoResponse()
        res2.query_execution_info.result = b'abcdSSefg'
        res2.result_ready = False

        for res in (res1, res2):
            yield res

    def RegisterQC(self, request, context):
        """
        test server function
        """
        return soterone_service_pb2.RegisterQCResponse(uuid='testtest')

    def TestModelCompleted(self, request, context):
        """
        test server function
        """
        return soterone_service_pb2.TestModelCompletedResponse()


class TestReceiveFromSs(unittest.TestCase):
    """
    test class
    """

    def setUp(self):
        """
        to do before testing
        """
        self.server = grpc.server(futures.ThreadPoolExecutor(max_workers=8))
        soterone_service_pb2_grpc.add_SoteroneServiceServicer_to_server(FakeServicer(), self.server)
        self.server.add_insecure_port('[::]:9001')
        self.server.start()
        # create tmp directory for save or load file
        self.filepath = './tmp_model/testfile'
        if not os.path.exists('./tmp_model/'):
            os.mkdir('./tmp_model')

    def tearDown(self) -> None:
        """
        to do after each testing, remove the tmp directory
        but because the stream transporting, may can not delete right now
        """
        try:
            shutil.rmtree('./tmp_model')
        except Exception as e:
            pass

    def test_get_query_info(self):
        with grpc.insecure_channel('localhost:9001') as channel:
            response, model_path = soterone.get_query_info('test_query_uuid', channel)
            self.assertIsNotNone(response, 'get_query_info error!')
        os.remove(model_path)

    def test_query_completed(self):
        query_execution_info_dict = {'_uuid': 'test_uuid',
                                     'start_time_ns': 66,
                                     'finished_time_ns': 666,
                                     'status': 1}
        with open(self.filepath, 'ab') as file:
            file.write(b'123abc')
        with grpc.insecure_channel('localhost:9001') as channel:
            response = soterone.query_completed('test_do_uuid',
                                                self.filepath,
                                                channel,
                                                query_execution_info_dict
                                                )
            self.assertIsNotNone(response, 'query_completed error!')

    def test_register_do(self):
        with grpc.insecure_channel('localhost:9001') as channel:
            node_info_do = {'address': '127.0.0.2', 'port': '1235', '_uuid': 'donode'}
            do_uuid = soterone.register_do('test_do_uuid', 'test_key2', channel,
                                           node_info_do).uuid
            os.remove('./do_register_res.json')
            self.assertIsInstance(do_uuid, str)

    def test_get_query_execution_info(self):
        with grpc.insecure_channel('localhost:9001') as channel:
            res, model_path = soterone.get_query_execution_info('sadasdsadas', channel)
            os.remove(model_path)
            self.assertIsInstance(res.result_ready, bool)

    def test_register_qc(self):
        node_info = {'_uuid': 'uuid', 'address': 'address', 'port': 'port'}
        with grpc.insecure_channel('localhost:9001') as channel:
            res = soterone.register_qc(uuid='dsadad', public_key='sadasdsada',
                                       channel=channel, node_info=node_info)
            self.assertEqual(res.uuid, 'testtest')

    def test_gen_query_completed(self):
        """
        test  gen_query_completed
        """
        if os.path.exists(self.filepath):
            os.remove(self.filepath)
        file = open(self.filepath, 'w')
        try:
            file.write('23' * 512)
        except:
            print('write error!')
            file.close()
            sys.exit(-1)
        file.close()
        bytes_data = bytes_from_file(self.filepath, 300)
        query_execution_info_dict = {'_uuid': 'uuid',
                                     'start_time_ns': 123,
                                     'finished_time_ns': 321,
                                     'status': 1}

        gen_res = soterone.gen_query_completed(do_uuid='test_uuid', content=bytes_data,
                                               query_execution_info_dict=query_execution_info_dict)
        for per_res in gen_res:
            self.assertEqual('test_uuid', per_res.do_uuid)
        if os.path.exists(self.filepath):
            os.remove(self.filepath)

    def test_test_model_completed(self):
        """
        the function's name is test_model_completed.
        """
        with grpc.insecure_channel('localhost:9001') as channel:
            res = soterone.test_model_completed(test_uuid='test_uuid', channel=channel)
            self.assertIsNotNone(res)
