"""
Test end two end for mpc server and client.

Test steps:
1. Start MPC server by running 'mpc_server.py 9000'
2. Start MPC client by running 'mpc_client_e2e_test.py 9000'
"""
import proto.mpc_message_pb2 as mpc_message

import sys
import mpc_client
import logging


def start_mpc_client(address):
    client = mpc_client.MPCClient(address)
    client.start()
    try:
        # Send test message twice. Should print two messages with different contents
        print(client.send_test_message(mpc_message.TestMessageRequest(test_message="message1"))
              .test_message_response.test_message)
        print(client.send_test_message(mpc_message.TestMessageRequest(test_message="message2"))
              .test_message_response.test_message)
    finally:
        client.close()


if __name__ == '__main__':
    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)
    start_mpc_client("localhost:" + sys.argv[1])
