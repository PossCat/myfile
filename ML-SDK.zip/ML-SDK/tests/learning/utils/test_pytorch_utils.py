import yaml
import unittest

import torch
import torch.nn.modules.loss as ln
from torch.optim.sgd import SGD

from soterml.learning.horizontal.torch_model.process_data import normalization, one_hot_encode
from soterml.learning.utils.pytorch_utils import (convert_optimizer_to_func,
                                                  convert_loss_name_to_func,
                                                  convert_data_process_to_func,
                                                  get_config_from_config_file,
                                                  send_data_to_device)


class TestPytorchUtils(unittest.TestCase):
    def setUp(self):
        config = {
            'data_config': {
                'batch_size': 1,
                'feature_process': {
                    'numeric_features': 'normalization',
                    'categorical_features': 'one_hot_encode'
                }
            },
            'model_config': {
                'model_train_config': {
                    'loss_fn': 'L1Loss',
                    'optimizer': 'SGD'
                }
            }
        }
        self.yaml_config = yaml.dump(config)
        self.batch_data = [torch.FloatTensor([1, 2, 3]), torch.LongTensor([1, 2])]
        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'

    def test_convert_loss_name_to_func(self):
        loss = 'L1Loss'
        result = convert_loss_name_to_func(loss)
        expect_result = ln.L1Loss
        self.assertEqual(result, expect_result)

    def test_convert_optimizer_to_func(self):
        loss = 'SGD'
        result = convert_optimizer_to_func(loss)
        expect_result = SGD
        self.assertEqual(result, expect_result)

    def test_convert_data_process_to_func(self):
        loss = 'normalization'
        result = convert_data_process_to_func(loss)
        expect_result = normalization
        self.assertEqual(result, expect_result)

    def test_get_config_from_config_file(self):
        config = get_config_from_config_file(self.yaml_config)
        expect = {
            'data_config': {
                'batch_size': 1,
                'feature_process': {
                    'numeric_features': normalization,
                    'categorical_features': one_hot_encode
                }
            },
            'model_config': {
                'model_train_config': {
                    'loss_fn': ln.L1Loss,
                    'optimizer': SGD
                }
            }
        }
        print(config)
        self.assertEqual(config, expect)

    def test_send_data_to_device(self):
        data = send_data_to_device(self.batch_data, self.device)
        if self.device == 'cpu':
            expect = self.batch_data
        else:
            expect = [torch.FloatTensor([1, 2, 3]).to(self.device), torch.LongTensor([1, 2]).to(self.device)]
        self.assertTrue(torch.equal(data[0], expect[0]))
        self.assertTrue(torch.equal(data[1], expect[1]))
