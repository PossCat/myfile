import unittest
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

import numpy as np

from soterml.learning.vertical.connection.secure_boost import SecureBoostConnection
from soterml.learning.vertical.connection.secure_boost import MessageType
from soterml.learning.vertical.utils import consts
from soterml.learning.vertical.utils.party import Party
from soterml.learning.vertical.ml.secure_protocol.paillier_encryptor import PaillierEncryptor
from soterml.learning.vertical.ml.secure_protocol.paillier_encryptor import EncryptedNumber


class TestSecureBoostConnection(unittest.TestCase):
    def setUp(self) -> None:
        self.host0_party = Party(role=consts.HOST, idx=0)
        self.guest0_party = Party(role=consts.GUEST, idx=0)
        self.mpc0_party = Party(role=consts.MPC, idx=0)

        self.host0_port = '50001'
        self.guest0_port = '50002'
        self.mpc0_port = '50003'

        self.host0_parties_map = {self.guest0_party: 'localhost:50002',
                                  self.mpc0_party: 'localhost:50003'}
        self.guest0_parties_map = {self.host0_party: 'localhost:50001',
                                   self.mpc0_party: 'localhost:50003'}
        self.mpc0_parties_map = {self.host0_party: 'localhost:50001',
                                 self.guest0_party: 'localhost:50002'}

    def test__init_connection_and_close(self):
        """
        This test test _init_connection and close
        @return:
        """
        def init_func(parties_map, role, role_index, port):
            try:
                federation = SecureBoostConnection(parties_map=parties_map,
                                                   role=role,
                                                   role_index=role_index,
                                                   port=port)
                federation.close()
            except:
                return False

            return True

        task_pool = ThreadPoolExecutor(max_workers=5)
        task1 = task_pool.submit(init_func, self.host0_parties_map, consts.HOST, 0, self.host0_port)
        task2 = task_pool.submit(init_func, self.guest0_parties_map, consts.GUEST, 0, self.guest0_port)
        task3 = task_pool.submit(init_func, self.guest0_parties_map, consts.MPC, 0, self.mpc0_port)

        tasks = [task1, task2, task3]
        for task in as_completed(tasks):
            assert task.result() is True

    def test_remote_and_get(self):
        # Avoid port occupation
        time.sleep(1)

        encryptor = PaillierEncryptor()
        public_key = encryptor.get_public_key()

        numpy_array = np.ones(1024)

        def task_host_0():
            """
            1. Host_0 send public key to guest_0.
            2. Host_0 send nd.array to mpc_0
            @return:
            """
            federation = SecureBoostConnection(parties_map=self.host0_parties_map,
                                               role=consts.HOST,
                                               role_index=0,
                                               port=self.host0_port)
            try:
                federation.remote(obj=public_key,
                                  obj_type=MessageType.public_key,
                                  role=consts.GUEST,
                                  role_index=0)
                federation.remote(obj=numpy_array,
                                  obj_type=MessageType.loss,
                                  role=consts.MPC,
                                  role_index=0)
            except:
                federation.close()
                return False
            federation.close()
            return True

        def task_guest_0():
            """
            1. Guest_0 get public key from host_0.
            @return:
            """
            federation = SecureBoostConnection(parties_map=self.guest0_parties_map,
                                               role=consts.GUEST,
                                               role_index=0,
                                               port=self.guest0_port)
            public_key_from_host = federation.get(obj_type=MessageType.public_key,
                                                  role=consts.HOST,
                                                  role_index=0)
            assert isinstance(public_key_from_host, EncryptedNumber)
            federation.close()
            return True

        def task_mpc_0():
            """
            1. MPC_0 get nd.array from host_0
            @return:
            """
            federation = SecureBoostConnection(parties_map=self.mpc0_parties_map,
                                               role=consts.MPC,
                                               role_index=0,
                                               port=self.mpc0_port)
            numpy_array_from_host = federation.get(obj_type=MessageType.loss,
                                                   role=consts.HOST,
                                                   role_index=0)
            assert (numpy_array_from_host == np.ones(1024)).all()
            federation.close()
            return True

        tasks_pool = ThreadPoolExecutor(max_workers=3)
        task1 = tasks_pool.submit(task_host_0)
        task2 = tasks_pool.submit(task_guest_0)
        task3 = tasks_pool.submit(task_mpc_0)

        tasks_list = [task1, task2, task3]

        # wait for thread
        for task in as_completed(tasks_list):
            assert task.result() is True



