"""
Training script test
this file is main procedure testing among DO, SS, chain and QC
to run this py file, you must:
1. down and install SoterOneService
2. down and install the chain
3. set address and port right, then start SS and chain
4. run "start_websocket_servers.py" to start websocket server
5. run this file

Additionally, ensure your proto files are the same with SS, or you will get
error!
"""
import mock
import grpc
import unittest
import datetime
import pandas as pd
from multiprocessing import Process

import torch
import syft
from syft.workers.websocket_server import WebsocketServerWorker

from soterml.learning.testnet.train import training_workflow
from soterml.learning.testnet.titanic_MPC_websocket_parallel import Net
from soterml.connection.chain import SoterOneChain
from soterml.connection.proto import soterone_service_pb2


class TestTrainingScript(unittest.TestCase):

    def start_proc(self, id, host, port, hook):  # pragma: no cover
        """ helper function for spinning up a websocket participant """

        def target():
            server = WebsocketServerWorker(id=id, port=port, hook=hook, host=host)
            server.start()

        p = Process(target=target)
        p.start()
        return p

    def setUp(self):
        # max send(receive) message length is 2M(if streaming, per slice)
        self.channel = grpc.insecure_channel('localhost:9000',
                                             options=[
                                                 ('grpc.max_send_message_length', 5 * 1024 * 1024),
                                                 ('grpc.max_receive_message_length',
                                                  5 * 1024 * 1024),
                                             ],
                                             )

        self.hook = syft.TorchHook(torch)
        self.do_uuid = '123'
        self.model_path = 'temp_model_from_QC'
        self.trained_model_path = 'temp_model'
        self.chain = SoterOneChain(rpc_url='http://localhost:8545', private_key='dummy_private_key')
        self.event = {'queryUUID': '0x53515f34656433386633612d373730652d346633622d393830312d616431666564336136306363'}
        self.data = pd.DataFrame(
            {
                'Survived': [1, 0, 1, 0, 1, 2],
                'Pclass': [0, 1, 2, 1, 2, 1],
                'Age': [20, 11, 21, 18, 20, 19],
                'SibSp': [1, 2, 3, 4, 5, 6],
                'Parch': [12, 11, 10, 9, 1, 2],
                'Fare': [1, 1, 2, 2, 2, 1]
            }
        )
        self.start_proc(port="8787", id='worker1', hook=self.hook, host='localhost')
        self.start_proc(port="8788", id='worker2', hook=self.hook, host='localhost')
        self.start_proc(port="8789", id='worker3', hook=self.hook, host='localhost')
        self.start_proc(port="8790", id='worker4', hook=self.hook, host='localhost')

    @staticmethod
    def mock_result_get_query_info():
        cur_time = str(datetime.date.today())
        mock_response = soterone_service_pb2.GetQueryInfoResponse()
        query_info = mock_response.query_info
        query_info.uuid = 'uuid ' + cur_time
        query_info.content = ('content ' + cur_time).encode('utf8')

        query_cluster = mock_response.query_cluster
        query_cluster.query_uuid = 'query_cluster.query_uuid ' + cur_time

        # MPC nodes
        mpc_nodes = query_cluster.mpc_nodes.add()
        mpc_nodes.address = "localhost"
        mpc_nodes.port = "8787"

        mpc_nodes = query_cluster.mpc_nodes.add()
        mpc_nodes.address = "localhost"
        mpc_nodes.port = "8788"

        # Compute nodes
        do_nodes = query_cluster.do_nodes.add()
        do_nodes.address = "localhost"
        do_nodes.port = "8789"

        do_nodes = query_cluster.do_nodes.add()
        do_nodes.address = "localhost"
        do_nodes.port = "8790"

        return mock_response

    @mock.patch('ml.learning.testnet.train.get_query_info')
    @mock.patch('ml.learning.testnet.train.query_completed')
    @mock.patch('ml.learning.testnet.train.load_model_from_path')
    @mock.patch('ml.learning.testnet.train.save_model_to_path')
    @mock.patch('ml.learning.testnet.titanic_MPC_websocket_parallel.pd')
    def test_training_workflow(self,
                               mock_pandas,
                               mock_save_model_to_path,
                               mock_load_model_from_path,
                               mock_query_completed,
                               mock_get_query_info):
        mock_get_query_info.return_value = (self.mock_result_get_query_info(), self.model_path)
        mock_load_model_from_path.return_value = Net()
        mock_pandas.read_csv.return_value = self.data

        training_workflow(self.channel, self.do_uuid, self.trained_model_path, self.chain, self.event)

        self.assertTrue(mock_save_model_to_path.called)
        self.assertTrue(mock_query_completed.called)


if __name__ == '__main__':
    unittest.main()
