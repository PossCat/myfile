import unittest


class TestModelClass(unittest.TestCase):
    def setUp(self):
        pass

    def test_fit(self):
        pass

    def test_predict(self):
        pass

    def test_evaluate(self):
        pass

    def test_load_model(self):
        pass

    def test_save_model(self):
        pass

    def test_mpc_update_param(self):
        pass
