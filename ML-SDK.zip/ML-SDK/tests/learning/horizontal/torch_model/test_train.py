import unittest


class TestTrainingScript(unittest.TestCase):
    def setUp(self):
        pass

    def test_training(self):
        pass