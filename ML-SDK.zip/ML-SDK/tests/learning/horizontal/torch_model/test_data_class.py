import unittest


class TestDataClass(unittest.TestCase):
    def setUp(self):
        pass

    def test_PytorchDatasetg(self):
        pass
