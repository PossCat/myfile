import unittest
import numpy as np

from soterml.learning.horizontal.torch_model.process_data import (normalization,
                                                                  standardization,
                                                                  one_hot_encode,
                                                                  process_data)


class TestDataProcess(unittest.TestCase):
    def setUp(self):
        pass

    def test_normalization(self):
        test_data = np.array([10, 20, 30, 40, 50])
        test_result = normalization(test_data)
        expect = np.array([0., 0.25, 0.5, 0.75, 1.])
        assert((test_result == expect).all())

    def test_standardization(self):
        test_data = np.array([1,0,1,0])
        test_result = standardization(test_data)
        expect = np.array([ 1., -1.,  1., -1.])
        assert((test_result == expect).all())

    def test_one_hot_encode(self):
        test_data = np.array(['apple', 'banana', 'orange', 'banana', 'banana', 'orange'])
        test_result = one_hot_encode(test_data)
        expect = np.array([
            [1, 0, 0],
            [0, 1, 0],
            [0, 0, 1],
            [0, 1, 0],
            [0, 1, 0],
            [0, 0, 1]
        ])
        assert ((test_result == expect).all())

    def test_process_data(self):
        pass
