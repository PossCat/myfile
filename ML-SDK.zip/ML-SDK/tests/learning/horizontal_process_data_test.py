"""
this file is a test file of ml/learning/process_data.py
"""
import unittest
import numpy as np
import yaml
from soterml.learning.horizontal.torch_model import process_data
import torch.nn as nn
import torch.optim as optim


class TestProcessData(unittest.TestCase):
    def test_get_config_from_config_file(self):
        test_config_dict = {
            'data_config': {
                'feature_type': {
                    'numeric_features': 'Age Fare Pclass Parch SibSp',
                    'categorical_features': 'Sex', 'label':
                        'Survived'
                }, 'feature_process': {
                    'numeric_features': 'standardize',
                    'categorical_features': 'one-hot'},
                'batch_size': 64
            }, 'model_config': {
                'train_validate_split': [0.8, 0.2],
                'model_train_config': {
                    'learning_rate': 0.01,
                    'loss_fn': 'BCELoss',
                    'optimizer': 'Adam',
                    'epoch': 100
                }
            }
        }

        stream = open('test_config.yaml', 'w')
        yaml.dump(test_config_dict, stream)

        stream = open('test_config.yaml', 'r')
        config = yaml.load(stream)

        test_config_dict['data_config']['feature_process']['numeric_features'] \
            = process_data.standardization
        test_config_dict['data_config']['feature_process']['categorical_features'] \
            = process_data.one_hot_encode
        test_config_dict['model_config']['model_train_config']['loss_fn'] \
            = nn.BCELoss
        test_config_dict['model_config']['model_train_config']['optimizer'] \
            = optim.Adam

        print(test_config_dict)
        print(config)

        pass

    def test_normalization(self):
        test_data = np.array([10, 20, 30, 40, 50])
        test_result = process_data.normalization(test_data)
        pre_result = np.array([0., 0.25, 0.5, 0.75, 1.])
        assert((test_result == pre_result).all())

    def test_one_hot_encode(self):
        test_data = np.array(['apple', 'banana', 'orange', 'banana', 'banana', 'orange'])
        test_result = process_data.one_hot_encode(test_data)
        pre_result = np.array([
            [1, 0, 0],
            [0, 1, 0],
            [0, 0, 1],
            [0, 1, 0],
            [0, 1, 0],
            [0, 0, 1]
        ])
        assert((test_result == pre_result).all())

    # def test_standardization(self):
    #     test_data = np.array([20, 33, 17, 64, 72, 40])
    #     test_result = process_data.standardization(test_data)
    #     pre_result = np.array([-1.01428368, -0.38639378, -1.15918135, 1.11088213, 1.49727591, -0.04829922])
    #     print(test_result)
    #     print(pre_result)
    #     assert((test_result == pre_result).all())


if __name__ == '__main__':
    unittest.main()
