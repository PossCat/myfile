"""Tests aggregation functions in mpc status"""
import proto.mpc_message_pb2 as mpc_message
import proto.soterone_data_pb2 as soterone_data

import unittest
import logging
import mpc_status
import concurrent.futures
import time


class TestMPCStatus(unittest.TestCase):
    def setUp(self):
        logging.getLogger().setLevel(logging.DEBUG)

    def test_weight_avg_aggregation(self):
        """Test simple weight average aggregation function"""
        request1 = mpc_message.AggregationRequest(agg_type=mpc_message.AggregationRequest.WEIGHT_AVG,
                                                  gradients=[0.2, 0.4, 0.6], data_size=2)
        request2 = mpc_message.AggregationRequest(agg_type=mpc_message.AggregationRequest.WEIGHT_AVG,
                                                  gradients=[0.6, 1.2, 2.4], data_size=3)
        self.assertEqual([0.44, 0.88, 1.68],
                         [round(gradient, 2) for gradient in mpc_status.weight_avg_aggregation([request1, request2])])

    def test_one_party_aggregation_no_block(self):
        """Test one party aggregation with no blocking"""
        server_status = mpc_status.MPCServerStatus()
        query_uuid = "1"
        do_uuid1 = "DO1"
        epoch = 1
        query_cluster = soterone_data.QueryCluster(query_uuid=query_uuid,
                                                   do_nodes=[soterone_data.NodeInfo(uuid=do_uuid1)])
        # Add query cluster with on DO
        server_status.add_query_cluster(query_uuid, query_cluster)
        request1 = mpc_message.AggregationRequest(agg_type=mpc_message.AggregationRequest.WEIGHT_AVG,
                                                  do_uuid=do_uuid1,
                                                  query_uuid=query_uuid,
                                                  epoch=epoch,
                                                  gradients=[0.2, 0.4, 0.6], data_size=2)
        server_status.submit_gradients(request1)
        self.assertEqual([0.2, 0.4, 0.6], server_status.wait_or_aggregate(query_uuid, epoch))

    def test_two_parties_aggregation_block(self):
        """Test two threads sending request and doing aggregation"""
        server_status = mpc_status.MPCServerStatus()
        query_uuid = "1"
        do_uuid1 = "DO1"
        do_uuid2 = "DO2"
        epoch = 1
        query_cluster = soterone_data.QueryCluster(query_uuid=query_uuid,
                                                   do_nodes=[soterone_data.NodeInfo(uuid=do_uuid1),
                                                             soterone_data.NodeInfo(uuid=do_uuid2)])
        # Add query cluster with two DOs
        server_status.add_query_cluster(query_uuid, query_cluster)
        request1 = mpc_message.AggregationRequest(agg_type=mpc_message.AggregationRequest.WEIGHT_AVG,
                                                  do_uuid=do_uuid1,
                                                  query_uuid=query_uuid,
                                                  epoch=epoch,
                                                  gradients=[0.2, 0.4, 0.6], data_size=2)
        request2 = mpc_message.AggregationRequest(agg_type=mpc_message.AggregationRequest.WEIGHT_AVG,
                                                  do_uuid=do_uuid2,
                                                  query_uuid=query_uuid,
                                                  epoch=epoch,
                                                  gradients=[0.6, 1.2, 2.4], data_size=3)
        with concurrent.futures.ThreadPoolExecutor() as executor:
            # submit the first query
            server_status.submit_gradients(request1)
            future1 = executor.submit(server_status.wait_or_aggregate, query_uuid, epoch)
            time.sleep(2)

            # submit the second query after 2 seconds, make sure thread 1 is blocked
            server_status.submit_gradients(request2)
            future2 = executor.submit(server_status.wait_or_aggregate, query_uuid, epoch)
            aggregation_result2 = future2.result(timeout=5)
            self.assertEqual([0.44, 0.88, 1.68], [round(gradient, 2) for gradient in aggregation_result2])

            # assert two DOs get the same result
            aggregation_result1 = future1.result(timeout=1)
            self.assertEqual(aggregation_result1, aggregation_result2)

        # assert cleanup
        self.assertEqual(aggregation_result1, server_status.get_query_result(query_uuid, epoch))
        server_status.query_clean_up(query_uuid)
        self.assertTrue(server_status.get_query_result(query_uuid, epoch) is None)


if __name__ == '__main__':
    unittest.main()
