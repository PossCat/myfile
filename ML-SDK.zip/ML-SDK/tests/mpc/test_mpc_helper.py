"""
    test the mpc_helper.py
"""
import unittest
import grpc
from soterml.mpc.mpc_helper import register_mpc


class TestMpcHelper(unittest.TestCase):
    """
    test the mpc_helper.py
    """
    def setUp(self) -> None:
        """
        to do before testing
        you should start the SS first.If it isn't local, modify the localhost
        """
        self.channel = grpc.insecure_channel('localhost:9000',
                                             options=[
                                                 ('grpc.max_send_message_length', 5 * 1024 * 1024),
                                                 ('grpc.max_receive_message_length',
                                                  5 * 1024 * 1024),
                                             ],
                                             )

    def test_register_mpc(self):
        """
        test register_mpc to SS
        """
        mpc_info = {'uuid': 'mpcuuid',
                    'public_key': 'mpcpublic_key'
                    }
        node_info = {'uuid': 'node_infouuid',
                     'address': 'node_infoaddress',
                     'port': 'node_infoport'
                     }
        mpc_info['node_info'] = node_info
        res = register_mpc(self.channel, mpc_info)
        self.assertIsInstance(res.uuid, str)


if __name__ == '__main__':
    unittest.main()
