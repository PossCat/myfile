"""Test the functionality of the MPC server"""
import proto.mpc_message_pb2 as mpc_message
import proto.soterone_data_pb2 as soterone_data

import unittest
import mpc_server
import logging
import grpc
import mpc_client
import mpc_status
import mpc_chain


class TestMPCServer(unittest.TestCase):
    def setUp(self):
        logging.getLogger().setLevel(logging.DEBUG)

    def test_mpc_test_message(self):
        """Send two test message and one end message, should all success"""
        server = mpc_server.MPCServiceImpl()
        test_message1 = mpc_message.MPCConnectionRequest(
            test_message_request=mpc_message.TestMessageRequest(test_message="request1"))
        test_message2 = mpc_message.MPCConnectionRequest(
            test_message_request=mpc_message.TestMessageRequest(test_message="request2"))
        end_message = mpc_message.MPCConnectionRequest(
            end_message_request=mpc_message.EndMessageRequest())
        response_gen = server.MPCConnection([test_message1, test_message2, end_message],
                                            mpc_client.SimpleServicerContext())
        msg_index = 0
        for response in response_gen:
            if msg_index == 0:
                self.assertEqual("request1", response.test_message_response.test_message)
            elif msg_index == 1:
                self.assertEqual("request2", response.test_message_response.test_message)
            msg_index += 1

        # End message will not yield response
        self.assertEqual(2, msg_index)

    def test_mpc_unknown_message(self):
        """Send one unknown message one test message."""
        server = mpc_server.MPCServiceImpl()
        error_message = mpc_message.MPCConnectionRequest(unknown_message_request=mpc_message.UnknownMessageRequest())
        test_message1 = mpc_message.MPCConnectionRequest(
            test_message_request=mpc_message.TestMessageRequest(test_message="request1"))
        end_message = mpc_message.MPCConnectionRequest(
            end_message_request=mpc_message.EndMessageRequest())
        context = mpc_client.SimpleServicerContext()
        response_gen = server.MPCConnection([error_message, test_message1, end_message], context)
        msg_index = 0
        for response in response_gen:
            if msg_index == 0:
                self.assertTrue(response.HasField("unknown_message_response"))
                self.assertEqual(grpc.StatusCode.UNIMPLEMENTED, context.code)
                self.assertTrue("Request type not implemented" in context.details)
            elif msg_index == 1:
                self.assertEqual("request1", response.test_message_response.test_message)
            msg_index += 1

        self.assertEqual(2, msg_index)

    def test_aggregation_message(self):
        server_status = mpc_status.MPCServerStatus()
        query_uuid = "1"
        do_uuid1 = "DO1"
        epoch = 1
        query_cluster = soterone_data.QueryCluster(query_uuid=query_uuid,
                                                   do_nodes=[soterone_data.NodeInfo(uuid=do_uuid1)])
        # Add query cluster with on DO
        server_status.add_query_cluster(query_uuid, query_cluster)

        # Prepare server and send out request
        chain_worker = mpc_chain.MPCChainWorker(server_status)
        server = mpc_server.MPCServiceImpl(server_status, chain_worker)
        agg_request1 = mpc_message.AggregationRequest(agg_type=mpc_message.AggregationRequest.WEIGHT_AVG,
                                                      do_uuid=do_uuid1,
                                                      query_uuid=query_uuid,
                                                      epoch=epoch,
                                                      gradients=[0.2, 0.4, 0.6], data_size=2)
        connection_request = mpc_message.MPCConnectionRequest(
            agg_message_request=agg_request1)
        response_gen = server.MPCConnection([connection_request],
                                            mpc_client.SimpleServicerContext())

        # Make sure generator only has one value
        self.assertEqual([0.2, 0.4, 0.6], next(response_gen).agg_message_response.gradients)
        with self.assertRaises(StopIteration):
            next(response_gen)


if __name__ == '__main__':
    unittest.main()
