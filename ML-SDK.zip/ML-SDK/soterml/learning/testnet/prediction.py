"""
the file is a training script, it does the following:
1. monitor the chain and subscribe query events
2. get query info from SS
3. train raw model
4. complete query(return trained model)

to run this python file, you must:
1. down and install SoterOneService
2. down and install the chain
3. set address and port right, then start SS and chain
4. run "start_websocket_servers.py" to start websocket server
5. run this file

"""
import os
import time
import datetime
from binascii import unhexlify

import grpc
import syft
from grpc import Channel

from soterml.connection.proto import soterone_data_pb2, soterone_service_pb2
from soterml.learning.testnet.utils import *
from soterml.connection.chain import SoterOneChain
from soterml.connection.soterone import get_query_execution_info, test_model_completed
from soterml.learning.testnet.MNIST_MPC_websocket_parallel import predict
from soterml.learning.horizontal.torch_model.testnet_models import Net1, Net2


def prediction_workflow(chain, event):
    # type: (SoterOneChain, dict) -> ()
    """
    callback function
    :param chain: the chain that you monitor
    :param event: dict, includes some query request information submitted
    """
    print("The prediction event was successfully retrieved")
    channel = grpc.insecure_channel('132.232.36.171:11131',
                                    options=[
                                        ('grpc.max_send_message_length', 5 * 1024 * 1024),
                                        ('grpc.max_receive_message_length',
                                         5 * 1024 * 1024),
                                    ])

    bytes_str = unhexlify(event['queryUUID'][2:])
    query_uuid = bytes_str.decode(encoding='utf-8')

    bytes_str = unhexlify(event['predictionUUID'][2:])
    prediction_uuid = bytes_str.decode(encoding='utf-8')



    # get query info from SS
    prediction_info_and_nodes_info, model_path = get_query_execution_info(query_uuid, channel)

    # load model
    print(model_path)
    model = load_model_from_path(model_path)

    # test model
    predict(chain, prediction_uuid, model)

    test_model_completed(prediction_uuid, channel)
    # remove the model structure send by QC
    # if os.path.exists(model_path):
    #     os.remove(model_path)
    # else:
    #     print("The model structure send by QC is deleted")
