"""
the file is a training script, it does the following:
1. monitor the chain and subscribe query events
2. get query info from SS
3. train raw model
4. complete query(return trained model)

to run this python file, you must:
1. down and install SoterOneService
2. down and install the chain
3. set address and port right, then start SS and chain
4. run "start_websocket_servers.py" to start websocket server
5. run this file

"""
import os
import time
import datetime
from binascii import unhexlify

import grpc
import syft
from grpc import Channel

from soterml.connection.proto import soterone_data_pb2, soterone_service_pb2
from soterml.learning.testnet.utils import *
from soterml.connection.chain import SoterOneChain
from soterml.connection.soterone import get_query_info, query_completed
from soterml.learning.testnet.MNIST_MPC_websocket_parallel import train_model
from soterml.learning.horizontal.torch_model.testnet_models import Net1, Net2


def training_workflow(chain, event):
    # type: (SoterOneChain, dict) -> ()
    """
    callback function
    :param chain: the chain that you monitor
    :param event: dict, includes some query request information submitted
    """
    hook = syft.TorchHook(torch)
    trained_model_path = './tmp/model_uuid_completed'
    channel = grpc.insecure_channel('172.27.0.7:11131',
                                    options=[
                                        ('grpc.max_send_message_length', 5 * 1024 * 1024),
                                        ('grpc.max_receive_message_length',
                                         5 * 1024 * 1024),
                                    ])

    print("The listener event was successfully retrieved")
    bytes_str = unhexlify(event['queryUUID'][2:])
    query_uuid = bytes_str.decode(encoding='utf-8')
    print(query_uuid)

    # set start time of deal query request
    query_execution_info_dict = {'_uuid': query_uuid,
                                 'start_time_ns': int(time.time()),
                                 'finished_time_ns': 1,
                                 'status': 1}

    # get query info from SS
    query_info_and_nodes_info, model_path = get_query_info(query_uuid, channel)

    print(query_info_and_nodes_info.query_info.data_set)
    # get nodes info
    compute_nodes, mpc_nodes = \
        get_nodes_from_query_info(query_info_and_nodes_info, hook)

    do_uuids = get_do_uuid_from_info(query_info_and_nodes_info)

    # load model
    print(model_path)
    model = load_model_from_path(model_path)

    # train model and get trained model
    model_trained = train_model(chain,
                                query_uuid,
                                query_info_and_nodes_info,
                                compute_nodes,
                                model,
                                mpc_nodes)

    # set model_completed path
    filename_completed = trained_model_path + str(time.time()) + '.pt'
    save_model_to_path(model_trained, filename_completed)

    # query complete
    query_execution_info_dict['finished_time_ns'] = int(time.time())
    model_completed_path = os.path.abspath(filename_completed)

    for do_uuid in do_uuids:
        query_completed(do_uuid, model_completed_path,
                        channel, query_execution_info_dict)

    # # remove the model structure send by QC
    # if os.path.exists(model_path):
    #     os.remove(model_path)
    # else:
    #     print("The model structure send by QC is deleted")
    #
    # if os.path.exists(filename_completed):
    #     os.remove(filename_completed)
    # else:
    #     print("The model structure completed is deleted")
