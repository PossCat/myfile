from soterml.learning.vertical.utils import consts
from soterml.learning.vertical.workflow.logistic_regression.workflow_base import WorkflowBase, get_config_json
from soterml.learning.vertical.ml.param.param import PredictParam
from soterml.learning.vertical.ml.util.param_extract import ParamExtract


class MPCWorkflow(WorkflowBase):
    def __init__(self, local_config_path):
        super(MPCWorkflow, self).__init__(local_config_path, consts.MPC)

    def fit(self):
        self.model.fit()
        pass

    def predict(self):
        self.logger.debug("Starting predicting.")

        param_type = PredictParam()
        predict_params = ParamExtract.parse_param_from_config(param_type, self.model_config)

        predict_result = self.model.predict(data_instances=None, predict_param=predict_params)

        self.return_prediction_result(predict_result)
