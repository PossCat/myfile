import grpc

from soterml.learning.vertical.utils import consts
from soterml.learning.vertical.ml.logistic_regression import LRGuest, LRHost, LRMPC
from soterml.connection.chain import SoterOneChain, ChainEvent
from soterml.connection.soterone import get_query_info
from soterml.connection.soterone import download_file
from soterml.connection.soterone import upload_file
from soterml.connection.proto.grpc_service_pb2_grpc import SoteroneServiceStub
from soterml.learning.vertical.utils.party import Party
from soterml.connection.soterone import query_completed
from soterml.learning.vertical.utils.chain_log import decode_chain_str
from soterml.learning.vertical.utils.log import Logger, LogType, LogLevel


def get_config_json(config_path):
    import json
    with open(config_path, "r") as fin:
        config_json = json.loads(fin.read())
    return config_json


class WorkflowBase:
    def __init__(self, local_config_path, role):
        """
        """
        self.role = role
        self.local_config_path = local_config_path
        self.chain_event = None
        self.parties_map = None
        self.psi_res = None
        self.data_config = None
        self.model_config = None
        self.psi_res_path = None
        self.model = None
        self.grpc_channel = None
        self.query_uuid = None
        self.port = None
        self.node_uuid = None
        self.work_item = None

        self.model_path = None
        self.chain_event = None
        self.wallet_address = None
        self.chain = self._init_chain()
        self.grpc_stub = self._init_grpc()
        self.logger = Logger(type=LogType.LogisticRegressionWorkflow,
                             role=self.role,
                             level=LogLevel.DEBUG)

    def predict(self):
        pass

    def fit(self):
        pass

    def _run(self, chain, event):
        self.logger.debug("Get event from chain")
        self.chain_event = event
        self.query_uuid = self._get_query_uuid()
        # self.query_uuid = 'SQ_96dd6fd9-4647-4535-8c7f-678036609399'

        self.work_item = self._get_query_info_and_init()

        if self.work_item == 2:
            self.fit()
        elif self.work_item == 4:
            self.predict()

    def return_logistic_regression_result(self):
        if self.role != consts.MPC:
            # todo delete mock code

            model_summary = self.model.get_model_summary()
            model_path = './temp_data/' + self.role + "_" + self.query_uuid + "_lr_model.json"
            self.logger.debug("model_summary: {}".format(model_summary))
            import json

            with open(model_path, 'w') as file:
                file.write(json.dumps(model_summary))

            self.logger.debug("Write successfully")

            token = upload_file(node_uuid=self.wallet_address,
                                file_path=model_path,
                                stub=self.grpc_stub)

            self.logger.debug(self.role + " upload successfully")

            import time

            completed_info_dict = dict()
            completed_info_dict['node_uuid'] = self.node_uuid
            completed_info_dict['query_uuid'] = self.query_uuid
            completed_info_dict['result_token'] = token.token
            completed_info_dict['finish_time_ns'] = int(time.time())
            completed_info_dict['count'] = 0

            query_completed(query_completed_info_dict=completed_info_dict,
                            stub=self.grpc_stub)
            self.logger.info(self.role + " completed query successfully")

    def return_prediction_result(self, res):

        model_path = './temp_data/' + self.role + "_" + self.query_uuid + "_prediction_res.json"
        import json

        with open(model_path, 'w') as file:
            file.write(json.dumps(res.tolist()))

        self.logger.debug("Write successfully")

        token = upload_file(node_uuid=self.wallet_address,
                            file_path=model_path,
                            stub=self.grpc_stub)

        self.logger.debug(self.role + " upload successfully")

        import time

        completed_info_dict = dict()
        completed_info_dict['node_uuid'] = self.node_uuid
        completed_info_dict['query_uuid'] = self.query_uuid
        completed_info_dict['result_token'] = token.token
        completed_info_dict['finish_time_ns'] = int(time.time())
        completed_info_dict['count'] = 0

        query_completed(query_completed_info_dict=completed_info_dict,
                        stub=self.grpc_stub)
        print(self.role + " completed query successfully")

    def run(self):
        # monitor chain
        self.logger.debug("Workflow is running.")
        self.chain.subscribe(ChainEvent.QueryDispatched, self._run)
        print("OK")

        import time
        while True:
            time.sleep(10)

    def _init_chain(self):
        chain_config = self._get_local_config(self.local_config_path)
        self.chain_address = chain_config["CHAIN_ADDRESS"]
        self.wallet_address = chain_config[self.role]["wallet_address"]
        self.node_uuid = self.wallet_address
        self.chain_private_key = chain_config[self.role]["private_key"]

        chain = SoterOneChain(rpc_url=self.chain_address,
                              private_key=self.chain_private_key,
                              context={})
        return chain

    def _init_grpc(self):
        grpc_config = self._get_local_config(self.local_config_path)
        grpc_param = grpc_config["GRPC_ADDRESS"]
        grpc_stub = SoteroneServiceStub(grpc.insecure_channel(grpc_param))
        return grpc_stub

    def _get_local_config(self, config_path):
        if config_path is None:
            return None

        with open(self.local_config_path, 'r') as fin:
            import json
            config = json.loads(fin.read())
        return config

    def _get_query_uuid(self):
        return decode_chain_str(self.chain_event['uuid'])

    def _init_parties_map(self, nodes_info, do_uuid):
        parties_map = dict()

        for node in nodes_info.nodeInfo:
            if do_uuid != node.node_uuid:
                if node.node_type == 1:
                    role = consts.GUEST
                elif node.node_type == 2:
                    role = consts.MPC
                else:
                    role = consts.HOST
                party = Party(role=role, idx=0, wallet_address=node.node_uuid)
                parties_map[party] = node.address + ":" + node.port
            else:
                self.port = node.port
        return parties_map

    def _get_psi_res(self):
        path = './data/breast_a.csv'
        import pandas as pd
        df = pd.read_csv(path)
        return list(df['id'])

    def _get_query_info_and_init(self):
        res = get_query_info(self.query_uuid,
                             self.wallet_address,
                             self.grpc_stub)
        self.logger.debug("Get query info from SS.")
        if res is None:
            raise RuntimeError(self.role + self.query_uuid + " res is none.")

        self.parties_map = self._init_parties_map(res.query_cluster, self.node_uuid)
        self.logger.debug("Init parties map successfully.")
        self.psi_res = self._get_psi_res()
        self.logger.debug("get psi res successfully.")
        self._download_file(res)
        self.logger.debug("Init config successfully.")
        self.model = self._init_model()
        self.logger.debug("Init model successfully.")

        return res.query_info.query_type

    def _download_file(self, res):
        model_config_path = './temp_data/' + self.role + self.query_uuid + "model_config.json"
        data_config_path = './temp_data/' + self.role + self.query_uuid + "data_config.json"
        psi_result_path = './temp_data/' + self.role + self.query_uuid + "psi_result.txt"
        model_path = None
        download_file(node_uuid=self.node_uuid,
                      token=res.query_info.model_config_token,
                      stub=self.grpc_stub,
                      file_path=model_config_path)
        download_file(node_uuid=self.node_uuid,
                      token=res.query_info.data_config_token,
                      stub=self.grpc_stub,
                      file_path=data_config_path)
        download_file(node_uuid=self.node_uuid,
                      token=res.query_info.psi_result.result_token,
                      stub=self.grpc_stub,
                      file_path=psi_result_path)
        if res.query_info.query_type == 4 and self.role != consts.MPC:
            model_path = './temp_data/' + self.role + self.query_uuid + "model.json"
            download_file(node_uuid=self.node_uuid,
                          token=res.query_info.vertical_learning_training.model_token,
                          stub=self.grpc_stub,
                          file_path=model_path)

        self.model_config = model_config_path
        self.data_config = data_config_path
        self.psi_res_path = psi_result_path
        self.model_path = model_path

    def _init_model(self):
        if self.role == consts.MPC:
            model = LRMPC(chain=self.chain,
                          chain_event=self.chain_event,
                          parties_map=self.parties_map,
                          model_config=self.model_config,
                          port=self.port,
                          wallet_address=self.wallet_address,
                          psi_res=self.psi_res)
        elif self.role == consts.HOST:
            model = LRHost(chain=self.chain,
                           chain_event=self.chain_event,
                           parties_map=self.parties_map,
                           model_config=self.model_config,
                           port=self.port,
                           wallet_address=self.wallet_address)
        elif self.role == consts.GUEST:
            model = LRGuest(chain=self.chain,
                            chain_event=self.chain_event,
                            parties_map=self.parties_map,
                            model_config=self.model_config,
                            port=self.port,
                            wallet_address=self.wallet_address)
        else:
            raise Exception("The role name can not be identified.")

        return model



