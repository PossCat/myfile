import numpy as np

from soterml.learning.vertical.utils import consts
from soterml.learning.vertical.workflow.logistic_regression.workflow_base import WorkflowBase, get_config_json
from soterml.learning.vertical.ml.util.reader import Reader
from soterml.learning.vertical.ml.util.param_extract import ParamExtract
from soterml.learning.vertical.ml.param.param import PredictParam


class GuestWorkflow(WorkflowBase):
    def __init__(self, local_config_path):
        super(GuestWorkflow, self).__init__(local_config_path, consts.GUEST)

        self.reader = None

    def fit(self):
        self.reader = Reader(chain=None, role=self.role, idx=0, data_io_config=self.data_config)

        data_instances = self.reader.get_data_instances()

        self.model.fit(data_instances)

        import time
        time.sleep(1)
        self.return_logistic_regression_result()

    def predict(self):
        self.logger.debug("Starting predicting.")
        self.reader = Reader(chain=None, role=self.role, idx=0, data_io_config=self.data_config)
        self.logger.debug('Loading data successfully.')

        model_summary = get_config_json(self.model_path)

        self.model.coef_ = np.array(model_summary['w'])
        self.model.intercept_ = 0

        data_instances = self.reader.get_data_instances()

        param_type = PredictParam()
        predict_params = ParamExtract.parse_param_from_config(param_type, self.model_config)

        self.model.predict(data_instances=data_instances, predict_param=predict_params)

        self.logger.debug("End prediction")
