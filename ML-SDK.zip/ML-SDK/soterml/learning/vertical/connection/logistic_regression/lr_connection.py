import logging
import time
from concurrent import futures
from queue import Queue
from threading import Thread

import grpc
import numpy
import phe
from soterml.connection.chain import SoterOneChain, ChainEvent, NodeType
from soterml.learning.vertical.config.CONFIG import CHAIN_ADDRESS
from soterml.learning.vertical.connection.base_connection.base_connection import \
    BaseVerticalConnection
from soterml.learning.vertical.connection.logistic_regression.lr_client import \
    LogisticRegressionGrpcClient
from soterml.learning.vertical.ml.secure_protocol.paillier_encryptor import PaillierEncryptor
from soterml.learning.vertical.proto import LogisticRegression_pb2_grpc
from soterml.learning.vertical.utils.consts import HOST, GUEST, MPC
from soterml.learning.vertical.utils.chain_log import Log, LogLevel
from soterml.learning.vertical.utils.grpc_client_server_threading import GrpcServerThreading, \
    GrpcClientThreading
from soterml.learning.vertical.connection.logistic_regression.lr_server import \
    LogisticRegressionGrpcServer
from soterml.learning.vertical.utils.message_type import MessageType
from soterml.learning.vertical.utils.party import Party
from soterml.learning.vertical.utils.chain_log import decode_chain_str


class LogisticConnection(BaseVerticalConnection):
    """
    for vertical lr trainning, it includes the get and remote functions...
    """

    def __init__(self, port: int, party: Party, party_map: dict, query_uuid: str,
                 sc: SoterOneChain):
        self.Log = Log(chain_log_level=LogLevel.One, sc=sc)
        self.chain = sc
        self.chain.subscribe(ChainEvent.ServerReady, self.callback_server_ready)
        time.sleep(2)
        self.logger = self.Log.get_logger()
        self.connection_pool = {}
        self.party = party

        self.query_uuid = query_uuid
        self.ready_server_queue = Queue()
        self.init_connections(port, party_map)
        # t = Thread(target=self.init_connections, args=(port, party_map))
        # t.start()

    def check_type(self, obj: object, obj_type: MessageType):
        """

        :param obj: data
        :param obj_type:  the type that the data should be
        :type obj_type: Enum
        """

        if obj_type == MessageType:
            return isinstance(obj, obj_type)
        elif obj_type == MessageType.pub_key or obj_type == MessageType.loss_regular or \
                obj_type == MessageType.loss:
            return isinstance(obj, phe.paillier.EncryptedNumber)
        elif obj_type == MessageType.forward_intermediate_parameter:
            return isinstance(obj[0], numpy.ndarray) and isinstance(obj[1], numpy.ndarray)
        elif obj_type == MessageType.fore_gradient or obj_type == MessageType.gradient:
            return isinstance(obj, numpy.ndarray)
        elif obj_type == MessageType.is_stop:
            return isinstance(obj, bool)
        elif obj_type == MessageType.optim_loss:
            return isinstance(obj, float)
        else:
            raise TypeError('Type not implemented!!!')

    def callback_server_ready(self, chain, event):
        self.ready_server_queue.put(event)

    def init_connections(self, port: int, party_map: dict):
        """
        example:
        {party1:'192.168.0.1:1234', party2:'192.168.0.2:1234'}
        :param port: the server port
        :type port: int
        :param party_map: party to address
        :type party_map: dict
        """
        self.logger.info('Initing the connections.')

        server = grpc.server(futures.ThreadPoolExecutor(max_workers=8))
        my_server = LogisticRegressionGrpcServer(party_map)
        LogisticRegression_pb2_grpc.add_LRServicerServicer_to_server(
            my_server, server)
        server.add_insecure_port('[::]:' + str(port))
        Server = GrpcServerThreading(server, my_server)
        Server.start()
        node_type = NodeType.MPC if self.party.role == MPC else NodeType.DO
        import time
        # time.sleep(1)
        print('Server start:', self.query_uuid)
        self.chain.server_start_listening(query_uuid=self.query_uuid, node_type=node_type)
        self.connection_pool['server'] = Server

        import time
        # time.sleep(1)
        ready_server_num = 0
        while True:
            time.sleep(1)
            if not self.ready_server_queue.empty():
                event = self.ready_server_queue.get()
                if decode_chain_str(event['queryUUID']) == self.query_uuid:
                    for party in party_map:
                        if party.wallet_address.lower() == event['nodeAddr'].lower():
                            print('(Will connect Server)GET EVENT:', event)
                            client = LogisticRegressionGrpcClient(server_address=party_map[party])
                            Client = GrpcClientThreading(client)
                            Client.start()
                            self.connection_pool[party] = Client
                            ready_server_num = ready_server_num + 1
                if ready_server_num == len(party_map):
                    break
        # # create client for each connection with other server, and put them in the dict
        # for party, address in party_map.items():
        #     client = LogisticRegressionGrpcClient(server_address=address)
        #     Client = GrpcClientThreading(client)
        #     Client.start()
        #     self.connection_pool[party] = Client


# just for test, it will be moved after
if __name__ == '__main__':
    # import time
    # import pickle
    # from soterml.learning.vertical.connection.logistic_regression.lr_connection import \
    #     LogisticConnection
    # from soterml.learning.vertical.utils.message_type import MessageType
    #
    from run.standlone_lr_script import RegisterALL, CHAIN_ADDRESS
    RegisterALL()
    host = Party(HOST, 0, '0xFc805EDd43C76B569c00D998Fe1E74E60aF31213')
    guest = Party(GUEST, 0, '0x40A680e0461f5888Ea4Af71fc3d137cF9aa0f18C')
    mpc = Party(MPC, 0, '0x4860a1F0488119D1e858FFf94Ce2A2DD6E02954e')

    do1_chain = SoterOneChain(CHAIN_ADDRESS,
                              'ed587757a0ce2b5a6b21b8b5e72be2646ad80122a638539c9420b6b9cb9e0638',
                              {})
    do2_chain = SoterOneChain(CHAIN_ADDRESS,
                              '123c60a2b70bf9afd139a61bfad18fd1d113789a388c5709f5dd00cd0397ed0c',
                              {})
    mpc_chain = SoterOneChain(CHAIN_ADDRESS,
                              'cad0aa81610e0ae58edd7add1188d8bfb8730633efedab7a6fd7560136936231',
                              {})

    LR_HOST = LogisticConnection(port=10081, party=host, party_map={guest: 'localhost:10082',
                                                                    mpc: 'localhost:10083'},
                                 sc=do1_chain,
                                 query_uuid='SQ_d1034941-b212-4c23-92f7-68f3b3ac7805')
    LR_GUEST = LogisticConnection(port=10082, party=guest, party_map={host: 'localhost:10081',
                                                                      mpc: 'localhost:10083'},
                                  sc=do2_chain,
                                  query_uuid='SQ_d1034941-b212-4c23-92f7-68f3b3ac7805')
    LR_MPC = LogisticConnection(port=10083, party=mpc, party_map={guest: 'localhost:10082',
                                                                  host: 'localhost:10081'},
                                sc=mpc_chain, query_uuid='SQ_d1034941-b212-4c23-92f7-68f3b3ac7805')
    #
    # test = (numpy.array([1, 2, 3]))
    # # print(pubkey)mn

    LR_GUEST.remote(1.92, MessageType.optim_loss, HOST, 0)
    LR_GUEST.remote(-10.1, MessageType.optim_loss, MPC, 0)
    para = LR_HOST.get(MessageType.optim_loss, GUEST, 0)
    para1 = LR_MPC.get(MessageType.optim_loss, GUEST, 0)

    # print('host receive:', para)
    # print('mpc receive:', para1)
    from soterml.connection.chain import SoterOneChain, ChainEvent

    # from soterml.learning.vertical.config.CONFIG import CHAIN_ADDRESS, CHAIN_PRIVATE_KEY
    # import time
    # #
    # sc = SoterOneChain(CHAIN_ADDRESS, CHAIN_PRIVATE_KEY, {})
    #
    #
    # def pp(chain, event):
    #     print('233')
    #
    #
    # sc.subscribe(ChainEvent.LogAdded, pp)
    # sc.add_log('asdasdsaq', {'log': 'sdasada'})
    #
    # time.sleep(6)
    # sc.shutdown(wait=True)
    pass
