import pickle
from soterml.mpc.p2p_connection_base_client import P2PConnectionClient
from soterml.learning.vertical.proto.LogisticRegression_pb2_grpc import LRServicerStub
from soterml.learning.vertical.proto.LogisticRegression_pb2 import LRConnectionRequest, \
    SendPubKeyRequest, ForwardIntermediateParameter, ForeGradient, Gradient, LossRegular, Loss, \
    IsStop, OptimLoss
# from soterml.learning.vertical.utils.log import Log
from soterml.learning.vertical.utils.message_type import MessageType

from phe.paillier import EncryptedNumber


class LogisticRegressionGrpcClient(P2PConnectionClient):
    """
    LR grpc client
    """

    def __init__(self, server_address: str):
        super(LogisticRegressionGrpcClient, self).__init__(server_address)
        self._stub = LRServicerStub(self._channel)
        # self._log = Log(__name__).getlog()

    def _serve(self):
        response_iterator = self._stub.LRConnection(self._process_events())
        try:
            for response in response_iterator:
                # self._log.info('Got an event response ' + str(response))
                self._response_queue.put(response)
        except Exception as err:
            # self._log.error("Encountering an error in the serving thread" + str(err))
            raise

    def close(self):
        """
        wait for response_queue and request_queue is empty
        """
        super(LogisticRegressionGrpcClient, self).close()

    # send data, call rpc function according to the object's type
    def remote(self, obj: object, obj_type: MessageType):
        """
        :param obj: data object
        :param obj_type:  data type defined in MessageType
        :type obj_type: Enum
        """
        if obj_type not in MessageType:
            raise TypeError("Error data type!")

        if obj_type == MessageType.pub_key:
            obj_bytes = pickle.dumps(obj)
            self.send_request(
                LRConnectionRequest(
                    pub_key=SendPubKeyRequest(data=obj_bytes)
                )
            )
        elif obj_type == MessageType.forward_intermediate_parameter:
            obj_bytes = pickle.dumps(obj)
            self.send_request(
                LRConnectionRequest(
                    forward_intermediate_parameter=ForwardIntermediateParameter(data=obj_bytes)
                )
            )
        elif obj_type == MessageType.fore_gradient:
            obj_bytes = pickle.dumps(obj)
            self.send_request(
                LRConnectionRequest(
                    fore_gradient=ForeGradient(data=obj_bytes)
                )
            )
        elif obj_type == MessageType.gradient:
            obj_bytes = pickle.dumps(obj)
            self.send_request(
                LRConnectionRequest(
                    gradient=Gradient(data=obj_bytes)
                )
            )
        elif obj_type == MessageType.loss_regular:
            obj_bytes = pickle.dumps(obj)
            self.send_request(
                LRConnectionRequest(
                    loss_regular=LossRegular(data=obj_bytes)
                )
            )
        elif obj_type == MessageType.loss:
            obj_bytes = pickle.dumps(obj)
            self.send_request(
                LRConnectionRequest(
                    loss=Loss(data=obj_bytes)
                )
            )
        elif obj_type == MessageType.is_stop:
            obj_bytes = pickle.dumps(obj)
            self.send_request(
                LRConnectionRequest(
                    is_stop=IsStop(data=obj_bytes)
                )
            )
        elif obj_type == MessageType.optim_loss:
            obj_bytes = pickle.dumps(obj)
            self.send_request(
                LRConnectionRequest(
                    optim_loss=OptimLoss(data=obj_bytes)
                )
            )
        else:
            # todo: send rpc request according to the messagetype
            pass
