from queue import Queue
import pickle
from soterml.learning.vertical.proto.LogisticRegression_pb2_grpc import LRServicerServicer
# from soterml.learning.vertical.utils.log import Log
from soterml.learning.vertical.utils.message_type import MessageType
from soterml.learning.vertical.utils.consts import MPC, HOST, GUEST
from soterml.learning.vertical.utils.party import Party
from soterml.mpc.p2p_connection_base_server import P2PConnectionServer
from phe.paillier import EncryptedNumber

class LogisticRegressionGrpcServer(P2PConnectionServer, LRServicerServicer):
    """
    LR grpc server
    """

    def __init__(self, party_map: dict):
        # self.logger = Log(__name__).getlog()
        # for converting ip:port to role
        self.party_map_reverse = dict(
            zip([i.split(':')[0] for i in party_map.values()], party_map.keys()))

        # a client's requests are in a request queue,  all clients' requests make up a dict
        self.requests_queue_dict = {}
        # create requests queue for each party
        for party in party_map:
            self.requests_queue_dict[party] = Queue()

    def LRConnection(self, request_iterator, context):
        """
        receive all requests and save them in self.requests_queue_dict
        :param request_iterator: requests
        :param context: the contxt of the request including the client's ip and port
        """
        # self.logger.info('LR Server built a streaming connection with remote')
        for per_request in request_iterator:
            # get client's ip port from grpc context
            # print('&&&&&&&&&&&&&&&&', context._rpc_event.call_details.host.decode('utf8'))
            # request_addr = context._rpc_event.call_details.host.decode('utf8').split(':')[0]
            # if request_addr not in self.party_map_reverse.keys():
            #     raise Exception('Error client IP!')
            #
            # self.requests_queue_dict[self.party_map_reverse[request_addr]].put(per_request)
            import pickle
            req_type = str(per_request.WhichOneof('message_one_of'))
            party = pickle.loads(getattr(per_request, req_type).data)[1]

            self.requests_queue_dict[party]\
                .put([req_type, pickle.loads(getattr(per_request, req_type).data)[0]])

    # get data from the queue according the object type and the role + idx
    def get(self, obj_type: MessageType, role: str, idx: int):
        """
        :param obj_type: the type of data you want to get
        :type obj_type: MessageType
        :param role: which role you want to get data from
        :type role: Role
        :param idx: the index of the role
        :type idx: int
        :return: the rpc request you want to get
        """
        requests_queue = self.requests_queue_dict[Party(role, idx)]
        # todo: judge which I want to get or directly get one request from the queue then validate
        req = requests_queue.get()
        # req_type = str(req.WhichOneof('message_one_of'))
        if req[0] != obj_type.name:
            raise TypeError('Get error type request!')
        else:
            return req[1]
        # elif req[0] == MessageType.pub_key.name:
        #     # pub_key = pickle.loads(req.pub_key.pub_key)
        #     return req[1]
        # elif req[0] == MessageType.forward_intermediate_parameter.name:
        #     # para = pickle.loads(req.forward_intermediate_parameter.para)
        #     return req[1]
        # elif req[0] == MessageType.fore_gradient.name:
        #     return req[1]
        # elif req[0] == MessageType.gradient:
        #     return req[1]
        # else:
        #     # todo: handle the request then return or return directly?
        #     return req[1]

