from enum import Enum

from soterml.learning.vertical.utils.consts import MPC, HOST, GUEST
from soterml.learning.vertical.utils.party import Party
from soterml.learning.vertical.utils.message_type import MessageType
from soterml.learning.vertical.ml.secure_protocol.paillier_encryptor import PaillierEncryptor


class BaseVerticalConnection:
    """
    All ML class will implement it
    """

    def __init__(self, port: int, party_map: dict):
        # create connections, it includes a server and some clients.
        # each client connection with a server(arbiter or gust or host1, host2......)
        pass

    def remote(self, obj, obj_type: MessageType, role: str, role_idx: int):
        """
        send data to the role using connection_pools's client
        """
        if not self.check_type(obj, obj_type):
            raise
        client = self.connection_pool[Party(role, role_idx)].get_client()
        client.remote((obj, self.party), obj_type)

    def get(self, obj_type: MessageType, role: str, role_idx: int):
        """
        receive data
        """
        if not self.check_type(obj_type, MessageType):
            raise
        server = self.connection_pool['server'].get_server()
        return server.get(obj_type, role, role_idx)

    # It is implemented in subcalss
    def init_connections(self, port: int, party_map: dict):
        """
        example:
        {party1:'192.168.0.1:1234', party2:'192.168.0.2:1234'}
        :param port: server port
        :type port: int
        :param party_map: dict that party to address
        :type party_map: dict
        """
        # logger = Log(__name__).getlog()
        # logger.info('Initing the connections.')
        # connections_pool = {}
        # for party, address in party_map.items():
        #     pass
        #
        # return {}
        pass

    def clean_threading(self):
        """
        clean all threading after lr trainning is over
        """
        # for k in self.connection_pools:
        #     self.connection_pools[k].join()
        print('All threading is over!')

    def check_type(self, obj: object, obj_type: MessageType):
        """

        :param obj: data
        :param obj_type:  the type that the data should be
        :type obj_type: Enum
        """
        # return isinstance(obj, obj_type)
        return True



