from enum import Enum


class MessageType(Enum):
    """
    Message type of secure boost algorithm.
    """
    public_key = 1
    loss = 2