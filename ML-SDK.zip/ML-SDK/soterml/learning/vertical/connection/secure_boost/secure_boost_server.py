from concurrent import futures
from queue import Queue
import time

import grpc

from soterml.learning.vertical.utils import consts
from soterml.learning.vertical.connection.secure_boost import secure_boost_pb2
from soterml.learning.vertical.connection.secure_boost import secure_boost_pb2_grpc


class SecureBoostServer(secure_boost_pb2_grpc.FederationServicer):
    def __init__(self, role_and_role_index_list, time_out=600):
        self.role_and_role_index_list = role_and_role_index_list
        self.get_queue = self._init_get_queue()
        self.time_out = time_out

    def transfer(self, request_iterator, context):
        for msg in request_iterator:
            self.get_queue[msg.role][msg.role_index].put(item=msg)
        return secure_boost_pb2.signal()

    def connect(self, request, context):
        return secure_boost_pb2.signal()

    def _init_get_queue(self):
        get_queue = {consts.HOST: {}, consts.GUEST: {}, consts.MPC: {}}
        for role_and_role_index in self.role_and_role_index_list:
            role = role_and_role_index[0]
            role_index = role_and_role_index[1]
            get_queue[role][role_index] = Queue(maxsize=10)
        return get_queue

    def get(self, role, role_index):
        if role_index not in self.get_queue[role]:
            raise ValueError("Role and role_index do not match.")
        wait_time = 0
        while wait_time < self.time_out:
            # wait if queue is empty else return
            if self.get_queue[role][role_index].empty():
                time.sleep(1)
                wait_time = wait_time + 1

            else:
                data = self.get_queue[role][role_index].get()
                return data

        return None


class Server:
    def __init__(self, insecure_port, role_and_role_index_list, max_workers=10):
        self.server = grpc.server(futures.ThreadPoolExecutor(max_workers=max_workers))
        self.server_val = SecureBoostServer(role_and_role_index_list)
        secure_boost_pb2_grpc.add_FederationServicer_to_server(self.server_val,
                                                               self.server)
        self.server.add_insecure_port('[::]:' + insecure_port)
        self.is_close = False

    def start(self):
        self.server.start()
        while self.is_close is False:
            time.sleep(1)

    def get(self, role, role_index):
        return self.server_val.get(role, role_index)

    def shutdown(self):
        self.is_close = True
