import pickle

import grpc

from soterml.learning.vertical.connection.secure_boost import secure_boost_pb2
from soterml.learning.vertical.connection.secure_boost import secure_boost_pb2_grpc


class Client:
    def __init__(self, server_address, reconnection_times=5):
        self.server_address = server_address
        self.reconnection_times = reconnection_times
        self.channel = grpc.insecure_channel(server_address)
        self.stub = None

    def transfer(self, msg):
        msg_stream = Client.bytes_stream(msg)
        response = self.stub.transfer(msg_stream)
        return response

    def build_connection(self):
        import time
        times = 0
        self.stub = secure_boost_pb2_grpc.FederationStub(channel=self.channel)
        while times < self.reconnection_times:
            try:
                self.stub.connect(secure_boost_pb2.signal(status=True))
                return True
            except:
                print("Failed to connect {}. Trying to connect...".format(self.server_address))
                time.sleep(1)
                times = times + 1
        print("Failed to connect {}. The maximum number of reconnections has been reached.".format(self.server_address))
        return False

    @staticmethod
    def bytes_stream(message):
        iter_generator = [message]
        for obj in iter_generator:
            yield obj
