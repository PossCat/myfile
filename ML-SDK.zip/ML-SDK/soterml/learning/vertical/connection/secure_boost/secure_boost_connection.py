from concurrent.futures import ThreadPoolExecutor, as_completed
import pickle

from soterml.learning.vertical.utils import consts
from soterml.learning.vertical.connection.secure_boost.secure_boost_server import Server
from soterml.learning.vertical.connection.secure_boost.secure_boost_client import Client
from soterml.learning.vertical.connection.secure_boost.message_type import MessageType
from soterml.learning.vertical.connection.secure_boost import secure_boost_pb2


class SecureBoostConnection:
    def __init__(self, parties_map, role, role_index, port):
        self.parties_map = parties_map
        self.server = None
        self.port = port
        self.clients = {consts.HOST: {}, consts.GUEST: {}, consts.MPC: {}}
        self.connection_pool = ThreadPoolExecutor(max_workers=10)
        self.role = role
        self.role_index = role_index

        self._init_connection()

    def remote(self, obj, obj_type, role, role_index):
        """
        Remote obj to other nodes.
        @param obj: Serializable object.
        @param obj_type: type in MessageType.
        @param role: consts.HOST, consts.GUEST or consts.MPC.
        @param role_index: int.
        @return: None
        """
        # if obj_type not in MessageType.__members__.values():
        msg_type = -1
        for key, value in enumerate(MessageType):
            if obj_type == value:
                msg_type = key
                break
        if msg_type == -1:
            raise ValueError("obj_type {} not in MessageType.".format(obj))

        msg = secure_boost_pb2.msg(data=pickle.dumps(obj),
                                   type=msg_type,
                                   role=self.role,
                                   role_index=self.role_index)



        self.clients[role][role_index].transfer(msg=msg)

    def get(self, obj_type, role, role_index):
        """
        Get obj from other nodes.
        @param obj_type:
        @param role:
        @param role_index:
        @return:
        """
        msg = self.server.get(role, role_index)

        msg_type = None
        for key, value in enumerate(MessageType):
            if msg.type == key:
                msg_type = value
                break

        # raise error if obj_type not in MessageType
        if obj_type != msg_type or msg_type is None:
            raise KeyError("Get error type from msg.")
        data = pickle.loads(msg.data)
        return data

    def close(self):
        self.server.shutdown()

    def _init_connection(self):
        """
        Init grpc connection.
        1. Boost server.
        2. Connect other server of nodes.
        @return:
        """
        role_and_role_index_list = list()
        for party in self.parties_map.keys():
            role_and_role_index_list.append((party.role, party.idx))

        # server
        try:
            self.server = Server(max_workers=10,
                                 insecure_port=str(self.port),
                                 role_and_role_index_list=role_and_role_index_list)
            self.connection_pool.submit(self.server.start)
        except Exception as e:
            raise ConnectionError('Role: {}, '
                                  'role_index: {} '
                                  'server failed to boost. '
                                  'Exception: {}\n'.format(self.role,
                                                           self.role_index,
                                                           e))

        # clients
        client_connection_task_list = list()
        for party in self.parties_map.keys():
            role = party.role
            role_index = party.idx

            client = Client(server_address=self.parties_map[party], reconnection_times=5)
            self.clients[role][role_index] = client

            # client connect to server
            task = self.connection_pool.submit(self.clients[role][role_index].build_connection)
            client_connection_task_list.append(task)

        # raise error if any client failed
        for task in as_completed(client_connection_task_list):
            if not task.result():
                self.close()
                raise ConnectionError("Failed connect to all address")
        return True