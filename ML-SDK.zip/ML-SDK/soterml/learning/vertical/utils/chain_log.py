import logging
import os
import time
from enum import Enum
from concurrent import futures
from concurrent.futures import ThreadPoolExecutor
from soterml.learning.vertical.config.CONFIG import CHAIN_ADDRESS, CHAIN_PRIVATE_KEY
from soterml.connection.chain import SoterOneChain, ChainEvent
from queue import Queue
import traceback
from binascii import unhexlify


class LogLevel(Enum):
    """
    chain log level
    """
    One = 1
    Two = 2
    Three = 3
    Four = 4
    Five = 5
    Local = 999


def  decode_chain_str(data: str):
    return (unhexlify(data[2:])).decode('utf8')


class Log:
    """
    for ML to add log into the chain
    """

    def __init__(self, chain_log_level: LogLevel, local_log_level=logging.DEBUG, sc=None):
        if not isinstance(chain_log_level, LogLevel):
            raise ValueError("Please set right log_level!")

        self._sc = sc
        # if sc == None:
        #     try:
        #         self._sc = SoterOneChain(chain_addr, chain_private_key, {})
        #     except:
        #         raise
        # else:
        #     self._sc = sc

        self._local_log_level = local_log_level
        self._logger = logging.getLogger(__name__)
        self._logger.setLevel(logging.DEBUG)
        self.log_time = time.strftime("%Y_%m_%d")
        file_dir = os.getcwd() + '/../log'
        if not os.path.exists(file_dir):
            os.mkdir(file_dir)
        self.log_path = file_dir
        self.log_name = self.log_path + "/" + self.log_time + '.log'
        self._fh = logging.FileHandler(self.log_name, encoding='utf-8')
        self._fh.setLevel(local_log_level)
        formatter = logging.Formatter(
            '[%(asctime)s] %(filename)s->%(funcName)s line:%(lineno)d \t[%(levelname)s]\t%('
            'message)s')
        self._fh.setFormatter(formatter)
        self._logger.addHandler(self._fh)

        # self._sc.subscribe(ChainEvent.LogAdded, cb)
        self._executor = ThreadPoolExecutor(max_workers=8)
        self._chain_log_level = chain_log_level

    def add_chain_log(self, log: dict, query_uuid: str, level: LogLevel):
        """

        :param log:
        :type log:
        :param query_uuid:
        :type query_uuid:
        :param level:
        :type level:
        """
        if self._chain_log_level.value > level.value:
            pass
        else:
            try:
                self._sc.add_log(query_uuid, log)
                # self._executor.submit(self._sc.add_log, query_uuid, log)
            except:
                traceback.print_exc()

    def get_logger(self):
        return self._logger

    def close(self):
        """

        """
        # default wait = True, shutdown until all tasks are completed
        self._logger.removeHandler(self._fh)
        self._executor.shutdown()
        self._sc.shutdown()


# if __name__ == '__main__':
#     chain_log = ChainLog(LogLevel.Three)
#     # chain_log.add_log({'test': '123'}, 'sadsadasdas', LogLevel.Five)
#     # chain_log.add_log({'test': '124'}, 'sadsadasdas', LogLevel.Five)
#     # chain_log.add_log({'test': '125'}, 'sadsadasdas', LogLevel.Five)
#     # chain_log.add_log({}, 'sad', LogLevel.Two)
#     # chain_log.add_log({}, 'sad', LogLevel.Three)
#     chain_log.add_local_log('1234')
#     chain_log.add_local_log('5678')
#     chain_log.close()
#
#     import time

# time.sleep(10)
def pp(chain, event):
    print('abcd')


if __name__ == '__main__':
    _sc = SoterOneChain(CHAIN_ADDRESS, CHAIN_PRIVATE_KEY, {})
    _sc.subscribe(ChainEvent.LogAdded, pp)

    _sc.add_log('asdasda', {'adsa': 'dasdasd'})

    time.sleep(6)
