import time
from threading import Thread

import grpc

from soterml.mpc.p2p_connection_base_client import P2PConnectionClient


class GrpcServerThreading(Thread):
    """
    grpc server threading for connections pool
    """

    def __init__(self, grpc_server: grpc.server, my_server: object):
        super(GrpcServerThreading, self).__init__()
        self.grpc_server = grpc_server
        self.my_server = my_server

    def run(self) -> None:
        self.grpc_server.start()
        try:
            while True:
                time.sleep(1)
        except Exception:
            raise

    def get_server(self):
        try:
            return self.my_server
        except Exception:
            raise


class GrpcClientThreading(Thread):
    """
    grpc server threading for connections pool
    """

    def __init__(self, grpc_client: P2PConnectionClient):
        super(GrpcClientThreading, self).__init__()
        self.client = grpc_client

    def run(self) -> None:
        """
        start the client
        """
        self.client.start()

    def get_client(self):
        try:
            return self.client
        except Exception:
            raise
