import os

# Role
MPC = "MPC"
HOST = "HOST"
GUEST = "GUEST"

# Updater
L1_PENALTY = "L1"
L2_PENALTY = "L2"

# data path config
# DATA_PATH_CONFIG = 'r"D:\Development\Python\ML-SDK\soterml\learning\vertical\workflow\conf\data_path_conf.json'"
DATA_PATH_CONFIG = './config/data_path_conf.json'

FLOAT_ZERO = 1e-6
