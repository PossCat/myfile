from enum import Enum
import os
import time

from soterml.connection.chain import SoterOneChain


class LogLevel(Enum):
    DEBUG = 0
    INFO = 1
    WARNING = 2
    ERROR = 3
    CRITICAL = 4


class LogType(Enum):
    LogisticRegressionWorkflow = 0,
    LogisticRegressionModel = 1,
    SecureBoostWorkflow = 2,
    SecureBoostModel = 3


_LoggerType = {
    LogType.LogisticRegressionWorkflow: 'logistic_regression_workflow',
    LogType.LogisticRegressionModel: 'logistic_regression_model'
}


def _type_to_str(log_type):
    return _LoggerType[log_type]


class Logger:
    def __init__(self, type, role, level=LogLevel.DEBUG, chain=None, query_uuid=None):
        self.name = _type_to_str(type) + '_' + role
        self.level = level
        self.chain = chain
        self.query_uuid = query_uuid

        if query_uuid is not None:
            self.name = self.name + '_' + query_uuid

        self.file_path = './log/' + self.name + '.txt'

        self._init_file_path()

    def _init_file_path(self):
        if not os.path.exists('./log'):
            os.mkdir('./log')

        file = open(self.file_path, 'w')
        file.close()

    def debug(self, log):
        if self.level != LogLevel.DEBUG:
            return
        self._write(LogLevel.DEBUG, log)

    def info(self, log):
        if self.level != LogLevel.DEBUG and self.level != LogLevel.INFO:
            return
        self._write(LogLevel.INFO, log)

    def warning(self, log):
        if self.level != LogLevel.DEBUG and self.level != LogLevel.INFO and self.level != LogLevel.WARNING:
            return
        self._write(LogLevel.WARNING, log)

    def error(self, log):
        if self.level == LogLevel.CRITICAL:
            return
        self._write(LogLevel.ERROR, log)

    def critical(self, log):
        self._write(LogLevel.CRITICAL, log)

    def _write(self, level, log):
        if isinstance(log, str):
            self.__write(level, log)
            if self.chain is not None:
                self.chain.add_log(uuid=self.query_uuid, payload={'msg': log})

        elif isinstance(log, dict):
            if 'msg' not in log:
                raise RuntimeError('Log need key: msg')
            self.__write(level, log['msg'])
            if self.chain is not None:
                self.chain.add_log(uuid=self.query_uuid, payload=log)

        else:
            raise RuntimeError('Log format error')

    def __write(self, level, log):
        with open(self.file_path, 'a') as fin:
            fin.write(time.asctime(time.localtime(time.time())))
            fin.write(' - ')
            if level == LogLevel.DEBUG:
                fin.write('DEBUG: ')
            elif level == LogLevel.INFO:
                fin.write('INFO: ')
            elif level == LogLevel.WARNING:
                fin.write('WARNING: ')
            elif level == LogLevel.ERROR:
                fin.write('ERROR: ')
            else:
                fin.write('CRITICAL: ')

            fin.write(log)
            fin.write('\n')
            fin.close()
