from enum import Enum


class MessageType(Enum):
    pub_key = 1
    forward_intermediate_parameter = 2
    fore_gradient = 3
    gradient = 4
    loss_regular = 5
    is_stop = 6
    loss = 7
    optim_loss = 8


class SecureBoostType(Enum):
    tree_dim = 1
