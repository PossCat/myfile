from soterml.learning.vertical.utils.consts import MPC, HOST, GUEST


class Party:
    """
    role in the LogisticRegression, such as Host, Guest, Arbiter
    """

    def __init__(self, role: str, idx: int, wallet_address: str=None):
        self.role = role
        self.idx = idx
        self.wallet_address = wallet_address
        self.check_party_right()

    def check_party_right(self):
        """
        check
        """
        if self.role not in [MPC, HOST, GUEST]:
            raise TypeError('Error role type!')
        if self.idx < 0 or not isinstance(self.idx, int):
            raise TypeError('Role idx error!')

    # If two Partys are created in two places but the content is the same,
    # such as a = Party(Role.MPC, 0), b = Party(Role.MPC, 0), "a == b" will be False
    # so I have to overwrite the __eq__
    def __eq__(self, other):
        return (self.role, self.idx) == (other.role, other.idx)

    # for dict to hash, because the key of dict must be hashable
    def __hash__(self):
        kv = {MPC: 10000, HOST: 20000, GUEST: 30000}
        return kv[self.role] + self.idx
