from soterml.learning.vertical.connection.logistic_regression.lr_connection import \
    LogisticConnection
from soterml.learning.vertical.ml.secure_boost.boosting_tree import BoostingTree
from soterml.learning.vertical.utils.log import Logger, LogType, LogLevel
from soterml.learning.vertical.utils import consts
from soterml.learning.vertical.utils.message_type import SecureBoostType
from soterml.learning.vertical.ml.feature import Instance
import numpy as np

class SecureBoostingTreeHost(BoostingTree):
    def __init__(self, secureboost_tree_param):
        super(SecureBoostingTreeHost, self).__init__(secureboost_tree_param,
                                                     chain=None, parties_map={})
        self.flowid = 0
        self.F = None
        self.tree_dim = None
        self.feature_num = None
        self.trees_ = []
        self.bin_split_points = None
        self.bin_sparse_points = None
        self.data_bin = None
        self.role = consts.HOST
        self.logger = Logger(type=LogType.SecureBoostModel, role=self.role, level=LogLevel.DEBUG)
        self.federation = LogisticConnection(port='test', party='test', party_map={},
                                             query_uuid='test',
                                             sc=None)

    def convert_feature_to_bin(self, data_instance):
        """
        :param data_instance:
        :type data_instance:
        """
        self.logger.info('convert feature to bins')
        self.data_bin, self.bin_split_points, self.bin_sparse_points = \
            1, 2, 3
        pass

    def update_f_value(self, new_f=None, tidx=-1):
        self.logger.info("update tree f value, tree idx is {}".format(tidx))
        if self.F is None:
            self.logger.info('tree_dim is %d' % (self.tree_dim))
            tree_dim = self.tree_dim
            self.F = self.y


    def set_y(self):
        self.logger.info('set label from data and check label')
        self.y = self.data_bin.label

    def fit(self, data_inst):
        self.logger.info('begin to train secureboost host model')
        self.convert_feature_to_bin(data_inst)
        self.set_y()
        self.update_f_value()
        self.generate_encrypter()
