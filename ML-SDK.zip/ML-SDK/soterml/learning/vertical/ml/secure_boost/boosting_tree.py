from soterml.connection.chain import SoterOneChain


class BoostingTree(object):
    def __init__(self, boostingtree_param, chain: SoterOneChain, parties_map: dict):
        self.tree_param = boostingtree_param.tree_param
        self.task_type = boostingtree_param.task_type
        self.loss_type = boostingtree_param.loss_type
        self.learning_rate = boostingtree_param.learning_rate
        self.num_trees = boostingtree_param.num_trees
        self.subsample_feature_rate = boostingtree_param.subsample_feature_rate
        self.n_iter_no_change = boostingtree_param.n_iter_no_change
        self.encrypt_param = boostingtree_param.encrypt_param
        self.tol = boostingtree_param.tol
        self.quantile_method = boostingtree_param.quantile_method
        self.bin_num = boostingtree_param.bin_num
        self.bin_gap = boostingtree_param.bin_gap
        self.bin_sample_num = boostingtree_param.bin_sample_num

    def fit(self, data_inst):
        pass

    def predict(self, data_inst, threshold=0.5):
        pass

    def predict_proba(self, data_inst):
        pass

    def load_model(self):
        pass

    def save_mode(self):
        pass

