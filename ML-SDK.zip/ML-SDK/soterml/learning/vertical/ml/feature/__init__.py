from soterml.learning.vertical.ml.feature.instance import Instance, Instances

__all__ = ['Instance', 'Instances']
