import numpy as np


class Instance(object):
    """

    """
    def __init__(self, inst_id=None, weight=1.0, features=None, label=None):
        self.inst_id = inst_id
        self.weight = weight
        self.features = features
        self.label = label

    def set_weight(self, weight=1.0):
        self.weight = weight

    def set_label(self, label=1):
        self.label = label

    def set_feature(self, features):
        self.features = features


class Instances:
    def __init__(self, data: list, has_label=True):
        self.data = data
        self.has_label = has_label
        self.features = self._features()
        self.label = self._labels()

    def _features(self):
        features = list()
        for idx in range(len(self.data)):
            features.append(self.data[idx].features)
        return np.array(features)

    def _labels(self):
        size = len(self.data)
        if self.has_label:
            return np.array([self.data[idx].label for idx in range(size)])
        else:
            return None

    def __getitem__(self, item):
        return self.data[item]

    def __len__(self):
        return len(self.data)

