class LogisticRegressionModelMeta:
    def __init__(self):
        self.n_iter_ = 0
        self.coef_ = None
        self.intercept_ = None
        self.classes_ = None
