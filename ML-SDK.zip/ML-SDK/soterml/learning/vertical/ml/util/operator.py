from collections import Iterable

import numpy as np

from soterml.learning.vertical.ml.feature import Instances


def _one_dimension_dot(X, w):
    res = 0
    for i in range(len(X)):
        if np.fabs(X[i]) < 1e-5:
            continue
        res += w[i] * X[i]
    return res


def dot(value, w):
    if isinstance(value, Instances):
        X = value.features
    else:
        X = value

    # dot(a, b)[i, j, k, m] = sum(a[i, j, :] * b[k, :, m])
    # One-dimension dot, which is the inner product of these two arrays
    if np.ndim(X) == np.ndim(w) == 1:
        return _one_dimension_dot(X, w)
    elif np.ndim(X) == 2 and np.ndim(w) == 1:
        res = []
        for x in X:
            res.append(_one_dimension_dot(x, w))
        res = np.array(res)
    else:
        res = np.dot(X, w)
    return res


def reduce_add(x, y):
    if x is None and y is None:
        return None

    if x is None:
        return y

    if y is None:
        return x
    if not isinstance(x, Iterable):
        result = x + y
    else:
        result = []
        for idx, acc in enumerate(x):
            result.append(acc + y[idx])
    return result