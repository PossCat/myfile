import json
import inspect


class ParamExtract(object):
    def __init__(self):
        pass

    @staticmethod
    def parse_param_from_config(param_var, config_file):
        config_json = None
        with open(config_file, "r") as fin:
            config_json = json.loads(fin.read())

        if config_json is None:
            raise Exception("config file is not valid, please have a check!")

        from soterml.learning.vertical.ml import param
        valid_classes = [class_info[0] for class_info in inspect.getmembers(param, inspect.isclass)]
        param_var = ParamExtract.recursive_parse_param_from_config(param_var, config_json, valid_classes,
                                                                   param_parse_depth=0)
        return param_var

    @staticmethod
    def recursive_parse_param_from_config(param, config_json, valid_classes, param_parse_depth):
        # if param_parse_depth > consts.PARAM_MAXDEPTH:
        #     raise ValueError("Param define nesting too deep!!!, can not parse it")

        default_section = type(param).__name__
        inst_variables = param.__dict__

        for variable in inst_variables:
            attr = getattr(param, variable)

            if type(attr).__name__ in valid_classes:
                sub_params = ParamExtract.recursive_parse_param_from_config(attr, config_json, valid_classes,
                                                                            param_parse_depth + 1)
                setattr(param, variable, sub_params)
            else:
                if default_section in config_json and variable in config_json[default_section]:
                    option = config_json[default_section][variable]
                    setattr(param, variable, option)

        return param

    @staticmethod
    def is_class(var):
        return hasattr(var, "__class__")
