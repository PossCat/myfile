import numpy as np

from soterml.learning.vertical.ml.feature import Instances


class MiniBatch(object):
    def __init__(self, data, batch_size):
        self.batch_size = batch_size
        self.data_size = len(data)
        self.batch_num = len(data) // batch_size + (0 if self.data_size % self.batch_size == 0 else 1)
        self.raw_data = data
        self.data = self._split_data()

    def _split_data(self):
        data = list()
        for idx in range(self.batch_num):
            start = idx * self.batch_size
            end = (idx + 1) * self.batch_size if (idx + 1) * self.batch_size <= self.data_size else self.data_size
            data.append(Instances(self.raw_data[start: end]))
        return data

    def __len__(self):
        return self.batch_num

    def __getitem__(self, item):
        return self.data[item]

    def batch_info(self):
        return {"batch_size": self.batch_size, "batch_num": self.batch_num}
