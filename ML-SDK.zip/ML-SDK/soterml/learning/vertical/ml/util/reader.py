import pandas as pd
import json
import numpy as np

from soterml.learning.vertical.ml.util.param_extract import ParamExtract
from soterml.learning.vertical.ml.param import DataIOParam
from soterml.learning.vertical.utils import consts
from soterml.learning.vertical.ml.feature import Instance, Instances


class Reader:
    """
    func:
        1. get dataset_name from data_io_config
        2. get dataset path from data_path_config
        3. load data via dataset path
        4. data filtering(PSI res)
        5. todo data alignment(All DOs)
    """

    def __init__(self, chain=None, role=None, idx=None, data_io_config=None):
        self.chain = chain
        self.role = role
        self.idx = idx

        self.all_data_io_param = ParamExtract.parse_param_from_config(DataIOParam(), data_io_config)
        if self.role == consts.HOST:
            self.data_io_param = self.all_data_io_param.HOST[self.idx]
        elif self.role == consts.GUEST:
            self.data_io_param = self.all_data_io_param.GUEST[self.idx]

        self.dataset_name = self.data_io_param["dataset_name"]
        self.primary_key = self.data_io_param["primary_key"]
        self.features = self.data_io_param["features"]

        self.label = self.data_io_param["label"] if self.data_io_param["label"] != "None" else None
        self.df = self._init_dataframe()

    def filter_data(self, psi_res):
        psi_idx_map = dict()
        df = self.df
        for idx in range(len(psi_res)):
            psi_idx_map[df.iloc[idx][self.primary_key]] = idx

        # filter PSI
        df = df[df[self.primary_key].isin(psi_idx_map)]

        # filter features
        df = df[self.features]

        # todo data alignment
        return df.values

    def _init_dataframe(self):
        data_path_json = get_config_json(consts.DATA_PATH_CONFIG)
        data_path = data_path_json[self.dataset_name]
        return pd.read_csv(data_path)

    def get_data_instances(self):
        data_instances = list()
        for i in range(0, len(self.df)):
            if self.label is None:
                label = None
            else:
                label = self.df.iloc[i][self.label]
                if label is not None and label <= np.float(0.0):
                    label = np.float(-1.0)
            instance = Instance(inst_id=i, features=self.df.iloc[i][self.features].values, label=label)
            data_instances.append(instance)
        return Instances(data_instances, has_label=(True if self.label is None else False))


def get_config_json(config_path):
    with open(config_path, "r") as fin:
        config_json = json.loads(fin.read())
    return config_json

