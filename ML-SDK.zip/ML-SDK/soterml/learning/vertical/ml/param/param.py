class DataIOParam(object):
    def __init__(self, HOST=None, GUEST=None):
        """
        data_config = DataIOParam[self.role][self.index]
        data_config = {
                        "dataset_name": "dataset1",
                        "primary_key": "id",
                        "features": ["x1", "x2", "x3"],
                        "label": ["y"]
                    }
        @param HOST:
        @param GUEST:
        """
        self.HOST = HOST
        self.GUEST = GUEST


class PartiesParam(object):
    def __init__(self, parties_num=None, wallet_address_to_role=None, role_to_party=None):
        """

        @param parties_num:
                    example:
                            "parties_num": {
                                            "MPC": 1,
                                            "HOST": 1,
                                            "Guest": 1
                                            }
        @param wallet_address_to_role:
                    example:
                            "wallet_address_to_role": {
                                "walletAddress1": {
                                    "role": "MPC",
                                    "idx": 0
                                },
                            }
        @param role_to_party:
                    example:
                            "role_to_party": {
                                "MPC0": {
                                    "ip": "127.0.0.1",
                                    "port": "8770"
                                },
                                "HOST0": {
                                    "ip": "127.0.0.1",
                                    "port": "8771"
                                },
                                "GUEST0": {
                                    "ip": "127.0.0.1",
                                    "port": "8772"
                                }
                            }
        """
        self.parties_num = parties_num
        self.wallet_address_to_role = wallet_address_to_role
        self.role_to_party = role_to_party


class EvaluateParam(object):
    def __init__(self, metrics=None, classi_type="binary", pos_label=1, thresholds=None):
        self.metrics = metrics
        self.classi_type = classi_type
        self.pos_label = pos_label
        self.thresholds = thresholds


class PredictParam(object):
    def __init__(self, with_proba=True, threshold=0.5):
        self.with_proba = with_proba
        self.threshold = threshold


class InitParam(object):
    def __init__(self, init_method='random_uniform', init_const=1, fit_intercept=True):
        self.init_method = init_method
        self.init_const = init_const
        self.fit_intercept = fit_intercept


class LogisticParam(object):
    def __init__(self,penalty='L2',
                 eps=1e-5, alpha=1.0, optimizer='sgd', party_weight=1,
                 batch_size=-1, learning_rate=0.01, init_param=InitParam(),
                 max_iter=100, converge_func='diff',
                 model_path='lr_model'):
        self.penalty = penalty
        self.eps = eps
        self.alpha = alpha
        self.optimizer = optimizer
        self.batch_size = batch_size
        self.learning_rate = learning_rate
        self.init_param = init_param
        self.max_iter = max_iter
        self.converge_func = converge_func
        self.model_path = model_path
        self.party_weight = party_weight
