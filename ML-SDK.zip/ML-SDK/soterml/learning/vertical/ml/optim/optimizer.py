import numpy as np


class Optimizer(object):

    def __init__(self, learning_rate, opt_method_name="Sgd"):
        """
        """
        # 优化算法初始化参数；
        self.opt_beta1 = 0.9
        self.opt_beta2 = 0.999
        self.rho = 0.99

        self.opt_beta1_decay = 1.0
        self.opt_beta2_decay = 1.0

        self.opt_m = None
        self.opt_v = None
        self.learning_rate = learning_rate

        self.opt_method_name = opt_method_name.lower()

    def SgdOptimizer(self, grad):
        """sgd 优化；
           grad: 梯度；
        """
        self.learning_rate *= self.opt_beta2
        delta_grad = self.learning_rate * grad
        return delta_grad

    def AdaGradOptimizer(self, grad):
        """ AdaGrad 优化算法；
            grad: 梯度；
        """
        if self.opt_m is None:
            self.opt_m = np.zeros_like(grad)

        self.opt_m = self.opt_m + np.square(grad)
        self.opt_m = np.array(self.opt_m, dtype=np.float64)
        delta_grad = self.learning_rate * grad / (np.sqrt(self.opt_m) + 1e-7)
        return delta_grad

    def RMSPropOptimizer(self, grad):
        """
        RMSProp 优化算法；
        grad: 梯度；
        """
        if self.opt_m is None:
            self.opt_m = np.zeros_like(grad)

        self.opt_m = self.rho * self.opt_m + (1 - self.rho) * np.square(grad)
        self.opt_m = np.array(self.opt_m, dtype=np.float64)
        delta_grad = self.learning_rate * grad / np.sqrt(self.opt_m + 1e-6)
        return delta_grad

    def AdamOptimizer(self, grad):
        """
        Adam 优化算法；
        grad: 梯度；
        """
        if self.opt_m is None:
            self.opt_m = np.zeros_like(grad)

        if self.opt_v is None:
            self.opt_v = np.zeros_like(grad)

        self.opt_beta1_decay = self.opt_beta1_decay * self.opt_beta1
        self.opt_beta2_decay = self.opt_beta2_decay * self.opt_beta2
        self.opt_m = self.opt_beta1 * self.opt_m + (1 - self.opt_beta1) * grad
        self.opt_v = self.opt_beta2 * self.opt_v + (1 - self.opt_beta2) * np.square(grad)
        opt_m_hat = self.opt_m / (1 - self.opt_beta1_decay)
        opt_v_hat = self.opt_v / (1 - self.opt_beta2_decay)
        opt_v_hat = np.array(opt_v_hat, dtype=np.float64)
        delta_grad = self.learning_rate * opt_m_hat / (np.sqrt(opt_v_hat) + 1e-8)
        return delta_grad

    def apply_gradients(self, grad):
        """
        根据优化器类型应用梯度；
        """
        if self.opt_method_name == "sgd":
            return self.SgdOptimizer(grad)

        elif self.opt_method_name == "rmsprop":
            return self.RMSPropOptimizer(grad)

        elif self.opt_method_name == "adam":
            return self.AdamOptimizer(grad)

        elif self.opt_method_name == "adagrad":
            return self.AdaGradOptimizer(grad)

        else:
            raise NotImplementedError("Optimize method cannot be recognized: {}".format(self.opt_method_name))

