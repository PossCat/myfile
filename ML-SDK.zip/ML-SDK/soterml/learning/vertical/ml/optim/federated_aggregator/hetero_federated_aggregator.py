import numpy as np

from soterml.learning.vertical.ml.util import operator


class HeteroFederatedAggregator(object):
    @staticmethod
    def aggregate_add(table_a, table_b):
        table_add = table_a.join(table_b, lambda a, b: a + b)
        return table_add

    # do res = (a + b)^2
    @staticmethod
    def aggregate_add_square(table_a, table_b, table_a_square, table_b_square):
        table_a_mul_b = table_a.join(table_b, lambda a, b: 2 * a * b)
        table_a_square_add_b_square = HeteroFederatedAggregator.aggregate_add(table_a_square, table_b_square)
        table_add_square = HeteroFederatedAggregator.aggregate_add(table_a_mul_b, table_a_square_add_b_square)
        return table_add_square

    @staticmethod
    def separate(value, size_list):
        separate_res = []
        cur = 0
        for size in size_list:
            separate_res.append(value[cur:cur + size])
            cur += size

        return separate_res

    @staticmethod
    def aggregate_mean(data):
        count = data.shape[0]
        reduce_res = data
        # count = table.count()
        # reduce_res = table.reduce(operator.reduce_add)
        if isinstance(reduce_res, list):
            reduce_res = np.array(reduce_res)
        reduce_res = reduce_res / count
        return reduce_res
