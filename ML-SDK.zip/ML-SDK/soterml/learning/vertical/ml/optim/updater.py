import numpy as np


class Updater:
    def __init__(self, alpha, learning_rate=0.01):
        self.alpha = alpha
        self.learning_rate = learning_rate
        self.shrinkage_val = self.alpha * self.learning_rate

    def loss_norm(self, coef_): pass

    def update_coef(self, coef_, gradient): pass


class L1Updater(Updater):
    def loss_norm(self, coef_):
        return np.sum(self.alpha * np.abs(coef_))

    def update_coef(self, coef_, gradient):
        return np.sign(coef_ - gradient) * np.maximum(0, np.abs(coef_ - gradient) - self.shrinkage_val)


class L2Updater(Updater):
    def loss_norm(self, coef_):
        return 0.5 * self.alpha * np.dot(coef_, coef_)

    def update_coef(self, coef_, gradient):
        return coef_ - gradient - self.learning_rate * self.alpha * coef_
