import functools
from phe.paillier import EncryptedNumber

import numpy as np

from soterml.learning.vertical.ml.optim.gradient.base_gradient import Gradient
from soterml.learning.vertical.ml.util import operator
from soterml.learning.vertical.ml.optim.federated_aggregator import HeteroFederatedAggregator


class LogisticGradient(Gradient):
    def compute_loss(self, X, Y, coef, intercept):
        tot_loss = np.log(1 + np.exp(np.multiply(-Y.transpose(), X.dot(coef) + intercept))).sum()
        avg_loss = tot_loss / Y.shape[0]
        # avg_loss = LogLoss.compute(X, Y, coef)
        return avg_loss

    def compute(self, values, coef, intercept, fit_intercept):

        # LOGGER.debug("In logistic gradient compute method")
        # print("In logistic gradient compute method")
        X, Y = self.load_data(values)

        # print("Data loaded, shape of X : {}, shape of Y: {}, coef shape: {}".format(
        #     X.shape, Y.shape, np.shape(coef)))
        batch_size = len(X)

        if batch_size == 0:
            return None, None

        d = (1.0 / (1 + np.exp(-np.multiply(Y.transpose(), X.dot(coef) + intercept))) - 1).transpose() * Y
        grad_batch = d * X
        if fit_intercept:
            grad_batch = np.c_[grad_batch, d]
        grad = sum(grad_batch) / batch_size
        loss = self.compute_loss(X, Y, coef, intercept)
        return grad, loss


class TaylorLogisticGradient(Gradient):
    def compute_loss(self, X, Y, w, intercept):
        return 0

    def compute(self, values, coef, intercept, fit_intercept):
        X, Y = self.load_data(values)
        batch_size = len(X)
        if batch_size == 0:
            return None, None

        one_d_y = Y.reshape([-1, ])
        d = (0.25 * np.array(operator.dot(X, coef) + intercept).transpose() + 0.5 * one_d_y * -1)

        grad_batch = X.transpose() * d
        grad_batch = grad_batch.transpose()

        if fit_intercept:
            grad_batch = np.c_[grad_batch, d]
        grad = sum(grad_batch) / batch_size
        return grad, None


class HeteroLogisticGradient(object):
    def __init__(self, encrypt_method=None):
        self.encrypt_operator = encrypt_method

    @staticmethod
    def __compute_gradient(data, fit_intercept=True):
        gradient = []
        feature = data[0]
        fore_gradient = data[1]

        if feature.shape[0] <= 0:
            return 0
        for j in range(feature.shape[1]):
            feature_col = feature[:, j]
            gradient_j = operator.dot(feature_col, fore_gradient)
            gradient_j /= feature.shape[0]
            gradient.append(gradient_j)

        if fit_intercept:
            fore_gradient_size = fore_gradient.shape[0]
            fore_gradient = fore_gradient / fore_gradient_size
            bias_grad = np.sum(fore_gradient)
            gradient.append(bias_grad)

        return np.array(gradient)

    @staticmethod
    def __compute_loss(values):
        half_ywx = values[0]
        encrypted_wx_square = values[1]
        bias = np.log(2)

        if len(half_ywx) <= 0 or len(encrypted_wx_square) <= 0:
            return 0

        loss = 0
        for i in range(len(half_ywx)):
            l = half_ywx[i] * (-1) + encrypted_wx_square[i] / 8 + bias
            if i == 0:
                loss = l
            else:
                loss = loss + l

        return loss / len(half_ywx)

    def compute_fore_gradient(self, data_instance, encrypted_wx):
        # [[d]] = 0.25 * [[wx]] - 0.5 * [[y]]
        fore_gradient = 0.25 * encrypted_wx - 0.5 * self.encrypt_operator.encrypt(data_instance.label)
        return fore_gradient

    def compute_gradient(self, data_instance, fore_gradient, fit_intercept):
        feature_join_grad = (data_instance.features, fore_gradient)
        gradient_partition = self.__compute_gradient(data=feature_join_grad, fit_intercept=fit_intercept)
        gradient = HeteroFederatedAggregator.aggregate_mean(gradient_partition)
        return gradient

    def compute_gradient_and_loss(self, data_instance, fore_gradient, encrypted_wx, en_sum_wx_square, fit_intercept):
        # compute gradient
        gradient = self.compute_gradient(data_instance, fore_gradient, fit_intercept)

        # compute and loss
        half_ywx = 0.5 * encrypted_wx * data_instance.label
        half_ywx_join_en_sum_wx_square = (half_ywx, en_sum_wx_square)
        loss_partition = self.__compute_loss(half_ywx_join_en_sum_wx_square)
        loss = loss_partition
        # loss = HeteroFederatedAggregator.aggregate_mean(loss_partition)

        return gradient, loss
