import numpy as np


class Gradient:
    def compute(self, values, coef, intercept, fit_intercept):
        raise NotImplementedError("Method not implement")

    def compute_loss(self, X, Y, coef, intercept):
        raise NotImplementedError("Method not implement")

    def load_data(self, data_instance):
        X = []
        Y = []

        # get batch data
        for iter_key, instant in data_instance:
            weighted_feature = instant.weight * instant.features
            X.append(weighted_feature)
            if instant.label == 1:
                Y.append([1])
            else:
                Y.append([-1])
        X = np.array(X)
        Y = np.array(Y)
        return X, Y
