import numpy as np
import time

from soterml.learning.vertical.ml.logistic_regression.lr_base import LRBase
from soterml.learning.vertical.utils import consts
from soterml.learning.vertical.ml.util.mini_batch import MiniBatch
from soterml.learning.vertical.connection.logistic_regression.lr_connection import MessageType
from soterml.learning.vertical.utils.party import Party
from soterml.learning.vertical.ml.optim.gradient import HeteroLogisticGradient
from soterml.learning.vertical.utils.log import Logger, LogType, LogLevel


class LRGuest(LRBase):
    def __init__(self, chain, chain_event, parties_map, model_config, port, wallet_address):
        super(LRGuest, self).__init__(chain, chain_event, parties_map, model_config, port,
                                      party=Party(role=consts.GUEST, idx=0, wallet_address=wallet_address))
        self.batch_num = None
        self.batch_index_list = []
        self.role = consts.GUEST
        self.logger = Logger(type=LogType.LogisticRegressionModel, role=self.role, level=LogLevel.DEBUG)

    def compute_forward(self, data_instances, coef_, intercept_):
        wx = self.compute_wx(data_instances, coef_, intercept_)
        wx_square = np.square(wx)
        return self.encryptor.encrypt(wx), self.encryptor.encrypt(wx_square)

    def fit(self, data_instances=None):
        self.logger.debug("Starting fitting.")
        public_key = self.federation.get(obj_type=MessageType.pub_key, role=consts.MPC, role_idx=0)
        self.logger.info("Get public key from mpc.")
        self.encryptor.set_public_key(public_key)

        mini_batch_obj = MiniBatch(data_instances, batch_size=self.batch_size)

        model_shape = self.get_features_shape(data_instances)

        if self.init_param_obj.fit_intercept:
            self.init_param_obj.fit_intercept = False

        if self.fit_intercept:
            self.fit_intercept = False

        self.coef_ = self.initializer.init_model(model_shape, init_params=self.init_param_obj)
        self.batch_num = mini_batch_obj.batch_num

        is_stopped = False
        self.n_iter_ = 0
        while self.n_iter_ < self.max_iter:
            self.logger.info("Iter: {}".format(self.n_iter_))
            batch_index = 0
            while batch_index < self.batch_num:
                self.logger.info("Batch_index: {}".format(batch_index))
                # Get mini-batch train data
                batch_data_inst = mini_batch_obj[batch_index]

                # compute forward
                # w1x + w2x = wx
                guest_forward = self.compute_forward(batch_data_inst, self.coef_, self.intercept_)

                self.federation.remote(guest_forward,
                                       obj_type=MessageType.forward_intermediate_parameter,
                                       role=consts.HOST,
                                       role_idx=0)
                self.logger.info("Remote guest_forward to host.")

                # fore_gradient * guest_x
                fore_gradient = self.federation.get(obj_type=MessageType.fore_gradient,
                                                    role=consts.HOST,
                                                    role_idx=0)
                self.logger.info("Get fore_gradient from host.")

                # compute host gradient
                if self.gradient_operator is None:
                    self.gradient_operator = HeteroLogisticGradient(self.encryptor)
                guest_gradient = self.gradient_operator.compute_gradient(batch_data_inst, fore_gradient,
                                                                         fit_intercept=False)

                # regulation if necessary
                if self.updater is not None:
                    loss_regular = self.updater.loss_norm(self.coef_)
                    en_loss_regular = self.encryptor.encrypt(loss_regular)
                    self.federation.remote(obj=en_loss_regular,
                                           obj_type=MessageType.loss_regular,
                                           role=consts.HOST,
                                           role_idx=0)
                    self.logger.info("Remote guest_loss_regular to host")

                self.federation.remote(obj=guest_gradient,
                                       obj_type=MessageType.gradient,
                                       role=consts.MPC,
                                       role_idx=0)
                self.logger.info("Remote guest_gradient to mpc.")

                # Get optimize host gradient and update model
                optim_host_gradient = self.federation.get(obj_type=MessageType.gradient,
                                                          role=consts.MPC,
                                                          role_idx=0)
                self.logger.info("Get optim gradient from mpc.")
                self.logger.debug("Guest update_model")
                self.update_model(optim_host_gradient)

                # is converge
                is_stopped = self.federation.get(obj_type=MessageType.is_stop,
                                                 role=consts.MPC,
                                                 role_idx=0)
                self.logger.info("Get is_stop flag from MPC:{}".format(is_stopped))

                batch_index += 1
                if is_stopped:
                    self.logger.info("Get stop signal from MPC, model is converged, iter:{}".format(is_stopped))
                    break

            self.n_iter_ += 1
            if is_stopped:
                break
        self.logger.info("Reach max iter {}, train model finish!".format(self.max_iter))

    def predict(self, data_instances=None, predict_param=None):
        self.logger.debug("Starting predicting.")
        public_key = self.federation.get(obj_type=MessageType.pub_key,
                                         role=consts.MPC,
                                         role_idx=0)
        self.logger.info("Get public key from mpc.")
        self.encryptor.set_public_key(public_key=public_key)
        self.logger.info("Set the public key to public key of own encryptor.")

        guest_wx = self.compute_wx(data_instances=data_instances,
                                   coef_=self.coef_,
                                   intercept_=self.intercept_)
        # enc_guest_wx = guest_wx
        enc_guest_wx = self.encryptor.encrypt(guest_wx)
        self.federation.remote(obj=enc_guest_wx,
                               obj_type=MessageType.gradient,
                               role=consts.HOST,
                               role_idx=0)
        self.logger.info("Remote guest_wx to host.")






