import numpy as np

from soterml.learning.vertical.ml.logistic_regression.lr_base import LRBase
from soterml.learning.vertical.utils import consts
from soterml.learning.vertical.ml.util.mini_batch import MiniBatch
from soterml.learning.vertical.utils.message_type import MessageType
from soterml.learning.vertical.ml.optim.gradient import HeteroLogisticGradient
from soterml.learning.vertical.utils.party import Party
from soterml.learning.vertical.utils.log import Logger, LogType, LogLevel


class LRHost(LRBase):
    def __init__(self, chain, chain_event, parties_map, model_config, port, wallet_address):
        party = Party(role=consts.HOST, idx=0, wallet_address=wallet_address)
        super(LRHost, self).__init__(chain=chain,
                                     chain_event=chain_event,
                                     parties_map=parties_map,
                                     model_config=model_config,
                                     port=port,
                                     party=party)
        self.idx = None
        self.batch_num = None
        self.role = consts.HOST

        self.host_forward = None
        self.logger = Logger(type=LogType.LogisticRegressionModel, role=self.role, level=LogLevel.DEBUG)

    def compute_forward(self, data_instances, coef_, intercept_):
        self.wx = self.compute_wx(data_instances, coef_, intercept_)
        enc_wx = self.encryptor.encrypt(self.wx)
        square_wx = np.square(self.wx)
        enc_square_wx = self.encryptor.encrypt(square_wx)
        self.host_forward = (enc_wx, enc_square_wx, self.wx)

    def aggregate_forward(self, guest_forward):
        """
        [[wx]] = [[wx_guest]] + [[wx_host]] = guest_forward[0] + host_forward[0]
        [[wx_square]] = [[wx_guest_square + wx_host_square + 2 * wx_guest * wx_host]]
                      = [[wx_guest_square]] + [[wx_host_square]] + 2 * wx_host * [[wx_guest]]
        @param guest_forward:
        @return:
        """
        aggregate_forward_res = (self.host_forward[0] + guest_forward[0],
                                 self.host_forward[1] + guest_forward[1] + 2 * self.host_forward[2] * guest_forward[0])
        return aggregate_forward_res

    @staticmethod
    def load_data(data_instance):
        if data_instance.label != 1:
            data_instance.label = -1
        return data_instance

    def fit(self, data_instances=None):
        self.logger.debug("Starting fitting.")

        public_key = self.federation.get(MessageType.pub_key, role=consts.MPC, role_idx=0)
        # print("Get public_key from MPC")
        self.logger.info('Get public_key from mpc.')

        self.encryptor.set_public_key(public_key=public_key)
        mini_batch_obj = MiniBatch(data_instances, batch_size=self.batch_size)

        model_shape = self.get_features_shape(data_instances)

        weight = self.initializer.init_model(model_shape, init_params=self.init_param_obj)

        if self.init_param_obj.fit_intercept is True:
            self.coef_ = weight[:-1]
            self.intercept_ = weight[-1]
        else:
            self.coef_ = weight

        is_stopped = False
        self.n_iter_ = 0
        self.batch_num = mini_batch_obj.batch_num

        while self.n_iter_ < self.max_iter:
            batch_index = 0
            self.logger.info("Iter {}".format(self.n_iter_))
            for batch_data_index in range(self.batch_num):
                # Get mini-batch train data
                self.logger.info("batch_index {}".format(batch_data_index))
                batch_data_inst = mini_batch_obj[batch_index]

                # guest/host forward
                self.compute_forward(batch_data_inst, self.coef_, self.intercept_)
                guest_forward = self.federation.get(obj_type=MessageType.forward_intermediate_parameter,
                                                    role=consts.GUEST,
                                                    role_idx=0)
                self.logger.info("Get guest_forward from guest.")

                aggregate_forward_res = self.aggregate_forward(guest_forward)
                self.logger.debug("Host aggregate forward res successfully")

                en_aggregate_wx = aggregate_forward_res[0]
                en_aggregate_wx_square = aggregate_forward_res[1]

                # compute [[d]]
                if self.gradient_operator is None:
                    self.gradient_operator = HeteroLogisticGradient(self.encryptor)
                fore_gradient = self.gradient_operator.compute_fore_gradient(batch_data_inst, en_aggregate_wx)
                self.logger.debug("Compute fore_gradient successfully.")

                self.federation.remote(obj=fore_gradient,
                                       obj_type=MessageType.fore_gradient,
                                       role=consts.GUEST,
                                       role_idx=0)
                self.logger.info("Remote fore_gradient to guest.")

                # compute guest gradient and loss
                host_gradient, loss = self.gradient_operator.compute_gradient_and_loss(batch_data_inst,
                                                                                       fore_gradient,
                                                                                       en_aggregate_wx,
                                                                                       en_aggregate_wx_square,
                                                                                       self.fit_intercept)
                self.logger.debug("Compute gradient successfully.")

                # loss regulation if necessary
                if self.updater is not None:
                    host_loss_regular = self.updater.loss_norm(self.coef_)
                    loss += self.encryptor.encrypt(host_loss_regular)

                self.federation.remote(obj=host_gradient,
                                       obj_type=MessageType.gradient,
                                       role=consts.MPC,
                                       role_idx=0)
                self.logger.info("Remote host_gradient to mpc.")
                optim_guest_gradient = self.federation.get(obj_type=MessageType.gradient,
                                                           role=consts.MPC,
                                                           role_idx=0)
                self.logger.info("Get optim_guest_gradient from mpc.")

                # update model
                self.logger.debug("Host update model.")
                self.update_model(optim_guest_gradient)

                # Get loss regulation from Host if regulation is set
                if self.updater is not None:
                    en_guest_loss_regular = self.federation.get(obj_type=MessageType.loss_regular,
                                                                role=consts.GUEST,
                                                                role_idx=0)
                    self.logger.info("Get guest_loss_regular from guest.")
                    loss += en_guest_loss_regular

                self.federation.remote(obj=loss,
                                       obj_type=MessageType.loss_regular,
                                       role=consts.MPC,
                                       role_idx=0)
                self.logger.info("Remote loss to mpc.")

                # is converge of loss in arbiter
                is_stopped = self.federation.get(obj_type=MessageType.is_stop,
                                                 role=consts.MPC,
                                                 role_idx=0)
                self.logger.info("Get is_stop flag from MPC:{}".format(is_stopped))
                batch_index += 1
                if is_stopped:
                    self.logger.info("Get stop signal from mpc, model is converged, iter:{}".format(self.n_iter_))
                    break

            self.n_iter_ += 1
            if is_stopped:
                break
        self.logger.info("Reach max iter {}, train model finish!".format(self.max_iter))

    def predict(self, data_instances=None, predict_param=None):
        # todo fix message type
        self.logger.debug("Starting predicting.")
        public_key = self.federation.get(obj_type=MessageType.pub_key,
                                         role=consts.MPC,
                                         role_idx=0)
        self.encryptor.set_public_key(public_key)
        self.logger.info("Get public key from mpc.")
        # self.encryptor.set_public_key(public_key=public_key)
        self.logger.info("Set the public key to public key of own encryptor.")

        enc_guest_wx = self.federation.get(obj_type=MessageType.gradient,
                                           role=consts.GUEST,
                                           role_idx=0)
        self.logger.info("Get the guest_wx from guest.")

        host_wx = self.compute_wx(data_instances=data_instances,
                                  coef_=self.coef_,
                                  intercept_=self.intercept_)
        enc_host_wx = self.encryptor.encrypt(host_wx)

        enc_wx = enc_guest_wx + enc_host_wx

        # if predict_param.with_proba:
        #     label = data_instances.label
        # else:
        #     label = None
        label = None

        # pred_label_join_label = (enc_wx, label)
        self.federation.remote(obj=enc_host_wx,
                               obj_type=MessageType.gradient,
                               role=consts.MPC,
                               role_idx=0)
        self.logger.info("Remote prediction result to mpc.")


