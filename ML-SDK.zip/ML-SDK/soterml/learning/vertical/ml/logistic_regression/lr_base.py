import numpy as np

from soterml.learning.vertical.connection.logistic_regression.lr_connection import LogisticConnection
from soterml.learning.vertical.ml.secure_protocol.paillier_encryptor import PaillierEncryptor, EncryptedNumber
from soterml.learning.vertical.ml.util.param_extract import ParamExtract
from soterml.learning.vertical.ml.param import LogisticParam
from soterml.learning.vertical.ml.logistic_regression_modelmeta import LogisticRegressionModelMeta
from soterml.learning.vertical.ml.optim import Initializer
from soterml.learning.vertical.ml.optim import L1Updater
from soterml.learning.vertical.ml.optim import L2Updater
from soterml.learning.vertical.utils import consts
from soterml.learning.vertical.utils.chain_log import decode_chain_str
from soterml.connection.chain import SoterOneChain


class LRBase(object):
    def __init__(self, chain: SoterOneChain, chain_event, parties_map, model_config, port, party):
        """

        @param chain:
        @param chain_event:
        @param parties_map:
        @param model_config:
        """
        self.lr_param_obj = ParamExtract.parse_param_from_config(LogisticParam(), model_config)
        self.init_param_obj = self.lr_param_obj.init_param

        self.query_uuid = decode_chain_str(chain_event['uuid'])
        self.parties_map = parties_map
        self.role = None
        self.idx = None
        self.chain = chain
        self.chain_event = chain_event
        self.federation = LogisticConnection(party_map=parties_map,
                                             port=port, party=party,
                                             sc=self.chain, query_uuid=decode_chain_str(chain_event['uuid']))
        self.wx = None

        # attribute
        self.eps = self.lr_param_obj.eps
        self.max_iter = self.lr_param_obj.max_iter
        self.learning_rate = self.lr_param_obj.learning_rate
        self.alpha = self.lr_param_obj.alpha
        self.batch_size = self.lr_param_obj.batch_size
        self.fit_intercept = self.init_param_obj.fit_intercept

        if self.lr_param_obj.penalty == consts.L1_PENALTY:
            self.updater = L1Updater(self.alpha, self.learning_rate)
        elif self.lr_param_obj.penalty == consts.L2_PENALTY:
            self.updater = L2Updater(self.alpha, self.learning_rate)
        else:
            self.updater = None

        self.n_iter_ = None
        self.coef_ = None
        self.intercept_ = 0
        self.classes_ = None

        self.gradient_operator = None
        self.initializer = Initializer()
        self.model_meta = LogisticRegressionModelMeta()
        self.encryptor = PaillierEncryptor()

    def fit(self, data_instances=None):
        pass

    def predict(self, data_instances=None, predict_param=None):
        pass

    def public_key(self):
        return self.encryptor.get_public_key()

    def set_public_key(self, public_key):
        self.encryptor.set_public_key(public_key)

    def init_mini_batch(self):
        pass

    def compute_wx(self, data_instances, coef_, intercept_=0):
        return np.dot(data_instances.features, coef_) + intercept_

    def update_model(self, gradient):
        if self.fit_intercept:
            if self.updater is not None:
                self.coef_ = self.updater.update_coef(self.coef_, gradient[:-1])
            else:
                self.coef_ = self.coef_ - gradient[:-1]
            self.intercept_ -= gradient[-1]

        else:
            if self.updater is not None:
                self.coef_ = self.updater.update_coef(self.coef_, gradient)
            else:
                self.coef_ = self.coef_ - gradient

    def merge_model(self):
        w = self.coef_.copy()
        if self.fit_intercept:
            w = np.append(w, self.intercept_)
        return w

    def get_features_shape(self, data_instances):
        if data_instances is None:
            return None
        print(data_instances[0])
        return data_instances[0].features.shape[0]

    def set_coef_(self, w):
        if self.fit_intercept:
            self.coef_ = np.array(w[:-1])
            self.intercept_ = w[-1]
        else:
            self.coef_ = np.array(w)
            self.intercept_ = 0

    def classified(self, prob_table, threshold):
        prob_table[prob_table > threshold] = 0
        prob_table[prob_table <= threshold] = 1
        return prob_table

    def get_model_summary(self):
        model = dict()
        model['model_name'] = "logistic_regression"
        model['role'] = self.role
        model['index'] = 0
        model['w'] = list(self.merge_model())
        model['coef'] = list(self.coef_)
        model['fit_intercept_'] = self.fit_intercept
        model['intercept'] = self.intercept_
        return model



