import time
import numpy as np

from soterml.learning.vertical.ml.logistic_regression.lr_base import LRBase
from soterml.learning.vertical.utils import consts
from soterml.learning.vertical.connection.logistic_regression.lr_connection import MessageType
from soterml.learning.vertical.utils.party import Party
from soterml.learning.vertical.ml.optim.optimizer import Optimizer
from soterml.learning.vertical.ml.optim.convergence import DiffConverge
from soterml.learning.vertical.ml.optim.federated_aggregator import HeteroFederatedAggregator
from soterml.learning.vertical.utils.log import Logger, LogType, LogLevel


class LRMPC(LRBase):
    def __init__(self, chain, chain_event, parties_map, model_config, port, wallet_address, psi_res):
        """

        @param chain:
        @param chain_event:
        @param parties_map:
        @param psi_res:
        @param data_config:
        @param model_config:
        """
        super(LRMPC, self).__init__(chain, chain_event, parties_map, model_config, port,
                                    party=Party(role=consts.MPC, idx=0, wallet_address=wallet_address))
        self.role = consts.MPC
        self.batch_num = None
        self.psi_res = psi_res
        self.optimizer = Optimizer(self.lr_param_obj.learning_rate, self.lr_param_obj.optimizer)
        self.converge_func = DiffConverge(self.lr_param_obj.eps)
        self.logger = Logger(type=LogType.LogisticRegressionModel, role=self.role, level=LogLevel.DEBUG)

    def fit(self, data_instances=None):
        """

        @return:
        """
        self.logger.debug("Starting fitting.")
        # Generate encrypt keys

        public_key = self.encryptor.get_public_key()
        public_key = public_key
        self.federation.remote(obj=public_key,
                               obj_type=MessageType.pub_key,
                               role=consts.HOST,
                               role_idx=0)
        self.logger.info("Remote public key to host.")
        self.federation.remote(obj=public_key,
                               obj_type=MessageType.pub_key,
                               role=consts.GUEST,
                               role_idx=0)
        self.logger.info("Remote public key to guest.")

        self.batch_num = len(self.psi_res) // self.lr_param_obj.batch_size + \
                         (0 if len(self.psi_res) % self.lr_param_obj.batch_size == 0 else 1)

        is_stop = False
        self.n_iter_ = 0
        while self.n_iter_ < self.max_iter:
            self.logger.info("Iter: {}".format(self.n_iter_))
            batch_index = 0
            while batch_index < self.batch_num:
                self.logger.info("Batch_index: {}".format(batch_index))
                host_gradient = self.federation.get(obj_type=MessageType.gradient,
                                                    role=consts.HOST,
                                                    role_idx=0)
                self.logger.info("Get host_gradient from Host, host_gradient.shape: {}".format(host_gradient.shape))
                guest_gradient = self.federation.get(obj_type=MessageType.gradient,
                                                     role=consts.GUEST,
                                                     role_idx=0)
                # aggregate gradient
                gradient = np.hstack((host_gradient, guest_gradient))
                # decrypt gradient
                gradient = self.encryptor.decrypt(gradient)

                # optimization
                optim_gradient = self.optimizer.apply_gradients(gradient)

                # separate optim_gradient according gradient size of Host and Guest
                separate_optim_gradient = HeteroFederatedAggregator.separate(optim_gradient,
                                                                             [host_gradient.shape[0],
                                                                              guest_gradient.shape[0]])
                host_optim_gradient = separate_optim_gradient[0]
                guest_optim_gradient = separate_optim_gradient[1]

                self.federation.remote(obj=host_optim_gradient,
                                       obj_type=MessageType.gradient,
                                       role=consts.HOST,
                                       role_idx=0)
                self.logger.info("Remote host_optim_gradient to Host")
                self.federation.remote(obj=guest_optim_gradient,
                                       obj_type=MessageType.gradient,
                                       role=consts.GUEST,
                                       role_idx=0)
                self.logger.info("Remote host_optim_gradient to Guest")

                # get loss
                loss = self.federation.get(obj_type=MessageType.loss_regular,
                                           role=consts.HOST,
                                           role_idx=0)
                de_loss = self.encryptor.decrypt(loss)
                self.logger.info("Get loss from Host:{}".format(de_loss))

                # if converge
                if self.converge_func.is_converge(de_loss):
                    is_stop = True

                self.federation.remote(obj=is_stop,
                                       obj_type=MessageType.is_stop,
                                       role=consts.HOST,
                                       role_idx=0)
                self.logger.info("Remote is_stop to host:{}".format(is_stop))
                self.federation.remote(is_stop,
                                       obj_type=MessageType.is_stop,
                                       role=consts.GUEST,
                                       role_idx=0)
                self.logger.info("Remote is_stop to guest:".format(is_stop))

                batch_index += 1
                if is_stop:
                    self.logger.info("Model is converged, iter:{}".format(self.n_iter_))
                    break

            self.n_iter_ += 1
            if is_stop:
                break

        self.logger.info("Reach max iter {}, train model finish!".format(self.max_iter))

    def predict(self, data_instances=None, predict_param=None):
        # generate public key and send it to DOs.
        self.logger.info("Starting predicting.")
        public_key = self.encryptor.get_public_key()
        self.federation.remote(obj=public_key,
                               obj_type=MessageType.pub_key,
                               role=consts.HOST,
                               role_idx=0)
        self.logger.info("Remote public key to host.")
        self.federation.remote(obj=public_key,
                               obj_type=MessageType.pub_key,
                               role=consts.GUEST,
                               role_idx=0)
        self.logger.info("Remote public key to guest.")

        pred_label_join_label = self.federation.get(obj_type=MessageType.gradient,
                                                    role=consts.HOST,
                                                    role_idx=0)
        self.logger.info("Get prediction result from host.")
        # enc_pred_label = pred_label_join_label
        de_pred_label = self.encryptor.decrypt(pred_label_join_label)
        pred_label = self.classified(de_pred_label, predict_param.threshold)

        # if pred_label_join_label[1] is not None:
        #     pass

        return pred_label


