""" The client connect to MPC server."""
import proto.mpc_message_pb2_grpc as mpc_message_grpc
import proto.mpc_message_pb2 as mpc_message

from concurrent import futures

import grpc
import logging
import queue
import mpc_server


class MPCClient:
    """
    Client Connected to the MPC.

    Attributes
    ----------
    __mpc_server_address: str, <mpc_server_ip>:<mpc_server_port>
    __is_testing_mode: bool, No real connection if in the testing mode. Used for local test.
    __thread_pool: ThreadPoolExecutor, thread pool to maintain the connection with the server.
    __request_queue: One slot queue of MPCConnectionRequest.
    __response_queue: One slot queue of MPCConnectionResponse.
    __channel: Channel, GRPC Channel.
    __stub: Stub, GRPC service stub.
    """

    def __init__(self, mpc_server_address, is_testing_mode=False):
        self.__mpc_server_address = mpc_server_address
        self.__is_testing_mode = is_testing_mode
        # Only one worker and single item blocking queue because queues are only used by one client.
        self.__thread_pool = futures.ThreadPoolExecutor(max_workers=1)
        self.__request_queue = queue.Queue(maxsize=1)
        self.__response_queue = queue.Queue(maxsize=1)
        # Build the actual connection if not in testing mode.
        if not self.__is_testing_mode:
            # TODO: Change to use a secure channel.
            self.__channel = grpc.insecure_channel(self.__mpc_server_address)
            self.__stub = mpc_message_grpc.MPCServiceStub(self.__channel)

    def _process_events(self):
        """
        Processes the event(request message) sent from the client. Will be blocked until event is available.
        In case of test mode, will directly call server message handler and yield responses.
        In case of the real connection, will yield the request sending to MPC server.
        """
        while True:
            event = self.__request_queue.get()
            logging.debug('Received a request ' + str(event))
            if event.WhichOneof("message_oneof") == "end_message_request":
                self.__request_queue.task_done()
                return

            if self.__is_testing_mode:
                close, yield_msg = mpc_server.MPCServiceImpl().handle_one_message(event, SimpleServicerContext())
                if close:
                    return
                yield yield_msg
            else:
                yield event
            self.__request_queue.task_done()

    def _serve(self):
        """
        Serves requests by sending RPC to MPC server and collecting the response.
        In case of test mode, will directly get the fixed response from _process_events.
        In case of the real connection, will send requests to remote and get responses.
        """
        if self.__is_testing_mode:
            response_iterator = self._process_events()
        else:
            response_iterator = self.__stub.MPCConnection(self._process_events())

        try:
            for response in response_iterator:
                logging.debug('Got an event response ' + str(response))
                self.__response_queue.put(response)
        except Exception as err:
            logging.error("Encountering an error in the serving thread" + str(err))
            raise

    def start(self):
        """Start the thread to handle peer to peer messages"""
        self.__thread_pool.submit(self._serve)
        logging.info('Connection built successfully.')

    def close(self):
        """Close the connection by sending end message to the queue"""
        self.__request_queue.put(mpc_message.MPCConnectionRequest(
            end_message_request=mpc_message.EndMessageRequest()))
        self.__request_queue.join()
        self.__response_queue.join()
        self.__thread_pool.shutdown()
        logging.info('Connection closed.')

    def send_test_message(self, test_message_request):
        """Sends test message to the remote and wait until gets the response.
        :param test_message_request TestMessageRequest.
        :return TestMessageResponse
        """
        self.__request_queue.put(mpc_message.MPCConnectionRequest(
            test_message_request=test_message_request))
        response = self.__response_queue.get()
        self.__response_queue.task_done()
        return response


class SimpleServicerContext:
    """
    Simple implementation of grpc.ServicerContext

    Attributes
    ----------
    code: message code
    details: message details
    """

    def __init__(self):
        self.code = ""
        self.details = ""

    def set_code(self, code):
        self.code = code

    def set_details(self, details):
        self.details = details
