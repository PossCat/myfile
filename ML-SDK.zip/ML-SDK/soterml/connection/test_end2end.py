"""
End to end test
this file is main procedure testing among DO, SS, chain and QC
to run this py file, you must:
1. down and install SoterOneService
2. down and install the chain
3. set address and port right, then start SS and chain
4. run this file

Additionally, ensure your proto files are the same with SS, or you will get
error!
"""
import queue
import time
import unittest
from binascii import unhexlify
import sys
import grpc

sys.path.append('../../')
from soterml.connection.chain import SoterOneChain, ChainEvent
from soterml.connection.proto.soterone_service_pb2 import RegisterQCRequest
from soterml.connection.proto.soterone_service_pb2_grpc import SoteroneServiceStub
from soterml.connection.qc_client import submit_query
from soterml.connection.soterone import get_query_info, query_completed, register_do, register_qc

# if DO monitors the chain event happening, it will call get_query_info
# and place the return here
GET_QUERY_INFO_RES = queue.Queue()


class EndToEndTest(unittest.TestCase):
    """
    test Class
    """

    def setUp(self):
        """
        to do before the test, use the global channel
        """
        # max send(receive) message length is 2M(if streaming, per slice)
        self.channel = grpc.insecure_channel('127.0.0.1:9000',
                                             options=[
                                                 ('grpc.max_send_message_length', 5 * 1024 * 1024),
                                                 ('grpc.max_receive_message_length',
                                                  5 * 1024 * 1024),
                                             ],
                                             )

    def if_query_submitted(self, chain, event: dict):
        """
        call this function if data owner monitors that ss had written model info to chain
        kwargs includes info
        """
        global GET_QUERY_INFO_RES
        # It seems that kwargs['queryUUID'] is a string but its content is Hexadecimal??
        # eg: '0x53515f34656433386633612d373730652d346633622d393830312d616431666564336136306363'
        # I can't convert it to 'SQ_2f7aa74d-345f-4766-9eff-1a3e4c59b47e' easily
        bytes_str = unhexlify(event['queryUUID'][2:])
        query_uuid = bytes_str.decode(encoding='utf-8')
        res, model_path = get_query_info(query_uuid, self.channel)
        self.assertIsNotNone(res, "DO GetQueryInfo error!")
        self.assertIsInstance(model_path, str, "DO save the model error!")
        # save result in global list
        GET_QUERY_INFO_RES.put((res, model_path))

    def test_run(self):
        """
        main of the test
        1. register DO, QC
        2. QC submit_query(send local model)
        3. SS receive and write info to chain
        4. DO monitor the chain and call get_query_info(save the model locally)
        (5). --------DO->MPC->DO-------------- (to do)
        6. DO query_completed to SS(send model)
        7. SS write info to chain(to do)
        (8). QC call GetQueryExecutionInfo(to do)
        """

        #   SS write parameters to chain
        #   DO Monitor the Chain event, if happen, call if_query_submitted
        #   the chain address that you want to monitor
        chain = SoterOneChain('http://132.232.36.171:8545',
                              '872708f77fcdaa388ef3abdc99e331f3cd708d31007dd0bef89d4378c6bba0ac'
                              )
        # the event tpye you monitor
        chain.subscribe(ChainEvent.QuerySubmitted, self.if_query_submitted)
        # ensure the monitor starting
        time.sleep(2)

        # register(DO QC)
        node_info_qc = {'address': '127.0.0.1', 'port': '1234', '_uuid': 'qcnode'}
        node_info_do = {'address': '127.0.0.2', 'port': '1235', 'uuid': 'donode'}
        qc_uuid = register_qc('test_qc_uuid', 'test_key', self.channel,
                              **node_info_qc).uuid
        do_uuid = register_do('test_do_uuid', 'test_key2', self.channel,
                              **node_info_do).uuid
        self.assertIsInstance(qc_uuid, str, "QC register error!")
        self.assertIsInstance(do_uuid, str, "DO register error!")

        # QC submitQuery, the model is from local file
        query_uuid = submit_query('test_uuid', qc_uuid,
                                  'tmp_model/testmodel.pt',
                                  self.channel).uuid
        self.assertIsInstance(do_uuid, str, "QC SubmitQuery error!")

        # if get_query_info_res is not empty, continue else wait
        while True:
            # if there is submit_query chain event, continue
            if not GET_QUERY_INFO_RES.empty():
                time.sleep(1)
                break

        # DO queryCompleted (to SS)
        query_execution_info_dict = {'_uuid': query_uuid,
                                     'start_time_ns': 66,
                                     'finished_time_ns': 666,
                                     'status': 1}
        res_query_completed = query_completed(do_uuid, GET_QUERY_INFO_RES.get()[1],
                                              self.channel, **query_execution_info_dict)
        self.assertIsNotNone(res_query_completed, "QueryCompletedResponse error!")


if __name__ == '__main__':
    unittest.main()
