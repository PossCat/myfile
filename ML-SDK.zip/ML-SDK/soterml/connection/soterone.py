""" receive data from SoteroneService by grpc"""
import os
import time
import json
from binascii import unhexlify

import grpc
import logging
from soterml.connection.utils.soterone_utils import bytes_from_file
from soterml.connection.proto import grpc_service_pb2, grpc_service_pb2_grpc, soterone_data_pb2


# query_uuid:string, channel is created in main scrpit
def get_query_info(query_uuid: str, node_uuid: str,
                   stub: grpc_service_pb2_grpc.SoteroneServiceStub):
    """GetQueryInfo DO gets query information after it is chosen for query training.
    Returns Queryinfo as well as chosen nodes info for P2P connection.
    Returns NOT_FOUND error in cases query is not found.
    query_uuid rpc GetQueryInfo request parameter, it is a string"""
    # build rpc connection with SoteroneService
    getqueryinfo_response = stub.GetQueryInfo(

        grpc_service_pb2.GetQueryInfoRequest(query_uuid=query_uuid, node_uuid=node_uuid))


    return getqueryinfo_response


def query_completed(query_completed_info_dict: dict,
                    stub: grpc_service_pb2_grpc.SoteroneServiceStub):
    """    QueryCompleted DO sends query result after it completes the query training.
    SS sevice will check query results and save query info in case all of DO
    results are received and consistent.
    Returns UNKNOWN error in case query reuslts are not consistent.
    Returns NOT_FOUND error in case query is not found.
    doUuid is a string
    """
    req = grpc_service_pb2.QueryCompletedRequest(
        node_uuid=query_completed_info_dict['node_uuid'],
        query_uuid=query_completed_info_dict['query_uuid'],
        result_token=query_completed_info_dict['result_token'],

        finish_time_ns=query_completed_info_dict['finish_time_ns'],
        count=query_completed_info_dict['count']
    )
    query_completed_response = stub.QueryCompleted(req)

    return query_completed_response


def get_query_execution_info(query_uuid: str, node_uuid: str,
                             stub: grpc_service_pb2_grpc.SoteroneServiceStub):
    """
    to get the trained model for testing, in fact it is used by QC, but testing needs
    """
    req = grpc_service_pb2.GetQueryExecutionInfoRequest(
        node_uuid=node_uuid,
        query_uuid=query_uuid
    )
    res = stub.GetQueryExecutionInfo(req)
    return res


def upload_file(node_uuid: str, file_path: str,
                stub: grpc_service_pb2_grpc.SoteroneServiceStub):
    """

    :param wallet_address:
    :type wallet_address:
    :param file_path:
    :type file_path:
    :param stub:
    :type stub:
    """
    file_bytes = bytes_from_file(file_path, chunk_size=1024 * 1024)
    req = (grpc_service_pb2.UploadFileRequest(
        file=bytes_chunk,
        node_uuid=node_uuid)
        for bytes_chunk in file_bytes
    )
    res = stub.UploadFile(req)
    return res


def download_file(node_uuid: str, token: str, file_path: str,
                  stub: grpc_service_pb2_grpc.SoteroneServiceStub):
    """

    :param wallet_address:
    :type wallet_address:
    :param token:
    :type token:
    :param file_path:
    :type file_path:
    :param stub:
    :type stub:
    """
    req = grpc_service_pb2.DownloadFileRequest(node_uuid=node_uuid, token=token)
    responses = stub.DownloadFile(req)
    try:
        with open(file_path, 'wb') as file:
            for res in responses:
                file.write(res.file)
    except:
        raise IOError('Write File ERROR!')


def register_do(uuid: str, pubkey: str, ip: str, port: str,
                stub: grpc_service_pb2_grpc.SoteroneServiceStub):
    """
    before call this function, you should registerDO in chain
    :param wallet_address:
    :type wallet_address:
    :param pubkey:
    :type pubkey:
    :param ip:
    :type ip:
    :param port:
    :type port:
    :param stub:
    :type stub:
    :return:
    :rtype:
    """
    req = grpc_service_pb2.RegisterDORequest(
        uuid=uuid, public_key=pubkey,
        ip_address=ip, port=port
    )
    res = stub.RegisterDO(req)
    if res.status != 0:
        raise Exception(res.message)
    return res


def register_mpc(uuid: str, pubkey: str, ip: str, port: str,
                 stub: grpc_service_pb2_grpc.SoteroneServiceStub):
    """
    before call this function, you should registerDO in chain
    :param wallet_address:
    :type wallet_address:
    :param pubkey:
    :type pubkey:
    :param ip:
    :type ip:
    :param port:
    :type port:
    :param stub:
    :type stub:
    :return:
    :rtype:
    """
    req = grpc_service_pb2.RegisterMPCRequest(
        uuid=uuid, public_key=pubkey,
        ip_address=ip, port=port
    )
    res = stub.RegisterMPC(req)
    if res.status != 0:
        raise Exception(res.message)
    return res


if __name__ == '__main__':
    from soterml.connection.proto.grpc_service_pb2_grpc import SoteroneServiceStub

    stub = SoteroneServiceStub(grpc.insecure_channel('192.168.1.25:9000'))

    info = {
        'node_uuid': '0xFc805EDd43C76B569c00D998Fe1E74E60aF31213',
        'query_uuid': 'SQ_5f45244f-6cb7-46da-8d4a-ae139c88c611',
        'result_token': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJQYXlsb2FkIjoidGVtcC9RQ19lNWYyMTEzOC0zZTUzLTQ3OWMtOTQ3ZS1jMGIwYzAzODBlZTQvMTYwNzUwOTA4OTI4NzA0NjkwMC50ZW1wIiwiZXhwIjoxNjA3NTEwODg5fQ.1eceWmB02lIr990FLB1XkuaNPir5vlhRvT6vghn_n9k',
        'finish_time_ns': 123,
        'count': 123
    }
    res = query_completed(info, stub)
    print(res)

    # get query info about vertical learning

    # res = get_query_info(wallet_address='0xFc805EDd43C76B569c00D998Fe1E74E60aF31213',
    #                      query_uuid='SQ_001f3f8d-e88e-43e7-a02d-047d8bee58c1',
    #                      stub=stub)
    # print(res)
    # # psi query uuid
    # psi_query_uuid = res.query_info.parent_query_uuid
    # # get psi result for vertical learning
    # res = get_query_execution_info(
    #     query_uuid=psi_query_uuid, node_uuid='0xFc805EDd43C76B569c00D998Fe1E74E60aF31213',
    #     stub=stub)
    # print(res)
    # psi_result_token = res.result
    #
    # psi_res = download_file(node_uuid='0xFc805EDd43C76B569c00D998Fe1E74E60aF31213',
    #                         token=psi_result_token,
    #                         file_path='./psi_res',
    #                         stub=stub)
