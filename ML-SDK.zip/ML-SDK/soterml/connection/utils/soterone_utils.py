
def bytes_from_file(path, chunk_size):
    """
    yield bytes from file
    """
    with open(path, 'rb') as file_object:
        while True:
            chunk_data = file_object.read(chunk_size)
            if not chunk_data:
                # file_object.close()
                return
            yield chunk_data

def gen_upload_file_requestion(wallet_address: str, bytes_gen):
    """

    :param wallet_address:
    :type wallet_address:
    :param bytes_gen:
    :type bytes_gen:
    """
    for bytes_chunk in bytes_gen:
        per_req = grpc_service_pb2.UploadFileRequest(
            file=bytes_chunk,
            wallet_address=wallet_address
        )