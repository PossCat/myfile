"""
Communicate with chain
"""
import json
from enum import Enum, unique
from soterml.connection.chain_connection_helpers import SmartContract, W3Helper,\
    ThreadManager, CHAIN_MAX_TASK_NUM, CHAIN_TASK_NAME_PREFIX, QUEUE_EXIT_SIGNAL
import logging

# const
EVENT_DEFAULT_QUEUE_SIZE = 10
CHAIN_CONTRACT_ADDRESS = '0x2222222222222222222222222222222222222222'


@unique
class ChainEvent(Enum):
    # name -> event name
    # value or signature -> event signature
    DORegistered = 'DORegistered(address doAddr, bytes publicKey, string localVersion, address connectedSS, uint256 stakeIn, uint256 feesPerTraining)'
    ServerReady = 'ServerReady(bytes queryUUID, address nodeAddr, uint8 nodeType)'
    DOUnregistered = 'DOUnregistered(address doAddr)'
    MPCRegistered = 'MPCRegistered(address mpcAddr, bytes publicKey, string localVersion, ' + \
                    'address connectedSS, uint256 stakeIn, uint256 feesPerTraining)'
    MPCUnregistered = 'MPCUnregistered(address mpcAddr)'
    PSIPlan = 'PSIPlan(bytes queryUUID, bytes plan)'
    LogAdded = 'LogAdded(bytes uuid, bytes payload)'
    QuerySubmitted = 'QuerySubmitted(bytes uuid)'
    QueryDispatched = 'QueryDispatched(bytes uuid)'
    QueryProgressUpdated = 'QueryProgressUpdated(bytes uuid, uint64 epoch, uint64 totalEpoch, ' + \
                           'uint64 batchIndex, uint64 totalBatchIndex)'

    @property
    def signature(self):
        return self._value_

@unique
class NodeType(Enum):
    Unknown = 0
    SoterOneService = 1
    DO = 2
    MPC = 3


class SoterOneSmartContract(SmartContract):
    """SorterOne Smart Contract"""

    def __init__(self, url: str, contract_addr: str, queue_size: int):
        """
        :param url: like this: 'http://localhost:8545' - websocket has some concurrency problem
        :param contract_addr: like this: '0x2222222222222222222222222222222222222222'
        :param queue_size:
        """
        super().__init__(W3Helper(url), contract_addr, queue_size)
        # smart contract function list
        self.attrs = {
            # There are no white space for function signature.
            # event signature can be:
            #     EventName(type1 name1, type2 name2)
            #     EventName(type1 indexed name1, type2 name2)
            #     EventName(type1, type2)
            #
            # wrong example:
            # "addLog": ("addLog(bytes,bytes)", False, ["LogAdded(bytes, bytes)"])
            # correct example:
            # "addLog": ("addLog(bytes,bytes)", False, ["LogAdded(bytes,bytes)"])

            # "function_name": (
            #   "function_signature",
            #   `True` if you want to add extra data to end of txdata,
            #   ["event_signature1", "event_signature2"],
            # )
            "registerDO": (
                "registerDO(bytes,string,uint256)",
                False,
                [ChainEvent.DORegistered.signature],
            ),
            "serverStartListening": (
                "serverStartListening(bytes,uint8)",
                False,
                [ChainEvent.ServerReady.signature],
            ),
            "unregisterDO": (
                "unregisterDO()",
                False,
                [ChainEvent.DOUnregistered.signature],
            ),
            "registerMPC": (
                "registerMPC(bytes,string,uint256)",
                False,
                [ChainEvent.MPCRegistered.signature],
            ),
            "submitPSIPlan": (
                "submitPSIPlan(bytes,bytes)",
                False,
                [ChainEvent.PSIPlan.signature]
            ),
            "unregisterMPC": (
                "unregisterMPC()",
                False,
                [ChainEvent.MPCUnregistered.signature],
            ),
            "addLog": (
                "addLog(bytes,bytes)",
                False,
                [ChainEvent.LogAdded.signature],
            ),
            "submitQuery": (
                "submitQuery(bytes)",
                False,
                [ChainEvent.QuerySubmitted.signature],
            ),
            "updateQueryProgress": (
                "updateQueryProgress(bytes,uint64,uint64,uint64,uint64)",
                False,
                [ChainEvent.QueryProgressUpdated.signature],
            )
        }


# SorterOneChain
class SoterOneChain:
    """
    SoterOneChain represent a role which could communicate with SoterOne chain
    """

    def __init__(self, rpc_url: str, private_key: str, context: dict, queue_size=EVENT_DEFAULT_QUEUE_SIZE):
        """
        :param rpc_url: like this: 'ws://localhost:8546'
        :param private_key: like this:
            '872708f77fcdaa388ef3abdc99e331f3cd708d31007dd0bef89d4378c6bba0ac'
        :param context: All information about config are here. like this:
            # {
            #   "config1": {
            #       "ip": "127.0.0.1",
            #       "port": "80",
            #   },
            #   "config2": {
            #       "ip": "127.0.0.1",
            #       "port": "8080",
            #   },
            # }
        """
        self.log = logging.getLogger(self.__class__.__name__)
        self.private_key = private_key
        self.contract = SoterOneSmartContract(rpc_url, CHAIN_CONTRACT_ADDRESS, queue_size)
        self._thread_manager = ThreadManager(
            max_workers=CHAIN_MAX_TASK_NUM,
            thread_name_prefix=CHAIN_TASK_NAME_PREFIX)
        self.context = context

        # _subscriber: {
        #   event_name1: [callback1, callback2...],
        #   event_name2: [callback3, callback4...],
        # }
        self._subscriber = {}

        def _dispatcher():
            # create a thread to post event
            # to all subscriber who subscribe it
            while not self._thread_manager.has_shutdown():
                event = self.contract.events_queue.get()
                if event is QUEUE_EXIT_SIGNAL:
                    self.log.debug('Got queue exit signal')
                    # put QUEUE_EXIT_SIGNAL again
                    # help the queue at other thread could capture QUEUE_EXIT_SIGNAL
                    self.contract.events_queue.put(event)
                    break
                self.log.debug("Got event from queue %s", event)
                if event['event_name'] in self._subscriber:
                    for callback in self._subscriber[event['event_name']]:
                        self._thread_manager.submit(callback, self, event)

        self._thread_manager.submit(_dispatcher)

    def subscribe(self, event: ChainEvent, *callback):
        """
        subscribe event and assign list of callback
        all callback will be triggered if event occur
        :param event:
        :param callback:
        :return:
        """
        if event.name not in self._subscriber:
            self._subscriber[event.name] = list(callback)
            self._thread_manager.submit(
                self.contract.watch, event.signature, None)
        else:
            self._subscriber[event.name].append(callback)

    def shutdown(self, wait=False):
        """
        shutdown stop watching and close all threads
        :return:
        """
        self.contract.exit_all_watch(wait)
        self._thread_manager.shutdown(wait)

    def register_do(self, public_key: str, local_version: str, fees_per_training: int):
        """

        :param public_key:
        :param local_version:
        :param fees_per_training:
        :return:
        """
        public_key_bytes = public_key.encode(encoding='utf-8')
        return self.contract.registerDO(self.private_key, public_key_bytes, local_version, fees_per_training)

    def server_start_listening(self, query_uuid: str, node_type: NodeType):
        """

        :param query_uuid:
        :param node_type:
        :return:
        """
        query_uuid_bytes = query_uuid.encode(encoding='utf-8')
        return self.contract.serverStartListening(self.private_key, query_uuid_bytes, node_type.value)

    def unregister_do(self):
        """

        :return:
        """
        return self.contract.unregisterDO(self.private_key)

    def register_mpc(self, public_key: str, local_version: str, fees_per_training: int):
        """

        :param public_key:
        :param local_version:
        :param fees_per_training:
        :return:
        """
        public_key_bytes = public_key.encode(encoding='utf-8')
        return self.contract.registerMPC(self.private_key, public_key_bytes, local_version, fees_per_training)

    def unregister_mpc(self):
        """

        :return:
        """
        return self.contract.unregisterMPC(self.private_key)

    def add_log(self, uuid: str, payload: dict):
        """
        SDK side needs a function to report status for Smart Contract.
        :param uuid: It is the id of the query.
        :param payload: It contains information about training.
        :return receipt: receipt is a dict, which include block and the event information
        """
        uuid_bytes = uuid.encode(encoding='utf-8')
        payload_bytes = json.dumps(payload).encode(encoding='utf-8')
        return self.contract.addLog(self.private_key, uuid_bytes, payload_bytes)

    def submit_query(self, query_uuid: str):
        """
        query submitted by QC will generate the event called `QuerySubmitted`,
        trigger DO/MPC to train.
        :param query_uuid:
        :return:
        """
        query_uuid_bytes = query_uuid.encode(encoding='utf-8')
        return self.contract.submitQuery(self.private_key, query_uuid_bytes)

    def submit_psi_plan(self, query_uuid: str, plan: dict):
        """

        :param query_uuid:
        :param plan:
        :return:
        """
        query_uuid_bytes = query_uuid.encode(encoding='utf-8')
        plan_bytes = json.dumps(plan).encode(encoding='utf-8')
        return self.contract.submitPSIPlan(self.private_key, query_uuid_bytes, plan_bytes)

    def update_query_progress(self, uuid: str, epoch: int, total_epoch: int, batch_index: int, total_batch_index: int):
        """

        :param uuid:
        :param epoch:
        :param total_epoch:
        :param batch_index:
        :param total_batch_index:
        :return:
        """
        uuid_bytes = uuid.encode(encoding='utf-8')
        return self.contract.updateQueryProgress(self.private_key, uuid_bytes, epoch, total_epoch, batch_index, total_batch_index)