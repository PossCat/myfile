import os

# Temporary files and results
PSI_CACHE_PATH = os.path.abspath(os.path.join(os.getcwd(), "../connection/psi_cache/"))
PSI_LOG_PATH = os.path.abspath(os.path.join(os.getcwd(), "../connection/psi_log/"))
PSI_RESULT_PATH = os.path.abspath(os.path.join(os.getcwd(), "../connection/psi_result/"))

# PSI Server
WORKER_POOL_SIZE = 8


CHAIN_IP = 'http://192.168.1.5:8545'
CHAIN_PRI_KEY = '980b26e2fa86b5a1ca0e3fd6eafcfd226fb868727522022289287ceb7f328768'
PSI_BF_SIZE = 10000000
