import logging
import os
import pickle
from queue import Queue
from typing import List
import shutil
from soterml.connection.psi.utils import psi_util
from soterml.connection.psi.utils.psi_util import PrepareThread, PsiServer
from soterml.connection.psi.utils.psi_status import PsiStatus, END_PSI, PREPARE_FOR_NEXT_ROUND, \
    SEND_DATA_TO_CLIENT, RECEING_DATA_FROM_CLIENT
from soterml.connection.psi.config import psi_config
from soterml.connection.psi.proto import psi_server_pb2_grpc
from soterml.connection.psi.proto import psi_server_pb2


class DoPsiServer(psi_server_pb2_grpc.PsiServerServicer):
    """
    The implementation of the DO PSI Server
    """

    def __init__(self, keyword_strlist: List[str], finish_flag: Queue, tmp_dir: str = './psi_cache',
                 key_bit_length: int = 512):
        self.finish_flag = finish_flag
        self._status = PsiStatus.GET_KEY
        self.psi_server = PsiServer(key_bit_length)
        self.pub_key, self.priv_key = self.psi_server.pubkey, self.psi_server.privkey
        self.origin_data = keyword_strlist
        self.tmp_dir = tmp_dir + '/PSI_SERVER'
        if os.path.exists(self.tmp_dir):
            shutil.rmtree(self.tmp_dir)
            os.mkdir(self.tmp_dir)
        else:
            os.mkdir(self.tmp_dir)

    def DoPsiConnection(self, request_iterator, context):
        """
        the procedure of psi and transport data with a stream connection
        """
        logging.info('PsiServer built a streaming connection with remote')
        for per_request in request_iterator:

            next_step, yield_msg = self.handle_one_request(per_request, context)

            # send file
            if next_step == SEND_DATA_TO_CLIENT:
                for per_res in yield_msg:
                    yield per_res
                # when finish sending file, yiled end_this_round_response
                yield psi_server_pb2.DoPsiConnectionResponse(
                    end_this_round_response=psi_server_pb2.EndThisRoundResponse())
            # receiving the file from client, needn't respond
            elif next_step == RECEING_DATA_FROM_CLIENT:
                # todo: respond when receive each slice
                continue
            # end psi and delete tmp file, write event into the chain
            elif next_step == END_PSI:
                yield yield_msg
                logging.info("This PSI had finished!")
                if os.path.exists(self.tmp_dir):
                    shutil.rmtree(self.tmp_dir)
                    self.finish_flag.put('FINISHED')
                    # os.mkdir(self.tmp_dir)
                break
            # yield response normally
            else:
                yield yield_msg

            # prepare work. When finished, send start_new_round_response()
            # todo too confused
            if next_step == PREPARE_FOR_NEXT_ROUND:
                prepare_work = PrepareThread(
                    func=self.prepare_for_next_round,
                    args=(self._status,))
                prepare_work.start()
                prepare_work.join()
                r = prepare_work.get_result()
                yield r

    def handle_one_request(self, request, context):
        """
        handle a request and yield the request
        """
        request_type = str(request.WhichOneof("message_one_of"))
        logging.info('Receiving request ' + request_type)
        # end this round and prepare for next round
        if request_type == 'end_this_round_request':
            if self._status == PsiStatus.SEND_BLIND_DATA:
                self._status = PsiStatus.GET_SIGNED_DATA
            return PREPARE_FOR_NEXT_ROUND, psi_server_pb2.DoPsiConnectionResponse(
                end_this_round_response=psi_server_pb2.EndThisRoundResponse()
            )
        # ending of psi
        elif request_type == 'end_all_request':
            return END_PSI, psi_server_pb2.DoPsiConnectionResponse(
                end_all_response=psi_server_pb2.EndAllResponse()
            )
        # give client public key
        elif request_type == 'get_pub_key_request':
            res = psi_server_pb2.GetPubKeyResponse()
            res.pub_key.n_bytes = int.to_bytes(self.pub_key.n, length=64, byteorder='big')
            res.pub_key.e = self.pub_key.e
            self._status = PsiStatus.GET_BLOOM_FILTER
            return PREPARE_FOR_NEXT_ROUND, \
                   psi_server_pb2.DoPsiConnectionResponse(get_pub_key_response=res)
        # send client bloom filter with streaming transport
        elif request_type == 'get_bf_request':
            # return the bf file generator
            # serialize the bf and save to local file
            file_path = self.tmp_dir + '/tmp_bf'
            with open(file_path, 'wb') as f:
                pickle.dump(self.bf, f)
            # generate stream responses from local bf's file
            res = psi_util.gen_get_bloom_filter_response(file_path, 3 * 1024 * 1024)
            # return the generator and set next_step = 2
            return SEND_DATA_TO_CLIENT, res
        # receive the blind data from client
        elif request_type == 'send_blind_data_request':
            # receive the blind data from clinet and not respond
            file_path = self.tmp_dir + '/blind_data'
            self._status = PsiStatus.GET_SIGNED_DATA
            with open(file_path, 'ab') as file:
                file.write(request.send_blind_data_request.blind_data.list)
            # need not to respond and set next_step = 3 for loop receiving file
            return RECEING_DATA_FROM_CLIENT, None
        # send signed file to client
        elif request_type == 'get_signed_data_request':
            # return signed data generator
            file_path = self.tmp_dir + '/signed_blind_data'
            res = psi_util.gen_get_signed_blind_data_response(file_path)
            return SEND_DATA_TO_CLIENT, res
        else:
            return 'ERROR REQUEST MESSAGE!'

    # if next_step == 1, start new threading for next round. When finished,
    # return client a StartNewRoundResponse
    def prepare_for_next_round(self, status: PsiStatus):
        """
        prepare for next round
        """
        if status == PsiStatus.GET_BLOOM_FILTER:
            bytes_list = psi_util.strlist_to_byteslist(self.origin_data)
            # Server sign own data
            signed_data_bytes = \
                self.psi_server.server_sign(bytes_list, self.priv_key)
            # insert signed data into bloom filter(build bf from signed data)
            self.bf = \
                self.psi_server.build_bloom_filter(signed_data_bytes,
                                                   capacity=psi_config.PSI_BF_SIZE)
            return psi_server_pb2.DoPsiConnectionResponse(
                start_new_round_response=psi_server_pb2.StartNewRoundResponse()
            )
        if status == PsiStatus.GET_SIGNED_DATA:
            # load the blind_data saved in local
            with open(self.tmp_dir + '/blind_data', 'rb') as file:
                bytes_list = pickle.load(file)
            # signed the blinded data received from Client
            self.signed_blind_data = \
                self.psi_server.server_sign(bytes_list, self.priv_key)
            # save the signed blinded data in local
            with open(self.tmp_dir + '/signed_blind_data', 'wb') as file:
                # file.write(self.signed_blind_data)
                pickle.dump(self.signed_blind_data, file)
            return psi_server_pb2.DoPsiConnectionResponse(
                start_new_round_response=psi_server_pb2.StartNewRoundResponse()
            )
