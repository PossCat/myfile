import copy
import time

from soterml.connection.proto import grpc_service_pb2
from soterml.connection.chain import SoterOneChain
from soterml.connection.chain_connection_helpers import CHAIN_EVENT_GET_FAILED_WAIT_TIME_IN_S


def make_psi_plan(query_uuid: str, psi_do_mpc_info: dict, chain: SoterOneChain):
    """
    when mpc chosen by SS for PSI monitors that the psi query event in the chain, mpc calls this
    function for making psi plan
    @param psi_do_mpc_info: DOs and MPC info that the PSI query includes
    Chain: SoterOneChain, connect with chain, monitor or write event
    """
    b = copy.deepcopy(psi_do_mpc_info)
    del b['QC']
    b = list(b.values())
    planning = {'round1': []}
    num_of_dos = len(b)
    round_num = 1
    left = None
    while num_of_dos > 0:
        if round_num == 1:
            f = iter(b)
        else:
            f = iter(planning['round' + str(round_num - 1)])

        planning['round' + str(round_num)] = []
        # only one DO exist after some PSI rounds, the existed DO makes PSI with QC_DO
        if num_of_dos == 1:
            planning['round' + str(round_num)].append(
                {'Client': psi_do_mpc_info['QC'], 'Server': next(f)['Client']})
            # make QC_DO skipping in all rounds before final PSI
            for round_num in range(1, len(planning)):
                planning['round' + str(round_num)] \
                    .append({'Client': psi_do_mpc_info['QC'], 'Server': psi_do_mpc_info['QC']})
                pass
            break
        while True:
            try:
                planning['round' + str(round_num)].append(
                    {'Client': next(f), 'Server': next(f)} if round_num == 1
                    else {'Client': next(f)['Client'], 'Server': next(f)['Client']})
            except StopIteration:
                # if after a round remains DO, think about making PSI with DO leave before
                if num_of_dos % 2 == 1:
                    # if not round1
                    if round_num != 1:
                        if left is not None:
                            planning['round' + str(round_num)].append(
                                {'Client': planning['round' + str(round_num - 1)][-1]['Client'],
                                 'Server': left})
                        else:
                            # the remaining skipping this round
                            left = planning['round' + str(round_num - 1)][-1][0]
                    else:
                        # if this round is the first round, skip
                        left = (b[-1])
                        planning['round' + str(round_num)].append(
                            {'Client': b[-1], 'Server': b[-1]})
                num_of_dos = int(num_of_dos / 2 + num_of_dos % 2)
                round_num += 1
                break
    print(planning)
    chain.submit_psi_plan(query_uuid, planning)
    time.sleep(CHAIN_EVENT_GET_FAILED_WAIT_TIME_IN_S)


def callback_of_psi_submitted(chain, event):
    """
    when monitor psi query submitted, call this function
    """
    mute.acquire()
    event_dict['PSI_SUBMITTED'] = event['uuid']
    mute.release()


def res_to_psi_plan_dict(res: grpc_service_pb2.GetQueryInfoResponse):
    """
    create psi node info dict from get_query_info_response from SoteroneService
    """
    psi_node_info = {}
    do_num = 1
    # the dict that make_psi_plan needs, (node type(DO and QC_DO) and chain address)
    for i in res.query_cluster.nodeInfo:
        if i.node_type == 1:
            psi_node_info['DO' + str(do_num)] = i.node_uuid
            do_num += 1
        elif i.node_type == 3:
            psi_node_info['QC'] = i.node_uuid
    return psi_node_info
