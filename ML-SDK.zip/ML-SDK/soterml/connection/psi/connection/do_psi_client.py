import logging
import pickle
from typing import List
import os
import shutil
from soterml.connection.psi.proto import psi_server_pb2, psi_server_pb2_grpc
from soterml.connection.psi.utils import psi_util
from soterml.connection.psi.utils.psi_util import client_gen_random, client_blind, client_unblind, \
    PK
from soterml.connection.chain import SoterOneChain
from soterml.learning.vertical.utils.log import Log
from soterml.mpc.p2p_connection_base_client import P2PConnectionClient


class DoPsiClient(P2PConnectionClient):
    """
    client of PSI between 2 DOs
    """

    def __init__(self, strlist: List[str], psi_server_addr: str, tmp_dir: str = './psi_cache'):
        super().__init__(psi_server_addr)
        self.data = psi_util.strlist_to_byteslist(strlist)
        self._tmp_dir = tmp_dir + '/PSI_CLIENT'
        self._stub = psi_server_pb2_grpc.PsiServerStub(self._channel)
        self._log = Log(__name__).getlog()
        # for saving temporary files
        if os.path.exists(self._tmp_dir):
            shutil.rmtree(self._tmp_dir)
            os.mkdir(self._tmp_dir)
        else:
            os.mkdir(self._tmp_dir)

    def close(self):
        """
        close the client unless all tasks are over.
        """
        self.send_request(psi_server_pb2.DoPsiConnectionRequest(
            end_all_request=psi_server_pb2.EndAllRequest()))
        self.get_request_result()
        # wait queue task is finished and shutdown thread_pool
        super(DoPsiClient, self).close()
        # delete temporary files
        if os.path.exists(self._tmp_dir):
            shutil.rmtree(self._tmp_dir)

    def _serve(self):
        response_iterator = self._stub.DoPsiConnection(self._process_events())
        try:
            for response in response_iterator:
                logging.debug('Got an event response ' + str(response))
                self._response_queue.put(response)
        except Exception as err:
            logging.error("Encountering an error in the serving thread" + str(err))
            raise

    def psi_procedure(self, server_client_uuid: dict, chain: SoterOneChain):
        """
        main procedure of PSI betweent 2 DO
        """

        psi_log = dict()
        psi_log['log_type'] = 'PSI_LOG'
        psi_log['uuid'] = server_client_uuid
        psi_log['message'] = 'PSI between %s(Server) and %s(Client) starts!' \
                             % (server_client_uuid['Server'], server_client_uuid['Client'])
        chain.add_log(server_client_uuid['Client'], psi_log)

        get_key_req = psi_server_pb2.DoPsiConnectionRequest(
            get_pub_key_request=psi_server_pb2.GetPubKeyResquest()
        )
        self.send_request(get_key_req)
        res = self.get_request_result()
        self.n = int.from_bytes(res.get_pub_key_response.pub_key.n_bytes, byteorder='big')
        self.e = res.get_pub_key_response.pub_key.e
        # todo: add_log

        # wait for server building bloom filter
        logging.info('waiting for server building bloom filter')
        # if not self.__response_queue.empty():
        res = self.get_request_result()
        response_type = str(res.WhichOneof("message_one_of"))
        assert response_type == 'start_new_round_response', 'Receive error response type!'

        get_bloom_filter_req = psi_server_pb2.DoPsiConnectionRequest(
            get_bf_request=psi_server_pb2.GetBloomFilterRequest()
        )
        self.send_request(get_bloom_filter_req)
        res = self.get_request_result()

        # receive bloom filter from server, when receive end_this_round_response, close writing
        # todo: write event
        psi_log = dict()
        psi_log['log_type'] = 'PSI_LOG'
        psi_log['uuid'] = server_client_uuid
        psi_log['message'] = 'Client has received bloom filter'
        # chain.add_log(server_client_uuid['Client'], psi_log)
        # todo file name may be duplipicated error
        file_path = self._tmp_dir + '/received_bloom_filter'
        # todo redis ?
        with open(file_path, 'wb') as file:
            file.write(res.get_bf_response.bf.list)
            while True:
                res = self.get_request_result()
                request_type = str(res.WhichOneof("message_one_of"))
                if request_type == 'end_this_round_response':
                    break
                file.write(res.get_bf_response.bf.list)
        # load the bloom filter
        with open(file_path, 'rb') as file:
            self.bf = pickle.load(file)

        # blind client's data
        # todo: write event
        psi_log = dict()
        psi_log['log_type'] = 'PSI_LOG'
        psi_log['uuid'] = server_client_uuid
        psi_log['message'] = 'Client is blinding the data'
        # chain.add_log(server_client_uuid['Client'], psi_log)
        pk = PK(self.n, self.e)
        self.random_list = client_gen_random(pk, len(self.data))
        blind_data = client_blind(self.data, pk, self.random_list)
        # serialize the blind data
        file_path = self._tmp_dir + '/blind_data'
        with open(file_path, 'wb') as file:
            pickle.dump(blind_data, file)
        # generate stream request from the file
        req = psi_util.gen_send_blind_data_request(file_path)
        # send blind data
        # todo: write event
        psi_log = dict()
        psi_log['log_type'] = 'PSI_LOG'
        psi_log['uuid'] = server_client_uuid
        psi_log['message'] = 'Client is sending the blinded data'
        # chain.add_log(server_client_uuid['Client'], psi_log)
        for per_req in req:
            self.send_request(per_req)
        # send end_this_round_request as the ending of sending blind file
        self.send_request(psi_server_pb2.DoPsiConnectionRequest(
            end_this_round_request=psi_server_pb2.EndThisRoundRequest()
        )
        )
        # todo: write event
        psi_log = dict()
        psi_log['log_type'] = 'PSI_LOG'
        psi_log['uuid'] = server_client_uuid
        psi_log['message'] = 'Client has sended blinded data'
        # chain.add_log(server_client_uuid['Client'], psi_log)
        # assure server receiving correctly
        res = self.get_request_result()
        request_type = str(res.WhichOneof("message_one_of"))
        assert request_type == 'end_this_round_response', 'Receive error response type!'

        # when server send the start_new_round_response, it means that server had signed the
        # blind data, server is ready to send the signed data
        res = self.get_request_result()
        request_type = str(res.WhichOneof("message_one_of"))
        if request_type == 'start_new_round_response':
            get_signed_req = psi_server_pb2.DoPsiConnectionRequest(
                get_signed_data_request=psi_server_pb2.GetSignedBlindDataRequest()
            )
            self.send_request(get_signed_req)
            # receiving signed data as local file
            file_path = self._tmp_dir + '/signed_blind_data'
            # todo: write event
            psi_log = dict()
            psi_log['log_type'] = 'PSI_LOG'
            psi_log['uuid'] = server_client_uuid
            psi_log['message'] = 'Client has received signed data'
            # chain.add_log(server_client_uuid['Client'], psi_log)
            with open(file_path, 'wb') as file:
                while True:
                    res = self.get_request_result()
                    request_type = str(res.WhichOneof("message_one_of"))
                    # server send end_this_round_response as the ending flag
                    if request_type == 'end_this_round_response':
                        # todo: add_log
                        # psi_util.add_log('RECEIVING SIGNED DATA FINISHED')
                        break
                    file.write(res.get_signed_data_response.signed_blind_data.list)
            # load the signed data
            with open(file_path, 'rb') as file:
                self.signed_blind_data = pickle.load(file)
            logging.info('Client has received the signed data')
            # unblind the signed data
            pk = PK(self.n, self.e)
            unblind_data = client_unblind(self.signed_blind_data, pk, self.random_list)
            # todo: add_log
            psi_log = dict()
            psi_log['log_type'] = 'PSI_LOG'
            psi_log['uuid'] = server_client_uuid
            psi_log['message'] = 'Client has get intersection'
            # chain.add_log(server_client_uuid['Client'], psi_log)
            self._result = []
            # get intersection by the bloom filter's 'check()' function
            for i in range(len(self.data)):
                if self.bf.check(unblind_data[i]):
                    self._result.append(self.data[i].decode())

            return self._result
