"""
    The status of the psi between two DOs.
    GET_KEY: Server generate Key, and send to Client
    GET_BLOOM_FILTER: Server build bloom filter with its own signed data
    GET_BLIND_DATA: Client blind its own data and send to Server
    GET_SIGNED_DATA: Server sign the data received from Client and send back to Client
    GET_INTERSECTION: Client get the intersection and send to Server
"""
from enum import Enum

END_PSI = -1
PREPARE_FOR_NEXT_ROUND = 1
SEND_DATA_TO_CLIENT = 2
RECEING_DATA_FROM_CLIENT = 3


class PsiStatus(Enum):
    """
    status of psi procedure
    """
    GET_KEY = 1
    GET_BLOOM_FILTER = 2
    SEND_BLIND_DATA = 3
    GET_SIGNED_DATA = 4
    SEND_INTERSECTION = 5
