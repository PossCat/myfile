"""
use for the rsa-psi
"""
import threading
import gmpy2
import rsa
from rsa import transform
from typing import List
from secrets import randbelow
from soterml.connection.psi.proto import psi_server_pb2
from soterml.connection.psi.utils import bloom_filter
from soterml.connection.psi.proto.psi_server_pb2 import GetBloomFilterResponse, \
    SendBlindDataRequest, GetSignedBlindDataResponse



def add_log(msg):
    pass


class PsiServer:
    """
    the functions in the PSI server such as generating RSA-KEY, signing data and building bloom
    filter, but this class dosen't send or receive the data from client, it's done by the
    GrpcPsiServer
    """

    def __init__(self, bit_length):
        self.pubkey, self.privkey = self.generate_key(bit_length)

    def server_sign(self, bytes_list, privkey):
        """
        Server sign the data with server's private key d.
        """
        signed_list = []
        for B in bytes_list:
            signed_list.append(
                transform.int2bytes(int(
                    gmpy2.powmod(
                        int.from_bytes(B, byteorder='big', signed=False),
                        privkey.d,
                        privkey.n
                    )
                ))
            )

        return signed_list

    def generate_key(self, bit_length):
        """
        server generates the RSA-KEY (pubkey, privkey)
        """
        pubkey, privkey = rsa.newkeys(bit_length)

        return pubkey, privkey

    def build_bloom_filter(self, signed_list: List[bytes], capacity=10000000, fp_prob=None):
        """
        build a bloom filter based on the signed_list(bytes)
        """
        bf = bloom_filter.build_from(signed_list, capacity=capacity, fp_prob=fp_prob)

        return bf


class PrepareThread(threading.Thread):
    """
    In PsiServer, prepare for next round such as creating bloom filter or signing data
    """

    def __init__(self, func, args=()):
        super(PrepareThread, self).__init__()
        self.func = func
        self.args = args

    def run(self):
        """
        what to do
        """
        self.result = self.func(*self.args)

    def get_result(self):
        """
        get result
        """
        try:
            return self.result
        except Exception:
            raise


class PK:
    """
    public key class
    """

    def __init__(self, n, e):
        self.n = n
        self.e = e


def server_sign(bytes_list, privkey):
    """
    Server sign the data with server's private key d.
    """
    signed_list = []
    for B in bytes_list:
        signed_list.append(
            transform.int2bytes(int(
                gmpy2.powmod(
                    int.from_bytes(B, byteorder='big', signed=False),
                    privkey.d,
                    privkey.n
                )
            ))
        )

    return signed_list


def client_blind(bytes_list, pubkey, random_list):
    """
    client blind its own data using the random_factors
    """
    blind_list = []

    for i in range(len(bytes_list)):
        blind_list.append(
            int_to_bytes(
                mulmod(
                    int.from_bytes(bytes_list[i], byteorder='big', signed=False),
                    int(random_list[i][1]),
                    int(pubkey.n)
                )
            )
        )

    return blind_list


def client_unblind(signed_blind_list, pubkey, random_list):
    """
    client unblind the signed blinded data with the random_factors
    """
    unblind_list = []
    for i in range(len(signed_blind_list)):
        unblind_list.append(
            transform.int2bytes(int(
                mulmod(
                    bytes_to_int(signed_blind_list[i]),
                    int(random_list[i][0]),
                    pubkey.n)
            )
            )
        )
    return unblind_list


def client_gen_random(pubkey, len_of_client):
    """
    client generate the random_factors for blinding and unblinding its own data
    """
    random_factors = []
    for _ in range(len_of_client):
        r = randbelow(pubkey.n)
        r_inv = inverse(pubkey, r)
        r_encrypted = encrypt(pubkey, r)
        random_factors.append((r_inv, r_encrypted))
    return random_factors


def generate_key(bit_length):
    """
    generate public and private key
    """
    pubkey, privkey = rsa.newkeys(bit_length)
    return pubkey, privkey


def mulmod(x, a, n):
    """
    for blinding and unblinding client's data
    """
    return (x * a) % n


def inverse(key, x):
    """
    x * y mod N == 1
    return y
    """
    n = key.n
    return gmpy2.invert(x, n)


def encrypt(key, pt):
    """
    for generating random_factors and server to sign
    """
    e, n = key.e, key.n
    return gmpy2.powmod(pt, e, n)


def strlist_to_byteslist(strlist):
    """
    transform string list to bytes list
    """
    bytes_list = []
    for i in range(len(strlist)):
        bytes_list.append(strlist[i].encode('utf-8'))
    return bytes_list


def int_to_bytes(i):
    """
    transform in to bytes
    """
    return transform.int2bytes(i)


def bytes_to_int(b):
    """
    rtransform bytes to int
    """
    return transform.bytes2int(b)


def monitor_psi_end(server_ip_addr: str):
    """
    ??
    """
    # psi client monitor the server which client will connect with. if the server is free(
    # finished psi with other DOs). Then the client can start the psi with this server
    pass


def gen_get_bloom_filter_response(file_path: str, chunk_size: int = 1024 * 1024 * 3):
    """
    content is generator of bytes
    the function generate requests by per bytes(in content) because this rpc function use the
    streaming transporting,it needs a request streaming not just a request.
    """
    with open(file_path, 'rb') as file_object:
        while True:
            chunk_data = file_object.read(chunk_size)
            # print(chunk_data)
            if not chunk_data:
                break
            req = GetBloomFilterResponse()
            req.bf.list = chunk_data
            yield psi_server_pb2.DoPsiConnectionResponse(get_bf_response=req)


def gen_send_blind_data_request(file_path: str, chunk_size: int = 1024 * 1024 * 3):
    """
    generate send blinded data requests (use for psi server)
    """
    with open(file_path, 'rb') as file_object:
        while True:
            chunk_data = file_object.read(chunk_size)
            if not chunk_data:
                break
            req = SendBlindDataRequest()
            req.blind_data.list = chunk_data
            yield psi_server_pb2.DoPsiConnectionRequest(
                send_blind_data_request=req
            )


def gen_get_signed_blind_data_response(file_path: str, chunk_size: int = 1024 * 1024 * 3):
    """
    generate get signed blind data responses (use for psi server)
    """
    with open(file_path, 'rb') as file_object:
        while True:
            chunk_data = file_object.read(chunk_size)
            # print(chunk_data)
            if not chunk_data:
                break
            req = GetSignedBlindDataResponse()
            req.signed_blind_data.list = chunk_data
            yield psi_server_pb2.DoPsiConnectionResponse(
                get_signed_data_response=req
            )
