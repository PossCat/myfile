import time
from binascii import unhexlify
from concurrent import futures
from queue import Queue
import grpc
import pickle
from soterml.connection.psi.config import psi_config
from soterml.connection.psi.proto import psi_server_pb2_grpc
from soterml.connection.psi.connection.do_psi_client import DoPsiClient
from soterml.connection.psi.connection.do_psi_server import DoPsiServer
from soterml.connection.chain import SoterOneChain, NodeType


# intersection result is NULL, will lead to PSI breaking
def do_start_psi(ip_addr: str, do_uuid: str, event: dict, data: list, chain: SoterOneChain):
    """
    when PSI procedure starts, every DO call this function.
    This function decides when and what the DO plays in the PSI procedure(which round and Server or
    client)
    """
    # todo: NULL PSI result leads to stop PSI
    finish_flag = Queue()
    # the result get from psi, it is none at first
    intersection = None
    # which role this DO plays and whether it have intersection result
    is_psi_client = False
    is_psi_server = False
    is_has_intersection = False
    # travel the psi_planning
    for round_num in range(1, len(event) + 1):
        for uuid in event['round' + str(round_num)]:
            # index 0 in each couples means client
            if uuid['Client'] == do_uuid:
                # if server and client are both self, it means skip this round
                if uuid['Server'] == do_uuid:
                    break
                is_psi_client = True
                # get the server's ip and port from the query_info
                server_ip_addr = psi_node_ip_port[uuid['Server']]
            # index 1 in each couples means server
            elif uuid['Server'] == do_uuid:
                is_psi_server = True

            if is_psi_server:
                server_finished = Queue()
                is_psi_server = False
                server = grpc.server(futures.ThreadPoolExecutor(
                    max_workers=psi_config.WORKER_POOL_SIZE))
                # if the DO has intersection got before, using it to init Server
                data = intersection if is_has_intersection else data
                psi_server_pb2_grpc.add_PsiServerServicer_to_server(
                    DoPsiServer(keyword_strlist=data, tmp_dir=psi_config.PSI_CACHE_PATH + do_uuid,
                                finish_flag=finish_flag),
                    server)
                server.add_insecure_port(ip_addr)
                server.start()
                chain.server_start_listening(do_uuid, NodeType.DO)
                try:
                    while True:
                        time.sleep(1)
                        if not finish_flag.empty():
                            if finish_flag.get() == 'FINISHED':
                                # todo: write event to the chain
                                server_finished.put(f'{do_uuid}')
                                server.stop(0)
                                break
                except Exception:
                    pass
            elif is_psi_client:
                is_psi_client = False
                # if the DO has intersection got before, using it to init Client
                data = intersection if is_has_intersection else data
                dc = DoPsiClient(strlist=data, psi_server_addr=server_ip_addr,
                                 tmp_dir=psi_config.PSI_CACHE_PATH + do_uuid)
                # sleep to mock monitor, because the server may be not ready for PSI
                time.sleep(1)
                # todo: monitor the chain that whether the server has started
                while True:
                    time.sleep(1)
                    mute.acquire()
                    if 'SERVER_READY' in event_dict:
                        del event_dict['SERVER_READY']
                        mute.release()
                        break
                    mute.release()
                # start client
                dc.start()
                # start psi with server
                intersection = dc.psi_procedure(
                    {'Client': do_uuid, 'Server': uuid['Server']}, chain)

                # the DO gets intersection, next round it can use the data to init
                is_has_intersection = True
                # close client
                dc.close()
                with open(psi_config.PSI_RESULT_PATH + do_uuid, 'wb') as file:
                    pickle.dump(intersection, file)

                # enter next round
                round_num += 1
                print(f'PSI between {do_uuid}(C) and {uuid["Server"]}(S) had been done!\r\n'
                      f'The intersection is {intersection}\r\n')


def callback_of_psi_submitted(chain, event):
    """
    when submit psi query, add 'PSI_SUBMITTED' to event_dict
    """
    mute.acquire()
    event_dict['PSI_SUBMITTED'] = event['uuid']
    mute.release()


def callback_of_psi_server_ready(chain, event):
    """
    when psi server is ready, add server_ready to event_chain
    todo: the server uuid is not implemented now, can not judge which server
    """
    mute.acquire()
    event_dict['SERVER_READY'] = event['nodeAddr']
    mute.release()


def callback_of_psi_plan(chain, event):
    """
    when psi plan is submitted in the chain, put 'PSI_PLAN' event in the chain
    """
    bytes_str = unhexlify(event['plan'][2:])
    plan = bytes_str.decode(encoding='utf-8')
    mute.acquire()
    event_dict['PSI_PLAN'] = eval(plan)
    mute.release()


def callback_of_null_psi_result(chain, event):
    """
    todo: no this event now
    """
    mute.acquire()
    event_dict['NULL_PSI_RESULT'] = query_uuid
    mute.release()
