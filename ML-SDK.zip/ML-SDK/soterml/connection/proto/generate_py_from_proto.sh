#!/usr/bin/env bash

python -m grpc_tools.protoc -I ./ --python_out=./ --grpc_python_out=./  grpc_service.proto
python -m grpc_tools.protoc -I ./ --python_out=./ --grpc_python_out=./  soterone_data.proto
python -m grpc_tools.protoc -I ./ --python_out=./ --grpc_python_out=./  mpc_message.proto