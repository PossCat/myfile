"""
This file is temporary for query customer, but there isn't sdk for qc in planning now.
Maybe this file will be remove later.
"""

from soterml.connection.proto import soterone_service_pb2 as soterone_service_pb2
from soterml.connection.proto import soterone_service_pb2_grpc as soterone_service_pb2_grpc
from soterml.connection.utils.soterone_utils import bytes_from_file


def gen_submit_query(uuid: str, qc_uuid: str, content):
    """
    content is a generator that generates bytes
    this function return streams of request from local file's bytes
    """
    for chunk in content:
        req = soterone_service_pb2.SubmitQueryRequest()
        req.query_info.uuid = uuid
        req.query_info.qc_uuid = qc_uuid
        req.query_info.content = chunk
        yield req


def submit_query(uuid: str, qc_uuid: str, content_path: str, channel):
    """
    SubmitQuery Query customer submits the query. SS sevice will save query info,
    chose DO and MPC nodes and notify the chain.
    """

    stub = soterone_service_pb2_grpc.SoteroneServiceStub(channel)
    bytes_data = bytes_from_file(content_path, 3*1024*1024)
    req = gen_submit_query(uuid, qc_uuid, bytes_data)

    submit_query_res = stub.SubmitQuery(req)
    print('send submit_query_request successful!')

    return submit_query_res
