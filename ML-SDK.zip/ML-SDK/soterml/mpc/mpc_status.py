import threading
import logging
import proto.mpc_message_pb2 as mpc_message
import numpy as np


class MPCServerStatus:
    """
    This class maintains the statuses of the MPC service. It will be modified by the chain
    worker as well as the RPC server.

    Attributes
    ----------
    __query_cluster_map:    Thread safe dictionary. [query_uuid, QueryCluster]. Will be cleaned up once get the
                            notification from the chain that query is completed.
    __gradients_status_map: Thread safe dictionary. [query_uuid, [epoch, [do_uuid, AggregationRequest]]]
                            This map is to keep track of intermediate state during the process of DOs sending
                            aggregation requests. Map will be cleaned up after aggregation is done and put the result in
                            __gradients_result_map.
    __gradients_conditions: Thread safe dictionary. [query_uuid, [epoch, condition_variable]].
                            This map is to keep track of conditional variable for each query epoch. Will be cleaned up
                            once get the notification from the chain that query is completed.
    __gradients_result_map: Thread safe dictionary. [query_uuid, [epoch, global_gradients]].
                            This map is to store aggregation results for each epoch. Will be cleaned up once get the
                            notification from the chain that query is completed.
    __lock:                 Map lock for check_and_update operations.
    """

    def __init__(self):
        self.__query_cluster_map = {}
        self.__gradients_status_map = {}
        self.__gradients_conditions = {}
        self.__gradients_result_map = {}
        self.__lock = threading.Lock()

    def _is_do_in_query_cluster(self, do_uuid, query_uuid):
        """
        Checks if DO is a valid DO regarding to the query.
        If the query cluster has been listened, directly check existence.
        If the query cluster has not been listened, poll for x minutes and check existence.
        :param do_uuid: str
        :param query_uuid: str
        :return: bool: Check result.
        """
        # TODO: Add impl once chain is ready, make sure updates is atomic and thread compatible.
        return True

    def add_query_cluster(self, query_uuid, query_cluster):
        """
        Adds relevant query cluster into the dictionary after getting notification from the chain.
        :param query_uuid: string
        :param query_cluster: QueryCluster
        """
        self.__query_cluster_map[query_uuid] = query_cluster

    def query_clean_up(self, query_uuid):
        """
        Cleans up given query statuses
        :param query_uuid: str
        """
        self.__query_cluster_map.pop(query_uuid, None)
        self.__gradients_status_map.pop(query_uuid, None)
        self.__gradients_conditions.pop(query_uuid, None)
        self.__gradients_result_map.pop(query_uuid, None)

    def get_query_result(self, query_uuid, epoch):
        """
        Returns query result given query_uuid and epoch
        Returns None if result is not found
        :param query_uuid: str
        :param epoch: int
        :return: float list: query result
        """
        if query_uuid not in self.__gradients_status_map:
            return None
        return self.__gradients_result_map[query_uuid].get(epoch, None)

    def submit_gradients(self, agg_message):
        """
        Submits local gradients for one epoch.
        :param agg_message: AggregationRequest
        :return: bool: gradients input is valid or not.
        """
        if not self._is_do_in_query_cluster(agg_message.do_uuid, agg_message.query_uuid):
            return False

        # No-ops if the query is already submitted or aggregation has completed.
        if agg_message.query_uuid in self.__gradients_result_map and \
                agg_message.epoch in self.__gradients_result_map[agg_message.query_uuid]:
            return True

        logging.info(
            "Query:" + agg_message.query_uuid + " epoch:" + str(agg_message.epoch) + " DO:" + agg_message.do_uuid +
            " has submitted gradients")

        # Create new entries if needed
        self.__lock.acquire(blocking=True)
        if agg_message.query_uuid not in self.__gradients_result_map:
            self.__gradients_result_map[agg_message.query_uuid] = {}

        if agg_message.query_uuid not in self.__gradients_status_map:
            self.__gradients_status_map[agg_message.query_uuid] = {}

        if agg_message.epoch not in self.__gradients_status_map[agg_message.query_uuid]:
            self.__gradients_status_map[agg_message.query_uuid][agg_message.epoch] = {}
        self.__lock.release()

        self.__gradients_status_map[agg_message.query_uuid][agg_message.epoch][agg_message.do_uuid] = agg_message
        return True

    def wait_or_aggregate(self, query_uuid, epoch):
        """
        Waits for aggregation until all DOs in the query cluster submitted the request. Or does aggregation if all DOs
        are ready.
        Will throw timeout or other exception if any wrong during the aggregation.
        :param query_uuid: str
        :param epoch: int
        :return: float list: aggregated_gradients
        """
        # No-ops if the query has already submitted or aggregation has completed.
        if query_uuid in self.__gradients_result_map and epoch in self.__gradients_result_map[query_uuid]:
            return self.__gradients_result_map[query_uuid][epoch]

        # Create new condition variable if needed.
        self.__lock.acquire(blocking=True)
        if query_uuid not in self.__gradients_conditions:
            self.__gradients_conditions[query_uuid] = {}

        if epoch not in self.__gradients_conditions[query_uuid]:
            self.__gradients_conditions[query_uuid][epoch] = threading.Condition()
        cv = self.__gradients_conditions[query_uuid][epoch]
        self.__lock.release()

        # Lock uses condition variable instead of semaphore now. So multiple aggregations can happen at the same time.
        with cv:
            submitted_dos = len(self.__gradients_status_map[query_uuid][epoch])
            total_dos = len(self.__query_cluster_map[query_uuid].do_nodes)
            logging.info("Query:" + query_uuid + " epoch:" + str(epoch) + " has gradients submitted DOs:" + str(
                submitted_dos) + " vs total DOs:" + str(total_dos))
            if submitted_dos == total_dos:
                self.__gradients_result_map[query_uuid][epoch] = self._do_aggregation(query_uuid, epoch)
                logging.info("Notify all DO requested threads")
                cv.notifyAll()
                # Clean up local gradients after the aggregation.
                self.__gradients_status_map[query_uuid].pop(epoch, None)
            else:
                # TODO: Add timeout
                cv.wait()
        return self.__gradients_result_map[query_uuid][epoch]

    def _do_aggregation(self, query_uuid, epoch):
        """
        Does aggregation based on the current status
        Will raise exception in case of any aggregation error.
        :param query_uuid:
        :param epoch:
        :return: float list: Global gradients.
        """
        logging.info("Aggregation starts.")

        # Get the first value from status map to identify what aggregation we are doing.
        first_request = next(iter(self.__gradients_status_map[query_uuid][epoch].values()))
        if first_request.agg_type == mpc_message.AggregationRequest.WEIGHT_AVG:
            return weight_avg_aggregation(self.__gradients_status_map[query_uuid][epoch].values())

        raise NotImplementedError("Unknown aggregation type: " + str(first_request.agg_type))


def weight_avg_aggregation(requests):
    """
    Does weight average aggregation.
    :param requests: List of AggregationRequest
    :return: float list: Global gradients.
    """
    local_gradients = []
    weights = []
    for request in requests:
        local_gradients.append(np.array(request.gradients))
        weights.append(1 if request.data_size == 0 else request.data_size)

    return np.average(local_gradients, axis=0, weights=weights).tolist()
