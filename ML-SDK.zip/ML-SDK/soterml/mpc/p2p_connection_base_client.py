import logging
import queue
from concurrent import futures

import grpc

# from soterml.learning.vertical.utils.log import Log


class P2PConnectionClient:
    """
    p2p grpc long connection client
    """

    def __init__(self, grpc_server_address: str):
        self._thread_pool = futures.ThreadPoolExecutor(max_workers=8)
        self._request_queue = queue.Queue(maxsize=5)
        self._response_queue = queue.Queue(maxsize=5)
        self._channel = grpc.insecure_channel(grpc_server_address)
        self._log = logging.getLogger()

    def _process_events(self):
        while True:
            event = self._request_queue.get()
            self._log.debug('Received a request ' + str(event)[:50])
            yield event
            self._request_queue.task_done()

    def _serve(self):
        # response_iterator = self._stub.DoPsiConnection(self._process_events())
        # try:
        #     for response in response_iterator:
        #         logging.debug('Got an event response ' + str(response))
        #         self._response_queue.put(response)
        # except Exception as err:
        #     logging.error("Encountering an error in the serving thread" + str(err))
        #     raise
        pass

    def start(self):
        """
        start the client
        """
        self._thread_pool.submit(self._serve)
        # self._log.debug('Connection with Server built successfully.')

    def close(self):
        """
        close the client
        """
        self._request_queue.join()
        self._response_queue.join()
        self._thread_pool.shutdown()
        # self._log.debug('Connection closed.')

    def send_request(self, request):
        """
        put request in the queue
        """
        self._request_queue.put(request)

    def get_request_result(self):
        """
        get result from the queue
        """
        response = self._response_queue.get()
        self._response_queue.task_done()
        return response
