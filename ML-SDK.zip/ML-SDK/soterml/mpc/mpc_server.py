"""The actual implementation of MPC Server. Get the interface from MPCServiceServicer"""
import proto.mpc_message_pb2_grpc as mpc_message_grpc
import proto.mpc_message_pb2 as mpc_message

from concurrent import futures

import grpc
import logging
import sys
import time
import mpc_chain
import mpc_status

# Constants
_WORKER_POOL_SIZE = 20
_ONE_DAY_IN_SECONDS = 60 * 60 * 24


class MPCServiceImpl(mpc_message_grpc.MPCServiceServicer):
    """
    The implementation of the MPC Service

    Attributes
    ----------
    __server_status: MPCServerStatus, maintain statuses of the server.
    __chain_worker: MPCChainWorker, send or receive information to/from the chain
    """

    def __init__(self, server_status=None, chain_worker=None):
        self.__server_status = server_status if server_status is not None else mpc_status.MPCServerStatus()
        self.__chain_worker = chain_worker if chain_worker is not None else mpc_chain.MPCChainWorker(
            self.__server_status)

    def MPCConnection(self, request_iterator, context):
        """
        Handle connection messages
        :param request_iterator. An Iterator of MPCConnectionRequest
        :param context ServicerContext, rpc call context
        :return yield response message to the caller.
        """
        logging.info('Built a streaming connection with remote.')
        for request_message in request_iterator:
            close, yield_msg = self.handle_one_message(request_message, context)
            if close:
                break
            yield yield_msg
        logging.info('Connection closed.')

    def handle_one_message(self, request_message, context):
        """
        Handle one connection message
        :param request_message MPCConnectionRequest incoming request
        :param context ServicerContext, rpc call context
        :returns (bool, MPCConnectionResponse), (should connection be closed, the response of the request.)
        """
        request_type = str(request_message.WhichOneof("message_oneof"))
        logging.info('Receiving request ' + request_type)
        # Handle different request types
        if request_type == "test_message_request":
            return False, mpc_message.MPCConnectionResponse(
                test_message_response=self.__test_message_handler(request_message))
        elif request_type == "end_message_request":
            # Close connection without returning if get end_message_request.
            return True, None
        elif request_type == "agg_message_request":
            return False, mpc_message.MPCConnectionResponse(
                agg_message_response=self.__agg_message_handler(request_message.agg_message_request, context))
        else:
            context.set_code(grpc.StatusCode.UNIMPLEMENTED)
            context.set_details(request_type + ': Request type not implemented!')
            return False, mpc_message.MPCConnectionResponse(
                unknown_message_response=mpc_message.UnknownMessageResponse())

    def __test_message_handler(self, request_message):
        """
        Gets test message and returns TestMessageResponse with exact the same message.
        :param request_message MPCConnectionRequest
        :return MPCConnectionResponse
        """
        return mpc_message.TestMessageResponse(test_message=request_message.test_message_request.test_message)

    def __agg_message_handler(self, agg_message, context):
        """
        Aggregates gradients from all Data owners.
        :param agg_message: AggregationRequest
        :param context: ServicerContext, rpc call context
        :return: AggregationResponse
        """
        if not self.__server_status.submit_gradients(agg_message):
            context.set_code(grpc.StatusCode.NOT_FOUND)
            context.set_details('Unable to find DO ' + agg_message.do_uuid + " in query " + agg_message.query_uuid)
            return mpc_message.AggregationResponse()

        try:
            global_gradients = self.__server_status.wait_or_aggregate(agg_message.query_uuid, agg_message.epoch)
        except TimeoutError:
            context.set_code(grpc.StatusCode.DEADLINE_EXCEEDED)
            context.set_details(
                'Deadline exceeded when waiting ' + agg_message.query_uuid + " gradients aggregation, epoch: ",
                agg_message.epoch)
            return mpc_message.AggregationResponse()
        except Exception as exp:
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(str(exp))
            return mpc_message.AggregationResponse()

        return mpc_message.AggregationResponse(gradients=global_gradients)

    def plan_psi(self, do_qc: dict):

        pass


def start_mpc_service(port):
    """Starts MPC service
    :param port: str, Port the server is listening
    """
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=_WORKER_POOL_SIZE))
    server_status = mpc_status.MPCServerStatus()
    chain_worker = mpc_chain.MPCChainWorker(server_status)
    mpc_message_grpc.add_MPCServiceServicer_to_server(MPCServiceImpl(server_status, chain_worker), server)
    # TODO: Change to use a secure port.
    server.add_insecure_port('[::]:' + port)
    server.start()
    try:
        while True:
            time.sleep(_ONE_DAY_IN_SECONDS)
    except KeyboardInterrupt:
        server.stop(0)


if __name__ == '__main__':
    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)
    start_mpc_service(sys.argv[1])
