"""
mpc helper:
    register from ss
"""
import json

from soterml.connection.proto import soterone_service_pb2
from soterml.connection.proto.soterone_service_pb2_grpc import SoteroneServiceStub


def register_mpc(channel, **mpc_info):
    """
    MPC register from SS
    it needs:
    uuid, publick_key, node_info(NodeInfo) and resource_info(ResourceInfo)
    because many args are not required so I use dict
    """
    stub = SoteroneServiceStub(channel)
    uuid = mpc_info['uuid']
    public_key = mpc_info['public_key']
    _node_info = mpc_info['node_info']

    resquest = soterone_service_pb2.RegisterMPCRequest()
    mpc_info = resquest.mpc_info
    mpc_info.uuid = uuid
    mpc_info.public_key = public_key
    node_info = mpc_info.node_info
    node_info.uuid = _node_info['uuid']
    node_info.address = _node_info['address']
    node_info.port = _node_info['port']

    res = stub.RegisterMPC(resquest)

    json_content = {'do_uuid': res.uuid}
    with open('./mpc_register_res.json', 'w') as fb:
        json.dump(json_content, fb)

    return res
