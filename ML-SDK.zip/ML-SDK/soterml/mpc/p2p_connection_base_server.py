class P2PConnectionServer:
    """
    for p2p grpc long connection
    """

    def __init__(self):
        pass

    def connection(self, request_iterator, context):
        """
        receive requests and return responses
        """
        pass

    def handle_one_request(self, request, context):
        """
        handle each request and yield response
        """
        pass


