class MPCChainWorker:
    """The worker with the chain. Will push MPC server information as well as monitor information from the Chain.

    Attributes
    ----------
    __server_status: MPCServerStatus, maintain statuses of the server.
    """

    def __init__(self, server_status):
        self.__server_status = server_status

    def listen_query_cluster(self):
        """Listens Query Cluster information on the chain and pushes related cluster to server status"""
        # TODO: add impl
        pass

    def query_cluster_cleanup(self):
        """Listens Query Finishes information and cleanup server status"""
        # TODO: add impl
        pass
