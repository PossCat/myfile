from soterml.learning.vertical.workflow.logistic_regression import HostWorkflow, GuestWorkflow, MPCWorkflow

workflow_path = "./../../../soterml/learning/vertical/workflow/"
running_time_config_path = workflow_path + "conf/default_runtime_conf.json"

data_io_config = workflow_path + "conf/default_data_io.json"

def start_host():
    pass

def start_guest():
    pass

def start_mpc():
    pass