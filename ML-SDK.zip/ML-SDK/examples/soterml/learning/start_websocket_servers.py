import subprocess
import sys
from pathlib import Path

python = Path(sys.executable).name

FILE_PATH = Path(__file__).resolve().parents[4].joinpath(r"./run_websocket_servers.py")
print(FILE_PATH)


call_worker1 = [python, FILE_PATH.name, "--port", "8787", "--id", "worker1"]

call_worker2 = [python, FILE_PATH.name, "--port", "8788", "--id", "worker2"]

call_worker3 = [python, FILE_PATH.name, "--port", "8789", "--id", "worker3"]


call_worker4 = [python, FILE_PATH.name, "--port", "8790", "--id", "worker4"]

call_worker5 = [python, FILE_PATH.name, "--port", "8791", "--id", "worker5"]

call_worker6 = [python, FILE_PATH.name, "--port", "8792", "--id", "worker6"]

call_mpc1 = [python, FILE_PATH.name, "--port", "8771", "--id", "mpc1"]

call_mpc2 = [python, FILE_PATH.name, "--port", "8772", "--id", "mpc2"]

call_mpc3 = [python, FILE_PATH.name, "--port", "8773", "--id", "mpc3"]

call_mpc4 = [python, FILE_PATH.name, "--port", "8774", "--id", "mpc4"]


subprocess.Popen(call_worker1)
subprocess.Popen(call_worker2)
subprocess.Popen(call_worker3)
subprocess.Popen(call_worker4)
subprocess.Popen(call_worker5)
subprocess.Popen(call_worker6)


subprocess.Popen(call_mpc1)
subprocess.Popen(call_mpc2)
subprocess.Popen(call_mpc3)
subprocess.Popen(call_mpc4)