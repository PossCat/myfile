import datetime
import sys
import socket

import syft
import torch

sys.path.append('../../../')
from soterml.connection.proto import soterone_data_pb2, soterone_service_pb2
from soterml.learning.horizontal.torch_model.testnet_models import Net1
from soterml.connection.chain import SoterOneChain
from soterml.learning.testnet.utils import get_nodes_from_query_info
from soterml.learning.testnet.MNIST_MPC_websocket_parallel import train_model
from syft import VirtualWorker


def get_host_ip():
    """
    query native IP
    :return: ip
    """
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
    finally:
        s.close()

    return ip


def get_query_info_and_nodes_info():
    cur_time = str(datetime.date.today())
    mock_response = soterone_service_pb2.GetQueryInfoResponse()
    query_info = mock_response.query_info
    query_info.uuid = 'uuid ' + cur_time
    query_info.content = ('content ' + cur_time).encode('utf8')

    query_cluster = mock_response.query_cluster
    query_cluster.query_uuid = 'query_cluster.query_uuid ' + cur_time

    # MPC nodes
    mpc_nodes = query_cluster.mpc_nodes.add()
    mpc_nodes.address = get_host_ip()
    mpc_nodes.port = "8779"

    mpc_nodes = query_cluster.mpc_nodes.add()
    mpc_nodes.address = get_host_ip()
    mpc_nodes.port = "8780"

    mpc_nodes = query_cluster.mpc_nodes.add()
    mpc_nodes.address = get_host_ip()
    mpc_nodes.port = "8781"

    # Compute nodes
    do_nodes = query_cluster.do_nodes.add()
    do_nodes.address = get_host_ip()
    do_nodes.port = "8777"

    do_nodes = query_cluster.do_nodes.add()
    do_nodes.address = get_host_ip()
    do_nodes.port = "8778"

    mock_response.query_info.data_set = 1

    return mock_response


query_info_and_nodes_info = get_query_info_and_nodes_info()
model = Net1()

hook = syft.TorchHook(torch)

compute_nodes = [VirtualWorker(id='worker1', hook=hook), VirtualWorker(id='worker2', hook=hook)]
mpc_nodes = [VirtualWorker(id='mpc1', hook=hook),
             VirtualWorker(id='mpc2', hook=hook),
             VirtualWorker(id='mpc3', hook=hook)]

# compute_nodes, mpc_nodes = get_nodes_from_query_info(query_info_and_nodes_info, hook)
ctx = {
            'config1': {'ip': '127.0.0.1', 'port': '80'},
            'config2': {'ip': '127.0.0.1', 'port': '8080'},
        }

chain = SoterOneChain('http://132.232.36.171:8645',
                      '980b26e2fa86b5a1ca0e3fd6eafcfd226fb868727522022289287ceb7f328768',
                      ctx)
query_uuid = "test_submit_query"
model_trained = train_model(chain,
                            query_uuid,
                            query_info_and_nodes_info,
                            compute_nodes,
                            model,
                            mpc_nodes)

chain.shutdown()
