"""
This file is the test of parallel training for multiple DOs

Preparation: start the websocket server workers
python start_websocket_servers.py
"""

import unittest
import syft
import torch
import torch.nn as nn
from syft.workers.websocket_client import WebsocketClientWorker
from soterml.learning.testnet.titanic_MPC_websocket_parallel import train_model
import pandas as pd
from torch.utils.data import TensorDataset, DataLoader

# define global hook
hook = syft.TorchHook(torch)


class TestTitanicMPCWebsocketParallel(unittest.TestCase):
    """
    define test class
    """

    def get_nodes(self):
        """
        return custom nodes
        """
        worker1 = WebsocketClientWorker(hook=hook, port=8787, host="localhost", id="worker1")
        worker2 = WebsocketClientWorker(hook=hook, port=8788, host="localhost", id="worker2")
        worker3 = WebsocketClientWorker(hook=hook, port=8789, host="localhost", id="worker3")

        mpc_node_1 = WebsocketClientWorker(hook=hook, port=8771, host="localhost", id="mpc1")
        mpc_node_2 = WebsocketClientWorker(hook=hook, port=8772, host="localhost", id="mpc2")
        mpc_node_3 = WebsocketClientWorker(hook=hook, port=8773, host="localhost", id="mpc3")

        crypto_provider = WebsocketClientWorker(hook=hook, port=8790,
                                                host="localhost", id="worker4")

        compute_nodes = [worker1, worker2, worker3]
        mpc_nodes = [mpc_node_1, mpc_node_2, mpc_node_3]

        return compute_nodes, mpc_nodes, crypto_provider

    def get_model(self):
        """
        return custom model
        """
        class Net(nn.Module):
            def __init__(self):
                super(Net, self).__init__()
                self.fc1 = nn.Linear(5, 1)

            def forward(self, x):
                x = self.fc1(x)
                x = torch.sigmoid(x)
                return x
        return Net()

    def model_test(self, model, test_loader: list):
        """
                test the model
                :param model
                :param test_loader
                :return
                """
        test_loss = 0
        for data, target in test_loader:
            output = model(data)
            loss = nn.BCELoss()
            test_loss += loss(output.squeeze(), target)

        test_loss /= len(test_loader.dataset)
        return test_loss

    def test_run(self):
        """
        (1) get custom nodes and model
        (2) call the train_model() to complete training
        """
        compute_nodes, mpc_nodes, crypto_provider = self.get_nodes()
        model = self.get_model()

        # get test data
        # the "train.csv" can be download in https://www.kaggle.com/c/titanic/data?select=train.csv
        data = pd.read_csv('./data/train.csv').fillna(0)
        test_data = data[700:]
        features = ['Pclass', 'Age', 'SibSp', 'Parch', 'Fare']
        target = 'Survived'
        data_test = torch.from_numpy(test_data[features].values).float()
        target_test = torch.from_numpy(test_data[target].values).float()
        test_dataset = TensorDataset(data_test, target_test)

        # Set a fixed random seed
        torch.manual_seed(1)

        # test raw model
        test_loader = DataLoader(test_dataset, batch_size=64, shuffle=True)
        loss_before_training = self.model_test(model, test_loader)

        # train model
        model = train_model(compute_nodes, crypto_provider, model, mpc_nodes)

        # test trained model
        test_loader = DataLoader(test_dataset, batch_size=64, shuffle=True)
        loss_after_training = self.model_test(model, test_loader)

        print("Loss before training: ", loss_before_training, ", Loss after training: ", loss_after_training)


if __name__ == '__main__':
    unittest.main()
