"""
    start mpc here
    register mpc and start the servicer
"""
import logging
import sys
from soterml.mpc.mpc_helper import register_mpc
from soterml.mpc.mpc_server import start_mpc_service
import grpc

channel = grpc.insecure_channel('localhost:9000',
                                options=[
                                    ('grpc.max_send_message_length', 5 * 1024 * 1024),
                                    ('grpc.max_receive_message_length',
                                     5 * 1024 * 1024),
                                ],
                                )

if __name__ == '__main__':
    mpc_info = {'uuid': 'mpcuuid',
                'public_key': 'mpcpublic_key'
                }
    node_info = {'uuid': 'node_infouuid',
                 'address': 'node_infoaddress',
                 'port': 'node_infoport'
                 }
    mpc_info['node_info'] = node_info

    mpc_uuid = register_mpc(channel, **mpc_info)
    # print(mpc_uuid)
    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)
    start_mpc_service(sys.argv[1])
