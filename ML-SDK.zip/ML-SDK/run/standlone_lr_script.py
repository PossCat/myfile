"""
test program
1. fix grpc and chain config file: soterml/learning/vertical/workflow/conf/local_params_config.json
                                    soterml/learning/vertical/workflow/conf/data_path_config.json
2. SS start
3. chain start
"""
import time
import sys
sys.path.append('../')

import grpc

from soterml.connection.chain import SoterOneChain
from soterml.connection.proto.grpc_service_pb2_grpc import SoteroneServiceStub
from soterml.connection.soterone import register_do, register_mpc
from soterml.learning.vertical.config.CONFIG import CHAIN_ADDRESS
from soterml.learning.vertical.workflow.logistic_regression import HostWorkflow
from soterml.learning.vertical.workflow.logistic_regression import GuestWorkflow
from soterml.learning.vertical.workflow.logistic_regression import MPCWorkflow


def workflow_run(workflow):
    workflow.run()


def RegisterALL():
    do1_chain = SoterOneChain(CHAIN_ADDRESS,
                              'ed587757a0ce2b5a6b21b8b5e72be2646ad80122a638539c9420b6b9cb9e0638',
                              {})
    do2_chain = SoterOneChain(CHAIN_ADDRESS,
                              '123c60a2b70bf9afd139a61bfad18fd1d113789a388c5709f5dd00cd0397ed0c',
                              {})
    mpc_chain = SoterOneChain(CHAIN_ADDRESS,
                              'cad0aa81610e0ae58edd7add1188d8bfb8730633efedab7a6fd7560136936231',
                              {})
    ss_stub = SoteroneServiceStub(grpc.insecure_channel('192.168.1.25:9000'))

    # ## register DO and MPC in chain
    do1_chain.register_do('pubkey1', 'beta1.0', 100)
    do2_chain.register_do('pubkey2', 'beta1.0', 100)
    mpc_chain.register_mpc('pubkey3', 'beta1.0', 100)
    #
    # res_register_do1 = register_do(uuid='0xFc805EDd43C76B569c00D998Fe1E74E60aF31213',
    #                                pubkey='pubkey1', ip='localhost', port='10086', stub=ss_stub)
    # res_register_do2 = register_do(uuid='0x40A680e0461f5888Ea4Af71fc3d137cF9aa0f18C',
    #                                pubkey='pubkey2', ip='localhost', port='10087', stub=ss_stub)
    # res_register_mpc = register_mpc(uuid='0x4860a1F0488119D1e858FFf94Ce2A2DD6E02954e',
    #                                 pubkey='pubkey3', ip='localhost', port='10088', stub=ss_stub)
    time.sleep(10)
    do1_chain.shutdown()
    do2_chain.shutdown()
    mpc_chain.shutdown()


if __name__ == '__main__':
    local_config_path = './config/local_params_config.json'

    # RegisterALL()

    from threading import Thread

    mpc_workflow = MPCWorkflow(local_config_path)
    mpc = Thread(target=workflow_run, args=(mpc_workflow,))
    mpc.start()

    host_workflow = HostWorkflow(local_config_path)
    host = Thread(target=workflow_run, args=(host_workflow,))
    host.start()

    guest_workflow = GuestWorkflow(local_config_path)
    guest = Thread(target=workflow_run, args=(guest_workflow, ))
    guest.start()

    while True:
        time.sleep(10)
