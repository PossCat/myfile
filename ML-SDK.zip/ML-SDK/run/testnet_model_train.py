import sys
import os
import threading

import grpc
import time
import queue
import pickle
from functools import partial

sys.path.append('../')
from soterml.connection.chain import SoterOneChain, ChainEvent
from soterml.learning.testnet.train import training_workflow
from soterml.learning.testnet.prediction import prediction_workflow


def get_queue():
    if os.path.exists('./training_task_queue'):
        mutex.acquire()
        with open('./training_task_queue', 'rb') as file:
            train_event_queue = pickle.load(file)
        mutex.release()
    else:
        mutex.acquire()
        train_event_queue = []
        with open('./training_task_queue', 'wb') as file:
            pickle.dump(train_event_queue, file)
        mutex.release()
    return train_event_queue


def train_event(chain, event):
    mutex.acquire()
    train_event_queue.append({"event": event})
    with open('./training_task_queue', 'wb') as file:
        pickle.dump(train_event_queue, file)
    mutex.release()


if __name__ == '__main__':
    """
    The boot function of the training script
    """
    mutex = threading.Lock()
    train_event_queue = get_queue()
    # monitor the chain and set the callback function

    ctx = {
        'config1': {'ip': '127.0.0.1', 'port': '80'},
        'config2': {'ip': '127.0.0.1', 'port': '8080'},
    }

    chain = SoterOneChain('http://132.232.36.171:8645',
                          '980b26e2fa86b5a1ca0e3fd6eafcfd226fb868727522022289287ceb7f328768',
                          ctx)

    # training = partial(training_workflow, channel=channel, model_path=model_path)

    # thechain.subscribe(ChainEvent.QuerySubmitted, training) event type you monitor
    chain.subscribe(ChainEvent.QuerySubmitted, train_event)
    chain.subscribe(ChainEvent.PredictionSubmitted, prediction_workflow)
    print(time.strftime("%X"), " Script is starting")

    while True:
        if train_event_queue:
            train_event = train_event_queue[0]
            training_workflow(chain, train_event["event"])
            mutex.acquire()
            train_event_queue.pop(0)
            with open('./training_task_queue', 'wb') as file:
                pickle.dump(train_event_queue, file)
            mutex.release()
        time.sleep(1)

