from soterml.connection.psi.connection.make_psi_plan import make_psi_plan, res_to_psi_plan_dict
from soterml.connection.soterone import get_query_info
from soterml.connection.chain import SoterOneChain, ChainEvent
from soterml.learning.vertical.config.CONFIG import CHAIN_ADDRESS, CHAIN_PRIVATE_KEY


def callback_of_psi_submitted(chain, event):
    event_queue.put({'PSI_SUBMITTED': event['uuid']})
    print(event)


if __name__ == '__main__':
    sc = SoterOneChain(CHAIN_ADDRESS, CHAIN_PRIVATE_KEY, {})
    sc.subscribe(ChainEvent.QuerySubmitted, callback_of_psi_submitted)
    # sc.submit_query('test_psi_query')

    from queue import Queue

    event_queue = Queue()

    from soterml.connection.proto.grpc_service_pb2_grpc import SoteroneServiceStub
    import grpc

    event = event_queue.get()
    if 'PSI_SUBMITTED' in event:
        psi_query_uuid = event['PSI_SUBMITTED']
        print('psi query uuid is:', psi_query_uuid)

    stub = SoteroneServiceStub(grpc.insecure_channel('192.168.43.18:9000'))
    res = get_query_info(psi_query_uuid, 'do_uuid_01', stub)

    info_dict = res_to_psi_plan_dict(res)

    make_psi_plan(psi_query_uuid, info_dict, sc)

    print(info_dict)
