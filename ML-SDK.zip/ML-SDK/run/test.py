from soterml.learning.vertical.workflow.logistic_regression import HostWorkflow, GuestWorkflow, MPCWorkflow

if __name__ == '__main__':


    host = HostWorkflow(r'D:\Development\Python\ML-SDK\soterml\learning\vertical\workflow\conf\local_params_config.json')
    host._run()

